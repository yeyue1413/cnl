package com.cnl.battle;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class BattleCommand implements CommandExecutor, TabCompleter {

    private final Main plugin;
    private final BattleGameManager gameManager;
    private final RerollManager rerollManager;
    private final TeamManager teamManager;
    private final AbilityMasterManager masterManager;
    private final CommandExecutor originalExecutor;
    private TabCompleter originalTabCompleter;

    public BattleCommand(Main plugin, BattleGameManager gameManager, RerollManager rerollManager, TeamManager teamManager, AbilityMasterManager masterManager, CommandExecutor originalExecutor) {
        this.plugin = plugin;
        this.gameManager = gameManager;
        this.rerollManager = rerollManager;
        this.teamManager = teamManager;
        this.masterManager = masterManager;
        this.originalExecutor = originalExecutor;
    }

    public void setOriginalTabCompleter(TabCompleter completer) {
        this.originalTabCompleter = completer;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (originalExecutor != null) {
                return originalExecutor.onCommand(sender, command, label, args);
            }
            return false;
        }

        String subCmd = args[0];

        if (subCmd.equals("battle")) {
            return handleBattleCommand(sender, command, label, args);
        }

        if (originalExecutor != null) {
            return originalExecutor.onCommand(sender, command, label, args);
        }

        return false;
    }

    private boolean handleBattleCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§6[大逃杀] §c用法:");
            sender.sendMessage("§6[大逃杀] §e/cnl battle start <on/off> [day/night]");
            sender.sendMessage("§6[大逃杀] §e/cnl battle mode <day/night/normal>");
            sender.sendMessage("§6[大逃杀] §e/cnl battle team <1/2/3/4/99/random/clear> §7- 设置队伍模式");
            sender.sendMessage("§6[大逃杀] §e/cnl battle samespawn <on/off> §7- 同队同出生点开关");
            sender.sendMessage("§6[大逃杀] §e/cnl battle ff <on/off> §7- 友伤开关");
            sender.sendMessage("§6[大逃杀] §e/cnl battle roll §7- 刷新超能力");
            sender.sendMessage("§6[大逃杀] §e/cnl battle ok §7- 确认准备完毕");
            sender.sendMessage("§6[大逃杀] §e/cnl battle debug ... §7- 测试指令");
            sender.sendMessage("§6[大逃杀] §e/cnl battle addspectator <玩家> §7- 让旁观者重新加入游戏");
            sender.sendMessage("§6[大逃杀] §e/cnl battle reset §7- 重置主世界和地狱");
            sender.sendMessage("§6[大逃杀] §e/cnl battle master <on/off> §7- 超能力大师模式");
            sender.sendMessage("§6[大逃杀] §e/cnl battle masterreroll §7- 刷新超能力（死亡3次无击杀可用）");
            sender.sendMessage("§6[大逃杀] §e/cnl battle click <玩家> <on/off> §7- 按钮点击权限");
            return true;
        }

        String subCmd = args[1];

        switch (subCmd) {
            case "start" -> {
                return handleGameStart(sender, args);
            }
            case "mode" -> {
                return handleMode(sender, args);
            }
            case "team" -> {
                return handleTeam(sender, args);
            }
            case "samespawn" -> {
                return handleSameSpawn(sender, args);
            }
            case "ff" -> {
                return handleFriendlyFire(sender, args);
            }
            case "roll" -> {
                return handleReroll(sender);
            }
            case "ok" -> {
                return handleOk(sender);
            }
            case "debug" -> {
                return handleDebug(sender, args);
            }
            case "reset" -> {
                return handleReset(sender);
            }
            case "addspectator" -> {
                return handleAddSpectator(sender, args);
            }
            case "master" -> {
                return handleMaster(sender, args);
            }
            case "masterreroll" -> {
                return handleMasterReroll(sender);
            }
            case "click" -> {
                return handleClick(sender, args);
            }
            default -> {
                sender.sendMessage("§6[大逃杀] §c未知子命令!");
                return true;
            }
        }
    }

    private boolean handleGameStart(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle start <on/off> [day/night]");
            return true;
        }

        String action = args[2];

        if (action.equals("on")) {
            if (gameManager.isGameRunning()) {
                sender.sendMessage("§6[大逃杀] §c游戏已在运行!");
                return true;
            }

            if (args.length >= 4) {
                String modeStr = args[3].toLowerCase();
                switch (modeStr) {
                    case "day" -> gameManager.startGame(BattleGameManager.GameModeType.ETERNAL_DAY);
                    case "night" -> gameManager.startGame(BattleGameManager.GameModeType.ETERNAL_NIGHT);
                    default -> gameManager.startGame();
                }
            } else {
                gameManager.startGame();
            }

            sender.sendMessage("§6[大逃杀] §a大逃杀已启动!");
            return true;
        }

        if (action.equals("off")) {
            if (!gameManager.isGameRunning()) {
                sender.sendMessage("§6[大逃杀] §c游戏未在运行!");
                return true;
            }

            gameManager.stopGame();
            sender.sendMessage("§6[大逃杀] §a大逃杀已停止!");
            Bukkit.broadcastMessage("§6[大逃杀] §e大逃杀已停止!");
            return true;
        }

        sender.sendMessage("§6[大逃杀] §c参数错误! 使用 §eon §c或 §eoff");
        return true;
    }

    private boolean handleMode(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle mode <day/night/normal>");
            sender.sendMessage("§6[大逃杀] §c当前模式: " + gameManager.getCurrentMode().getDisplayName());
            return true;
        }

        String modeStr = args[2].toLowerCase();
        BattleGameManager.GameModeType mode;
        switch (modeStr) {
            case "day" -> mode = BattleGameManager.GameModeType.ETERNAL_DAY;
            case "night" -> mode = BattleGameManager.GameModeType.ETERNAL_NIGHT;
            case "normal" -> mode = BattleGameManager.GameModeType.NORMAL;
            default -> {
                sender.sendMessage("§6[大逃杀] §c未知模式! 使用 day/night/normal");
                return true;
            }
        }

        if (gameManager.isGameRunning()) {
            sender.sendMessage("§6[大逃杀] §c游戏正在运行中！模式将在下一局生效");
        }

        sender.sendMessage("§6[大逃杀] §a已设置模式: " + mode.getDisplayName());
        return true;
    }

    private boolean handleTeam(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle team <1/2/3/4/99/random/clear>");
            sender.sendMessage("§6[大逃杀] §c当前队伍模式: " + getTeamModeDisplay());
            return true;
        }

        if (gameManager.isGameRunning()) {
            sender.sendMessage("§6[大逃杀] §c游戏已在运行！无法修改队伍模式!");
            return true;
        }

        String teamStr = args[2].toLowerCase();

        switch (teamStr) {
            case "solo", "1" -> {
                teamManager.setMode(TeamManager.TeamMode.SOLO);
                teamManager.cleanup();
                sender.sendMessage("§6[大逃杀] §a已设置为个人战（不分队）");
            }
            case "random" -> {
                List<UUID> playerIds = new ArrayList<>();
                for (Player p : Bukkit.getOnlinePlayers()) {
                    if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                        playerIds.add(p.getUniqueId());
                    }
                }

                if (teamManager.getMode() == TeamManager.TeamMode.SOLO) {
                    teamManager.setMode(TeamManager.TeamMode.DUO);
                    teamManager.initializeTeams(playerIds.size());
                    teamManager.setAllToAdventure();
                } else if (!teamManager.isInitialized()) {
                    teamManager.initializeTeams(playerIds.size());
                    teamManager.setAllToAdventure();
                }
                teamManager.setRandomAssign(true);
                teamManager.randomAssignTeams(playerIds);
                teamManager.broadcastTeamDisplay();
                sender.sendMessage("§6[大逃杀] §a已随机分队! 不满意的OP可再次输入 §e/cnl battle team random §a重新分队");
            }
            case "clear" -> {
                teamManager.cleanup();
                sender.sendMessage("§6[大逃杀] §e已清除所有队伍分配");
            }
            default -> {
                try {
                    int teamSize = Integer.parseInt(teamStr);
                     switch (teamSize) {
                         case 2 -> {
                             teamManager.setMode(TeamManager.TeamMode.DUO);
                             teamManager.initializeTeams(Bukkit.getOnlinePlayers().size());
                             teamManager.setAllToAdventure();
                             sender.sendMessage("§6[大逃杀] §a已设置为2人一队！玩家可潜行+§cF§a打开界面选择队伍");
                         }
                         case 3 -> {
                             teamManager.setMode(TeamManager.TeamMode.TRIO);
                             teamManager.initializeTeams(Bukkit.getOnlinePlayers().size());
                             teamManager.setAllToAdventure();
                             sender.sendMessage("§6[大逃杀] §a已设置为3人一队！玩家可潜行+§cF§a打开界面选择队伍");
                         }
                         case 4 -> {
                             teamManager.setMode(TeamManager.TeamMode.QUAD);
                             teamManager.initializeTeams(Bukkit.getOnlinePlayers().size());
                             teamManager.setAllToAdventure();
                             sender.sendMessage("§6[大逃杀] §a已设置为4人一队！玩家可潜行+§cF§a打开界面选择队伍");
                         }
                         case 99 -> {
                             teamManager.setMode(TeamManager.TeamMode.HALF);
                             teamManager.setRandomAssign(false);
                             teamManager.initializeTeams(Bukkit.getOnlinePlayers().size());
                             teamManager.setAllToAdventure();
                             sender.sendMessage("§6[大逃杀] §a已设置为对半分队（红蓝）！玩家可潜行+§cF§a打开界面选择队伍");
                        }
                        default -> {
                            sender.sendMessage("§6[大逃杀] §c无效! 支持的数字: 2/3/4/99");
                            return true;
                        }
                    }
                } catch (NumberFormatException e) {
                     sender.sendMessage("§6[大逃杀] §c未知队伍模式! 使用 1/2/3/4/99/random/clear");
                     return true;
                }
            }
        }

        return true;
    }

    private boolean handleSameSpawn(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle samespawn <on/off>");
            sender.sendMessage("§6[大逃杀] §c当前同队同出生点: " + (teamManager.isSameSpawn() ? "§a开启" : "§c关闭"));
            return true;
        }

        String value = args[2].toLowerCase();
        switch (value) {
            case "on" -> {
                teamManager.setSameSpawn(true);
                sender.sendMessage("§6[大逃杀] §a同队同出生点已开启");
            }
            case "off" -> {
                teamManager.setSameSpawn(false);
                sender.sendMessage("§6[大逃杀] §c同队同出生点已关闭，每个玩家各自随机出生");
            }
            default -> {
                sender.sendMessage("§6[大逃杀] §c参数错误! 使用 on 或 off");
                return true;
            }
        }
        return true;
    }

    private boolean handleFriendlyFire(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle ff <on/off>");
            sender.sendMessage("§6[大逃杀] §c当前友伤: " + (teamManager.isFriendlyFire() ? "§a开启" : "§c关闭"));
            return true;
        }

        String value = args[2].toLowerCase();
        switch (value) {
            case "on" -> {
                teamManager.setFriendlyFire(true);
                sender.sendMessage("§6[大逃杀] §a友伤已开启，同队伍玩家可互相伤害");
            }
            case "off" -> {
                teamManager.setFriendlyFire(false);
                sender.sendMessage("§6[大逃杀] §c友伤已关闭，同队伍玩家无法互相伤害");
            }
            default -> {
                sender.sendMessage("§6[大逃杀] §c参数错误! 使用 on 或 off");
                return true;
            }
        }
        return true;
    }

    private String getTeamModeDisplay() {
        if (teamManager == null) return "个人战";
        TeamManager.TeamMode mode = teamManager.getMode();
        if (mode == TeamManager.TeamMode.SOLO) return "个人战";
        String modeName = switch (mode) {
            case DUO -> "2人一队";
            case TRIO -> "3人一队";
            case QUAD -> "4人一队";
            case HALF -> "对半（红蓝）";
            default -> mode.name();
        };
        if (teamManager.isRandomAssign()) modeName += " (随机分队)";
        return modeName;
    }

    private boolean handleReroll(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§6[大逃杀] §c只有玩家可以使用此命令!");
            return true;
        }

        if (!gameManager.isGameRunning()) {
            player.sendMessage("§6[大逃杀] §c游戏未在运行!");
            return true;
        }

        if (!gameManager.isParticipant(player)) {
            player.sendMessage("§6[大逃杀] §c你不是游戏参与者!");
            return true;
        }

        player.sendMessage("§6[大逃杀] §e请在聊天栏输入 1、2 或 3 选择超能力!");
        return true;
    }

    private boolean handleOk(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§6[大逃杀] §c只有玩家可以使用此命令!");
            return true;
        }

        if (!gameManager.isGameRunning()) {
            player.sendMessage("§6[大逃杀] §c游戏未在运行!");
            return true;
        }

        if (!gameManager.isParticipant(player)) {
            player.sendMessage("§6[大逃杀] §c你不是游戏参与者!");
            return true;
        }

        if (gameManager.isConfirmed(player.getUniqueId())) {
            player.sendMessage("§6[大逃杀] §a你已经确认过了！");
            return true;
        }

        gameManager.confirmPlayer(player.getUniqueId());
        return true;
    }

    private boolean handleDebug(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法:");
            sender.sendMessage("§6[大逃杀] §e/cnl battle debug next §7- 强制进入下一个圈");
            sender.sendMessage("§6[大逃杀] §e/cnl battle debug shrink §7- 跳过停留立即缩圈");
            sender.sendMessage("§6[大逃杀] §e/cnl battle debug solo §7- 单人模式");
            sender.sendMessage("§6[大逃杀] §e/cnl battle debug win [玩家] §7- 直接获胜");
            return true;
        }

        String debugCmd = args[2];

        switch (debugCmd) {
            case "next" -> {
                if (!gameManager.isGameRunning()) {
                    sender.sendMessage("§6[大逃杀] §c游戏未在运行!");
                    return true;
                }
                gameManager.forceNextCircle();
                sender.sendMessage("§6[大逃杀] §a[测试] 已强制进入下一个圈!");
                return true;
            }
            case "shrink" -> {
                if (!gameManager.isGameRunning()) {
                    sender.sendMessage("§6[大逃杀] §c游戏未在运行!");
                    return true;
                }
                gameManager.forceShrink();
                return true;
            }
            case "solo" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("§6[大逃杀] §c只有玩家可以使用此命令!");
                    return true;
                }
                if (gameManager.isGameRunning()) {
                    sender.sendMessage("§6[大逃杀] §c已有游戏在运行！请先停止!");
                    return true;
                }
                gameManager.startSolo(player);
                sender.sendMessage("§6[大逃杀] §a[单人] 单人大逃杀已开始!");
                return true;
            }
            case "win" -> {
                if (!gameManager.isGameRunning()) {
                    sender.sendMessage("§6[大逃杀] §c游戏未在运行!");
                    return true;
                }
                Player target;
                if (args.length >= 4) {
                    target = Bukkit.getPlayer(args[3]);
                    if (target == null) {
                        sender.sendMessage("§6[大逃杀] §c玩家不存在或离线!");
                        return true;
                    }
                } else {
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage("§6[大逃杀] §c请指定玩家!");
                        return true;
                    }
                    target = player;
                }
                if (!gameManager.isParticipant(target)) {
                    sender.sendMessage("§6[大逃杀] §c该玩家不是游戏参与者!");
                    return true;
                }
                gameManager.forceWin(target);
                sender.sendMessage("§6[大逃杀] §a[测试] " + target.getName() + " 已被强制获胜!");
                return true;
            }
            default -> {
                sender.sendMessage("§6[大逃杀] §c未知调试命令!");
                return true;
            }
        }
    }

    private boolean handleReset(CommandSender sender) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        sender.sendMessage("§6[大逃杀] §e正在重置主世界和地狱...");
        sender.sendMessage("§6[大逃杀] §c注意：所有玩家将被踢出，世界将被删除重建!");
        sender.sendMessage("§6[大逃杀] §e请稍候...");

        Bukkit.getScheduler().runTask(plugin, () -> {
            gameManager.resetWorlds();
        });

        return true;
    }

    private boolean handleAddSpectator(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (!gameManager.isGameRunning()) {
            sender.sendMessage("§6[大逃杀] §c游戏未在运行!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle addspectator <玩家>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage("§6[大逃杀] §c玩家不存在或离线!");
            return true;
        }

        if (gameManager.isParticipant(target)) {
            sender.sendMessage("§6[大逃杀] §c该玩家已经是参与者了!");
            return true;
        }

        gameManager.addSpectatorPlayer(target);
        sender.sendMessage("§6[大逃杀] §a已将 " + target.getName() + " 重新加入游戏!");
        return true;
    }

    private boolean handleMaster(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle master <on/off>");
            sender.sendMessage("§6[大逃杀] §c当前超能力大师模式: " + (masterManager.isActive() ? "§a开启" : "§c关闭"));
            return true;
        }

        if (gameManager.isGameRunning()) {
            sender.sendMessage("§6[大逃杀] §c游戏已在运行！无法切换模式!");
            return true;
        }

        String value = args[2].toLowerCase();
        switch (value) {
            case "on" -> {
                masterManager.setActive(true);
                sender.sendMessage("§6[大逃杀] §a超能力大师模式已开启！击杀敌人获得超能力，击杀数最高者获胜！");
            }
            case "off" -> {
                masterManager.setActive(false);
                sender.sendMessage("§6[大逃杀] §c超能力大师模式已关闭，恢复普通大逃杀模式");
            }
            default -> {
                sender.sendMessage("§6[大逃杀] §c参数错误! 使用 on 或 off");
                return true;
            }
        }
        return true;
    }

    private boolean handleMasterReroll(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§6[大逃杀] §c只有玩家可以使用此命令!");
            return true;
        }

        if (!gameManager.isGameRunning() || !masterManager.isActive()) {
            player.sendMessage("§6[大逃杀] §c当前不是超能力大师模式!");
            return true;
        }

        if (!gameManager.isParticipant(player)) {
            player.sendMessage("§6[大逃杀] §c你不是游戏参与者!");
            return true;
        }

        masterManager.tryMasterReroll(player);
        return true;
    }

    private boolean handleClick(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[大逃杀] §c你没有权限!");
            return true;
        }

        if (args.length < 4) {
            sender.sendMessage("§6[大逃杀] §c用法: /cnl battle click <玩家> <on/off>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[2]);
        if (target == null) {
            sender.sendMessage("§6[大逃杀] §c玩家不存在或离线!");
            return true;
        }

        String value = args[3].toLowerCase();
        if (value.equals("on")) {
            plugin.getClickPermitted().add(target.getUniqueId());
            sender.sendMessage("§6[大逃杀] §a已给予 §e" + target.getName() + " §a按钮点击权限");
            target.sendMessage("§6[大逃杀] §a你已被授予大厅按钮点击权限");
        } else if (value.equals("off")) {
            plugin.getClickPermitted().remove(target.getUniqueId());
            sender.sendMessage("§6[大逃杀] §e已移除 §e" + target.getName() + " §e的按钮点击权限");
        } else {
            sender.sendMessage("§6[大逃杀] §c参数错误! 使用 on 或 off");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (args.length == 1) {
            List<String> options = new ArrayList<>();
            options.add("battle");
            if (originalTabCompleter != null) {
                List<String> originalCompletions = originalTabCompleter.onTabComplete(sender, command, alias, args);
                if (originalCompletions != null) {
                    options.addAll(originalCompletions);
                }
            }
            StringUtil.copyPartialMatches(args[0], options, completions);
        } else if (args.length == 2 && args[0].equals("battle")) {
            List<String> options = Arrays.asList("start", "mode", "team", "samespawn", "ff", "roll", "ok", "debug", "addspectator", "reset", "master", "masterreroll", "click");
            StringUtil.copyPartialMatches(args[1], options, completions);
        } else if (args.length == 3 && args[0].equals("battle")) {
            if (args[1].equals("start")) {
                completions.add("on");
                completions.add("off");
            } else if (args[1].equals("mode")) {
                completions.add("day");
                completions.add("night");
                completions.add("normal");
            } else if (args[1].equals("team")) {
                completions.add("1");
                completions.add("2");
                completions.add("3");
                completions.add("4");
                completions.add("99");
                completions.add("random");
                completions.add("clear");
            } else if (args[1].equals("samespawn")) {
                completions.add("on");
                completions.add("off");
            } else if (args[1].equals("ff")) {
                completions.add("on");
                completions.add("off");
            } else if (args[1].equals("debug")) {
                completions.add("next");
                completions.add("shrink");
                completions.add("solo");
                completions.add("win");
            } else if (args[1].equals("addspectator")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    completions.add(p.getName());
                }
            } else if (args[1].equals("master")) {
                completions.add("on");
                completions.add("off");
            } else if (args[1].equals("click")) {
                for (Player p : Bukkit.getOnlinePlayers()) {
                    completions.add(p.getName());
                }
            }
        } else if (args.length == 4 && args[0].equals("battle")) {
            if (args[1].equals("start") && args[2].equals("on")) {
                completions.add("day");
                completions.add("night");
            } else if (args[1].equals("debug") && args[2].equals("win")) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    completions.add(player.getName());
                }
            } else if (args[1].equals("click")) {
                completions.add("on");
                completions.add("off");
            }
        } else if (originalTabCompleter != null) {
            List<String> originalCompletions = originalTabCompleter.onTabComplete(sender, command, alias, args);
            if (originalCompletions != null) {
                StringUtil.copyPartialMatches(args[args.length - 1], originalCompletions, completions);
            }
        }

        return completions;
    }
}
