package com.cnl.battle;

import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import org.bukkit.entity.Player;

import java.util.*;

public class RerollManager {

    private static final int MAX_REROLLS = 2;
    private static final int REROLL_TIME_LIMIT_SECONDS = 60;

    private final Map<UUID, Integer> rerollCounts = new HashMap<>();
    private final Map<UUID, List<String>> previousAbilities;
    private BattleGameManager gameManager;

    public RerollManager() {
        this.previousAbilities = new HashMap<>();
    }

    public void setGameManager(BattleGameManager gameManager) {
        this.gameManager = gameManager;
    }

    public void reset() {
        rerollCounts.clear();
        previousAbilities.clear();
    }

    public int getRerollCount(Player player) {
        return rerollCounts.getOrDefault(player.getUniqueId(), 0);
    }

    public int getRemainingRerolls(Player player) {
        return MAX_REROLLS - getRerollCount(player);
    }

    public boolean isLastReroll(Player player) {
        return getRemainingRerolls(player) == 1;
    }

    public void recordInitialAbility(UUID playerId, String abilityName) {
        previousAbilities.computeIfAbsent(playerId, k -> new ArrayList<>()).add(abilityName);
    }

    public String tryReroll(Player player) {
        UUID uuid = player.getUniqueId();

        if (gameManager == null || !gameManager.isGameRunning()) {
            return "§6[大逃杀] §c游戏未在运行!";
        }

        if (gameManager.isConfirmed(uuid)) {
            return "§6[大逃杀] §c你已经确认过了，无法继续刷新超能力!";
        }

        int gameTime = gameManager.getGameTimeSeconds();
        if (gameTime > REROLL_TIME_LIMIT_SECONDS) {
            return "§6[大逃杀] §c游戏已开始超过1分钟, 无法重新随机超能力!";
        }

        int usedCount = rerollCounts.getOrDefault(uuid, 0);
        if (usedCount >= MAX_REROLLS) {
            return "§6[大逃杀] §c你已用完本局所有重随机次数! (最多" + MAX_REROLLS + "次)";
        }

        List<String> abilityHistory = previousAbilities.getOrDefault(uuid, new ArrayList<>());
        AbilityType currentAbility = AbilityManager.getAbility(player);
        if (currentAbility != null && !abilityHistory.contains(currentAbility.getDisplayName())) {
            abilityHistory.add(currentAbility.getDisplayName());
        }

        AbilityType rerolledAbility = getRerollAbility(abilityHistory);
        if (rerolledAbility == null) {
            return "§6[大逃杀] §c无法找到可分配的超能力!";
        }

        player.getInventory().clear();

        AbilityManager.setAbility(player, rerolledAbility);

        abilityHistory.add(rerolledAbility.getDisplayName());
        previousAbilities.put(uuid, abilityHistory);

        rerollCounts.put(uuid, usedCount + 1);

        int remaining = MAX_REROLLS - (usedCount + 1);
        return "§6[大逃杀] §a你已重新随机超能力: §e" + rerolledAbility.getDisplayId() + ". " + rerolledAbility.getDisplayName()
            + "\n§7背包已清空！剩余重随机次数: §e" + remaining;
    }

    private AbilityType getRerollAbility(List<String> excludeNames) {
        AbilityType[] allAbilities = AbilityType.values();
        List<AbilityType> valid = new ArrayList<>();

        for (AbilityType type : allAbilities) {
            if (type == AbilityType.NONE || type == AbilityType.DAMAGE_TELEPORT) continue;
            if (!excludeNames.contains(type.getDisplayName())) {
                valid.add(type);
            }
        }

        if (valid.isEmpty()) {
            return AbilityType.FLASH;
        }

        return valid.get(new Random().nextInt(valid.size()));
    }
}
