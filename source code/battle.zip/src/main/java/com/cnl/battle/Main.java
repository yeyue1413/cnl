package com.cnl.battle;

import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class Main extends JavaPlugin implements Listener {

    private static Main instance;
    private BattleGameManager gameManager;
    private RerollManager rerollManager;
    private TeamManager teamManager;
    private AbilityMasterManager abilityMasterManager;
    private final Set<UUID> clickPermitted = new HashSet<>();

    @Override
    public void onEnable() {
        instance = this;

        new File(getDataFolder().getParentFile().getParentFile(), "restart.flag").delete();

        saveDefaultConfig();
        BattleConfig battleConfig = new BattleConfig(getConfig());

        JavaPlugin abilitiesPlugin = (JavaPlugin) Bukkit.getPluginManager().getPlugin("Abilities");
        if (abilitiesPlugin == null) {
            getLogger().severe("Abilities plugin not found! Battle plugin will not function.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        teamManager = new TeamManager(this);
        gameManager = new BattleGameManager(this, battleConfig);
        abilityMasterManager = new AbilityMasterManager(this, gameManager);
        rerollManager = new RerollManager();
        gameManager.setRerollManager(rerollManager);
        gameManager.setTeamManager(teamManager);
        gameManager.setAbilityMasterManager(abilityMasterManager);
        rerollManager.setGameManager(gameManager);

        AbilityManager.setBattleModeActive(true);

        AbilityManager.setOnRedeemerReviveCallback(player -> {
            if (gameManager != null && gameManager.isGameRunning()) {
                gameManager.readdParticipant(player);
                player.sendMessage("§6[大逃杀] §a你已被救赎者复活，重新加入战斗!");
            }
        });

        PluginCommand abilitiesCommand = abilitiesPlugin.getCommand("cnl");
        if (abilitiesCommand != null) {
            CommandExecutor originalExecutor = abilitiesCommand.getExecutor();
            TabCompleter originalTabCompleter = abilitiesCommand.getTabCompleter();

            BattleCommand battleCommand = new BattleCommand(this, gameManager, rerollManager, teamManager, abilityMasterManager, originalExecutor);
            battleCommand.setOriginalTabCompleter(originalTabCompleter);

            abilitiesCommand.setExecutor(battleCommand);
            abilitiesCommand.setTabCompleter(battleCommand);

            getLogger().info("Hooked into Abilities' /cnl command with Battle wrapper");
        } else {
            getLogger().warning("Could not find Abilities' cnl command!");
        }

        getServer().getPluginManager().registerEvents(this, this);

        for (String uuidStr : getConfig().getStringList("click-permitted-players")) {
            try {
                clickPermitted.add(UUID.fromString(uuidStr));
            } catch (IllegalArgumentException ignored) {
            }
        }

        getLogger().info("Battle attachment plugin enabled!");
    }

    @Override
    public void onDisable() {
        AbilityManager.setBattleModeActive(false);
        if (gameManager != null) {
            gameManager.stopGame();
        }
        if (teamManager != null) {
            teamManager.cleanup();
        }
        getConfig().set("click-permitted-players", clickPermitted.stream().map(UUID::toString).toList());
        saveConfig();
        instance = null;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPlayerSwapHandItemsLowest(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();

        if (!player.isSneaking()) return;
        if (teamManager == null || !teamManager.isTeamModeEnabled() || !teamManager.isInitialized()) return;

        if (gameManager != null && gameManager.isGameRunning() && gameManager.isReleased()) return;

        event.setCancelled(true);
        Inventory gui = teamManager.createTeamGUI(player);
        if (gui != null) {
            player.openInventory(gui);
        }
    }

    @EventHandler
    public void onTeamInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (gameManager == null || teamManager == null) return;

        String title = event.getView().getTitle();
        if (!title.startsWith("§8[§6队伍选择§8]")) return;

        event.setCancelled(true);

        if (!teamManager.isInitialized()) return;

        Inventory clicked = event.getClickedInventory();
        if (clicked == null) return;
        if (!clicked.equals(event.getInventory())) return;

        int slot = event.getSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        teamManager.handleTeamGUIClick(player, event.getInventory(), slot);
    }

    @EventHandler
    public void onTeamModeInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (gameManager == null || teamManager == null) return;

        String title = event.getView().getTitle();
        if (!title.startsWith("§8[§6组队模式§8]")) return;

        event.setCancelled(true);

        Inventory clicked = event.getClickedInventory();
        if (clicked == null) return;
        if (!clicked.equals(event.getInventory())) return;

        int slot = event.getSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return;

        if (teamManager.handleTeamModeGUIClick(player, event.getInventory(), slot)) {
            gameManager.refreshLobbyHolograms();
        }
    }

    @EventHandler
    public void onTeamInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        String title = event.getView().getTitle();
        if (title.startsWith("§8[§6队伍选择§8]") || title.startsWith("§8[§6组队模式§8]")) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent event) {
        if (gameManager != null && gameManager.isResetInProgress()) {
            event.disallow(PlayerLoginEvent.Result.KICK_OTHER, "§6[大逃杀]\n§c广告位招租\n§e请稍候重新加入！");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (gameManager == null) return;
        if (gameManager.isGameRunning()) {
            if (gameManager.isParticipant(player)) {
                gameManager.respawnAsParticipant(player);
            } else {
                player.setGameMode(GameMode.SPECTATOR);
                if (AbilityManager.getAbility(player) != null) {
                    AbilityManager.removeAbility(player);
                }
                player.sendMessage("§6[大逃杀] §c游戏已经开始，你已自动切换为旁观模式!");
            }
        } else {
            gameManager.teleportToLobby(player);
        }

        if (teamManager != null && teamManager.isTeamModeEnabled() && teamManager.isInitialized()) {
            TeamManager.TeamColor color = teamManager.getPlayerTeam(player.getUniqueId());
            if (color != null) {
                teamManager.updatePlayerListName(player);
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        if (gameManager == null) return;

        if (gameManager.isGameRunning() && gameManager.isAbilityMasterMode()) {
            Location loc = abilityMasterManager.getRespawnLocation();
            if (loc != null) {
                event.setRespawnLocation(loc);
            }
            abilityMasterManager.applyRespawnEffects(player);
            Bukkit.getScheduler().runTask(this, () -> {
                AbilityType ability = AbilityManager.getAbility(player);
                if (ability != null) {
                    AbilityManager.removeAbilityEffectsOnly(player, ability);
                    AbilityManager.applyAbilityEffects(player, ability);
                }
            });
            return;
        }

        if (!gameManager.isGameRunning()) {
            if (AbilityManager.getAbility(player) != null) {
                AbilityManager.removeAbility(player);
            }
            Bukkit.getScheduler().runTask(this, () -> gameManager.teleportToLobby(player));
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (gameManager != null && gameManager.isGameRunning()) {
            if (gameManager.isAbilityMasterMode()) {
                event.setDeathMessage(null);
            }
            gameManager.onParticipantDeath(player);
        }
    }

    @EventHandler
    public void onLobbyButtonClick(PlayerInteractAtEntityEvent event) {
        if (event.getHand() != org.bukkit.inventory.EquipmentSlot.HAND) return;
        if (!(event.getRightClicked() instanceof ArmorStand stand)) return;
        if (gameManager == null || gameManager.isGameRunning()) return;

        Player player = event.getPlayer();
        World lobbyWorld = gameManager.getLobbyWorld();
        if (lobbyWorld == null || !player.getWorld().equals(lobbyWorld)) return;

        if (!player.isOp() && !clickPermitted.contains(player.getUniqueId())) {
            player.sendMessage("§6[大逃杀] §c你没有权限使用此按钮!");
            return;
        }

        String name = stand.getCustomName();
        if (name == null) return;

        event.setCancelled(true);

        if (name.contains("同队同出生点")) {
            if (teamManager == null) return;
            teamManager.setSameSpawn(!teamManager.isSameSpawn());
            String s = teamManager.isSameSpawn() ? "§a已开启" : "§c已关闭";
            player.sendMessage("§6[大逃杀] §e同队同出生点" + s);
            gameManager.refreshLobbyHolograms();
        } else if (name.contains("特殊模式")) {
            gameManager.cycleNextMode();
            BattleGameManager.GameModeType mode = gameManager.getCurrentMode();
            player.sendMessage("§6[大逃杀] §e模式已切换: §6" + mode.getDisplayName());
            gameManager.refreshLobbyHolograms();
        } else if (name.contains("随机分队")) {
            if (teamManager == null) return;
            if (teamManager.getMode() == TeamManager.TeamMode.SOLO) {
                player.sendMessage("§6[大逃杀] §c个人战模式下无法分队! 请先点击§e[切换组队]§c选择队伍模式");
                return;
            }
            List<UUID> playerIds = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getGameMode() == GameMode.SURVIVAL || p.getGameMode() == GameMode.ADVENTURE) {
                    playerIds.add(p.getUniqueId());
                }
            }
            if (!teamManager.isInitialized()) {
                teamManager.initializeTeams(playerIds.size());
            }
            teamManager.setRandomAssign(true);
            teamManager.randomAssignTeams(playerIds);
            teamManager.broadcastTeamDisplay();
            player.sendMessage("§6[大逃杀] §a已随机分队!");
        } else if (name.contains("切换组队")) {
            if (teamManager == null) return;
            Inventory gui = teamManager.createTeamModeGUI();
            if (gui != null) player.openInventory(gui);
        } else if (name.contains("友伤")) {
            if (teamManager == null) return;
            teamManager.setFriendlyFire(!teamManager.isFriendlyFire());
            String s = teamManager.isFriendlyFire() ? "§a已开启" : "§c已关闭";
            player.sendMessage("§6[大逃杀] §e友伤" + s);
            gameManager.refreshLobbyHolograms();
        } else if (name.contains("超能力大师")) {
            if (abilityMasterManager == null) return;
            abilityMasterManager.setActive(!abilityMasterManager.isActive());
            String status = abilityMasterManager.isActive() ? "§a已开启" : "§c已关闭";
            player.sendMessage("§6[大逃杀] §e超能力大师模式" + status);
            Bukkit.broadcastMessage("§6[大逃杀] §e超能力大师模式" + status);
            gameManager.refreshLobbyHolograms();
        } else if (name.contains("重置世界")) {
            gameManager.resetWorlds();
        } else if (name.contains("开始游戏")) {
            if (gameManager.isGameRunning()) {
                player.sendMessage("§6[大逃杀] §c游戏已在运行!");
                return;
            }
            gameManager.startGame(gameManager.getCurrentMode());
            Bukkit.broadcastMessage("§6[大逃杀] §a大逃杀已启动!");
        } else if (name.contains("本局旁观")) {
            if (player.getGameMode() == GameMode.SPECTATOR) {
                player.setGameMode(GameMode.ADVENTURE);
                player.sendMessage("§6[大逃杀] §a你已切换为游玩模式，下次游戏将正常参与");
                return;
            }
            if (gameManager.isGameRunning() && gameManager.isParticipant(player)) {
                gameManager.removeParticipant(player);
            }
            player.setGameMode(GameMode.SPECTATOR);
            if (AbilityManager.getAbility(player) != null) {
                AbilityManager.removeAbility(player);
            }
            player.sendMessage("§6[大逃杀] §a你已切换为旁观模式，本局游戏将不会参与");
        }
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (gameManager == null || !gameManager.isGameRunning()
            || !gameManager.isAbilityMasterMode()
            || !gameManager.isParticipant(victim)) return;

        Player damager = null;
        if (event.getDamager() instanceof Player p) {
            damager = p;
        } else if (event.getDamager() instanceof org.bukkit.entity.Projectile projectile
            && projectile.getShooter() instanceof Player p) {
            damager = p;
        } else {
            UUID ownerId = AbilityManager.getEntityOwner(event.getDamager());
            if (ownerId != null) {
                Player owner = Bukkit.getPlayer(ownerId);
                if (owner != null && gameManager.isParticipant(owner)) {
                    damager = owner;
                }
            }
        }

        if (damager != null) {
            gameManager.setLastDamager(victim.getUniqueId(), damager.getUniqueId());
        } else {
            gameManager.removeLastDamager(victim.getUniqueId());
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (gameManager != null && gameManager.isGameRunning()
            && gameManager.isParticipant(player)
            && !gameManager.isReleased()) {
            if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (gameManager != null && gameManager.isGameRunning()
            && gameManager.isParticipant(player)
            && !gameManager.isReleased()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (gameManager != null && gameManager.isGameRunning()
            && gameManager.isParticipant(player)
            && !gameManager.isReleased()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage().trim();

        if (gameManager == null || !gameManager.isGameRunning()
            || !gameManager.isParticipant(player)) return;

        if (gameManager.isAbilityMasterMode() && gameManager.isReleased()
            && (message.equalsIgnoreCase("roll") || message.equalsIgnoreCase("刷新"))) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask(this, () -> {
                abilityMasterManager.tryMasterReroll(player);
            });
            return;
        }

        if (gameManager.isConfirmed(player.getUniqueId())) return;

        if (message.equals("1") || message.equals("2") || message.equals("3")) {
            event.setCancelled(true);
            int choice = Integer.parseInt(message);
            Bukkit.getScheduler().runTask(this, () -> {
                gameManager.selectAbility(player, choice);
            });
        } else if (message.equalsIgnoreCase("ok") || message.equalsIgnoreCase("确认") || message.equalsIgnoreCase("好")) {
            event.setCancelled(true);
            UUID uuid = player.getUniqueId();
            Bukkit.getScheduler().runTask(this, () -> {
                gameManager.confirmPlayer(uuid);
            });
        }
    }

    public static Main getInstance() {
        return instance;
    }

    public BattleGameManager getGameManager() {
        return gameManager;
    }

    public RerollManager getRerollManager() {
        return rerollManager;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }

    public Set<UUID> getClickPermitted() {
        return clickPermitted;
    }
}
