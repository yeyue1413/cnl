package com.cnl.battle;

import com.cnl.abilities.AbilityManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.*;

public class TeamManager {

    public enum TeamMode {
        SOLO(1, false),
        DUO(2, false),
        TRIO(3, false),
        QUAD(4, false),
        HALF(0, true);

        private final int teamSize;
        private final boolean isHalf;

        TeamMode(int teamSize, boolean isHalf) {
            this.teamSize = teamSize;
            this.isHalf = isHalf;
        }

        public int getTeamSize() { return teamSize; }
        public boolean isHalf() { return isHalf; }
        public boolean isTeamMode() { return this != SOLO; }
    }

    public enum TeamColor {
        RED("红队", ChatColor.RED, Material.RED_DYE, "§c"),
        BLUE("蓝队", ChatColor.BLUE, Material.BLUE_DYE, "§9"),
        GREEN("绿队", ChatColor.GREEN, Material.GREEN_DYE, "§a"),
        YELLOW("黄队", ChatColor.YELLOW, Material.YELLOW_DYE, "§e"),
        AQUA("青队", ChatColor.AQUA, Material.LIGHT_BLUE_DYE, "§b"),
        PINK("粉队", ChatColor.LIGHT_PURPLE, Material.PINK_DYE, "§d"),
        WHITE("白队", ChatColor.WHITE, Material.WHITE_DYE, "§f"),
        GRAY("灰队", ChatColor.GRAY, Material.GRAY_DYE, "§8");

        private final String displayName;
        private final ChatColor chatColor;
        private final Material dyeMaterial;
        private final String colorCode;

        TeamColor(String displayName, ChatColor chatColor, Material dyeMaterial, String colorCode) {
            this.displayName = displayName;
            this.chatColor = chatColor;
            this.dyeMaterial = dyeMaterial;
            this.colorCode = colorCode;
        }

        public String getDisplayName() { return displayName; }
        public ChatColor getChatColor() { return chatColor; }
        public Material getDyeMaterial() { return dyeMaterial; }
        public String getColorCode() { return colorCode; }
    }

    private static final String TEAM_PREFIX = "battle_team_";

    private TeamMode mode = TeamMode.SOLO;
    private boolean randomAssign = false;
    private boolean sameSpawn = true;
    private boolean friendlyFire = false;
    private final Map<UUID, TeamColor> playerTeam = new HashMap<>();
    private final Map<TeamColor, Set<UUID>> teams = new LinkedHashMap<>();
    private boolean initialized = false;
    private final Main plugin;
    private Scoreboard scoreboard;

    public TeamManager(Main plugin) {
        this.plugin = plugin;
        this.scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
    }

    public void setMode(TeamMode mode) {
        this.mode = mode;
        if (!mode.isTeamMode()) {
            randomAssign = false;
        }
    }

    public TeamMode getMode() { return mode; }

    public void cycleTeamMode() {
        TeamMode[] modes = TeamMode.values();
        int next = (mode.ordinal() + 1) % modes.length;
        setMode(modes[next]);
        cleanup();
    }

    public String getTeamModeDisplayName() {
        return switch (mode) {
            case SOLO -> "个人战";
            case DUO -> "2人一队";
            case TRIO -> "3人一队";
            case QUAD -> "4人一队";
            case HALF -> "对半(红蓝)";
        };
    }

    public void setRandomAssign(boolean random) {
        this.randomAssign = random;
    }

    public boolean isRandomAssign() { return randomAssign; }

    public void setSameSpawn(boolean sameSpawn) {
        this.sameSpawn = sameSpawn;
    }

    public boolean isSameSpawn() {
        return sameSpawn;
    }

    public void setFriendlyFire(boolean friendlyFire) {
        this.friendlyFire = friendlyFire;
        for (TeamColor color : TeamColor.values()) {
            Team team = scoreboard.getTeam(TEAM_PREFIX + color.name().toLowerCase());
            if (team != null) {
                team.setAllowFriendlyFire(friendlyFire);
            }
        }
    }

    public boolean isFriendlyFire() {
        return friendlyFire;
    }

    public boolean isTeamMode() { return mode.isTeamMode(); }

    public boolean isInitialized() { return initialized; }

    public void initializeTeams(int playerCount) {
        cleanup();

        if (!mode.isTeamMode()) return;

        List<TeamColor> availableColors;

        if (mode.isHalf()) {
            availableColors = Arrays.asList(TeamColor.RED, TeamColor.BLUE);
        } else {
            int teamsNeeded = Math.max(1, (int) Math.ceil((double) playerCount / mode.getTeamSize()));
            TeamColor[] all = TeamColor.values();
            teamsNeeded = Math.min(teamsNeeded, all.length);
            availableColors = new ArrayList<>();
            for (int i = 0; i < teamsNeeded; i++) {
                availableColors.add(all[i]);
            }
        }

        for (TeamColor color : availableColors) {
            teams.put(color, new HashSet<>());
            createScoreboardTeam(color);
        }

        initialized = true;
    }

    public void autoAssignRemaining(Collection<UUID> participantIds) {
        if (!initialized || !mode.isTeamMode()) return;

        List<UUID> unassigned = new ArrayList<>();
        for (UUID uuid : participantIds) {
            if (!playerTeam.containsKey(uuid)) {
                unassigned.add(uuid);
            }
        }
        if (unassigned.isEmpty()) return;

        List<TeamColor> colorList = new ArrayList<>(teams.keySet());
        if (colorList.isEmpty()) return;

        if (mode.isHalf()) {
            int half = unassigned.size() / 2;
            for (int i = 0; i < half; i++) {
                Player p = Bukkit.getPlayer(unassigned.get(i));
                if (p != null) assignToTeam(p, TeamColor.RED);
            }
            for (int i = half; i < unassigned.size(); i++) {
                Player p = Bukkit.getPlayer(unassigned.get(i));
                if (p != null) assignToTeam(p, TeamColor.BLUE);
            }
        } else {
            int colorIndex = 0;
            for (UUID uuid : unassigned) {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null) continue;
                TeamColor color = colorList.get(colorIndex % colorList.size());
                assignToTeam(p, color);
                colorIndex++;
            }
        }
    }

    private void createScoreboardTeam(TeamColor color) {
        Team existing = scoreboard.getTeam(TEAM_PREFIX + color.name().toLowerCase());
        if (existing != null) existing.unregister();

        Team team = scoreboard.registerNewTeam(TEAM_PREFIX + color.name().toLowerCase());
        team.setPrefix("");
        team.setColor(color.getChatColor());
        team.setAllowFriendlyFire(friendlyFire);
        team.setCanSeeFriendlyInvisibles(true);
    }

    public boolean assignToTeam(Player player, TeamColor color) {
        if (!initialized || !mode.isTeamMode()) return false;
        Set<UUID> members = teams.get(color);
        if (members == null) return false;

        TeamColor current = playerTeam.get(player.getUniqueId());
        if (current != null) {
            teams.get(current).remove(player.getUniqueId());
            removePlayerFromScoreboardTeam(player, current);
        }

        for (TeamColor c : TeamColor.values()) {
            player.removeScoreboardTag(TEAM_PREFIX + c.name().toLowerCase());
        }
        player.addScoreboardTag(TEAM_PREFIX + color.name().toLowerCase());

        playerTeam.put(player.getUniqueId(), color);
        members.add(player.getUniqueId());
        addPlayerToScoreboardTeam(player, color);

        updatePlayerListName(player);
        return true;
    }

    private void addPlayerToScoreboardTeam(Player player, TeamColor color) {
        Team team = scoreboard.getTeam(TEAM_PREFIX + color.name().toLowerCase());
        if (team != null) {
            team.addEntry(player.getName());
        }
    }

    private void removePlayerFromScoreboardTeam(Player player, TeamColor color) {
        Team team = scoreboard.getTeam(TEAM_PREFIX + color.name().toLowerCase());
        if (team != null) {
            team.removeEntry(player.getName());
        }
    }

    public void updatePlayerListName(Player player) {
        TeamColor color = playerTeam.get(player.getUniqueId());
        if (color == null) {
            player.setPlayerListName(null);
        } else {
            player.setPlayerListName(color.getColorCode() + "§l【" + color.getDisplayName() + "§l" + color.getColorCode() + "】§r " + color.getChatColor() + player.getName());
        }
    }

    public void setReadyCheckmark(Player player, boolean ready) {
        TeamColor color = playerTeam.get(player.getUniqueId());
        if (color == null) return;
        if (ready) {
            player.setPlayerListName(color.getColorCode() + "§l【" + color.getDisplayName() + "§l" + color.getColorCode() + "】§r " + color.getChatColor() + player.getName() + " §a✔");
        } else {
            updatePlayerListName(player);
        }
    }

    public void randomAssignTeams(Collection<UUID> participantIds) {
        if (!initialized || !mode.isTeamMode()) return;

        List<UUID> shuffled = new ArrayList<>(participantIds);
        Collections.shuffle(shuffled, new Random());

        List<TeamColor> colorList = new ArrayList<>(teams.keySet());
        if (colorList.isEmpty()) return;

        if (mode.isHalf()) {
            int half = shuffled.size() / 2;
            for (int i = 0; i < half; i++) {
                Player p = Bukkit.getPlayer(shuffled.get(i));
                if (p != null) assignToTeam(p, TeamColor.RED);
            }
            for (int i = half; i < shuffled.size(); i++) {
                Player p = Bukkit.getPlayer(shuffled.get(i));
                if (p != null) assignToTeam(p, TeamColor.BLUE);
            }
        } else {
            int colorIndex = 0;
            for (UUID uuid : shuffled) {
                Player p = Bukkit.getPlayer(uuid);
                if (p == null) continue;
                TeamColor color = colorList.get(colorIndex % colorList.size());
                assignToTeam(p, color);
                colorIndex++;
            }
        }
    }

    public void randomAssignPlayer(Player player) {
        if (!initialized || !mode.isTeamMode()) return;

        List<TeamColor> colorList = new ArrayList<>(teams.keySet());
        if (colorList.isEmpty()) return;

        TeamColor current = playerTeam.get(player.getUniqueId());
        if (current != null) {
            teams.get(current).remove(player.getUniqueId());
            removePlayerFromScoreboardTeam(player, current);
        }

        List<TeamColor> available = new ArrayList<>();
        if (mode.isHalf()) {
            Set<UUID> redMembers = teams.get(TeamColor.RED);
            Set<UUID> blueMembers = teams.get(TeamColor.BLUE);
            int redCount = redMembers != null ? redMembers.size() : 0;
            int blueCount = blueMembers != null ? blueMembers.size() : 0;
            available.add(redCount <= blueCount ? TeamColor.RED : TeamColor.BLUE);
        } else {
            for (TeamColor color : colorList) {
                Set<UUID> members = teams.get(color);
                if (members == null || members.size() < mode.getTeamSize()) {
                    available.add(color);
                }
            }
            if (available.isEmpty()) {
                available.addAll(colorList);
            }
        }

        TeamColor chosen = available.get(new Random().nextInt(available.size()));
        assignToTeam(player, chosen);
    }

    public Inventory createTeamGUI(Player player) {
        if (!mode.isTeamMode()) return null;

        List<TeamColor> available = new ArrayList<>(teams.keySet());
        int size = Math.max(9, ((available.size() - 1) / 9 + 1) * 9);

        Inventory gui = Bukkit.createInventory(null, size, "§8[§6队伍选择§8] §7选择你的队伍");

        for (int i = 0; i < available.size() && i < size; i++) {
            TeamColor color = available.get(i);
            ItemStack dye = new ItemStack(color.getDyeMaterial());
            ItemMeta meta = dye.getItemMeta();
            meta.setDisplayName(color.getColorCode() + "§l" + color.getDisplayName());

            List<String> lore = new ArrayList<>();
            lore.add("§7点击加入" + color.getColorCode() + color.getDisplayName());
            lore.add("");

            Set<UUID> members = teams.get(color);
            int memberCount = members != null ? members.size() : 0;
            if (!mode.isHalf()) {
                lore.add("§7人数: §e" + memberCount + "§7/§e" + mode.getTeamSize());
            } else {
                lore.add("§7人数: §e" + memberCount);
            }
            lore.add("");
            lore.add("§7当前成员:");
            if (members != null && !members.isEmpty()) {
                for (UUID uuid : members) {
                    Player member = Bukkit.getPlayer(uuid);
                    if (member != null) {
                        lore.add(" §7- " + color.getColorCode() + member.getName());
                    }
                }
            } else {
                lore.add(" §7暂无成员");
            }
            meta.setLore(lore);
            dye.setItemMeta(meta);
            gui.setItem(i, dye);
        }

        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.setDisplayName("§r");
        filler.setItemMeta(fillerMeta);
        for (int i = available.size(); i < size - 1; i++) {
            gui.setItem(i, filler.clone());
        }

        ItemStack randomItem = new ItemStack(Material.BARRIER);
        ItemMeta randomMeta = randomItem.getItemMeta();
        randomMeta.setDisplayName("§6§l随机分队");
        randomMeta.setLore(Arrays.asList("§7点击后随机分配到一个队伍", "§7如果你已加入队伍会退出当前队伍"));
        randomItem.setItemMeta(randomMeta);
        gui.setItem(size - 1, randomItem);

        return gui;
    }

    public boolean handleTeamGUIClick(Player player, Inventory inventory, int slot) {
        if (!initialized || !mode.isTeamMode()) return false;

        int size = inventory.getSize();
        if (slot == size - 1) {
            randomAssignPlayer(player);
            Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7已随机分配到" + getPlayerTeamDisplay(player.getUniqueId()));
            player.closeInventory();
            return true;
        }

        List<TeamColor> colors = new ArrayList<>(teams.keySet());
        if (slot < 0 || slot >= colors.size()) return false;

        TeamColor color = colors.get(slot);

        TeamColor current = playerTeam.get(player.getUniqueId());
        if (current == color) {
            player.sendMessage("§6[大逃杀] §c你已经在" + color.getColorCode() + color.getDisplayName() + "§c中了!");
            return true;
        }

        if (current != null) {
            Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7已退出" + current.getColorCode() + current.getDisplayName());
        }

        if (!mode.isHalf()) {
            Set<UUID> members = teams.get(color);
            if (members != null && members.size() >= mode.getTeamSize()) {
                player.sendMessage("§6[大逃杀] §c" + color.getColorCode() + color.getDisplayName() + " §c已满!");
                return true;
            }
        }

        assignToTeam(player, color);
        Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7已加入" + color.getColorCode() + color.getDisplayName());
        player.closeInventory();

        return true;
    }

    public TeamColor getPlayerTeam(UUID uuid) {
        return playerTeam.get(uuid);
    }

    public Set<UUID> getTeamMembers(TeamColor color) {
        return teams.getOrDefault(color, Collections.emptySet());
    }

    public Set<TeamColor> getActiveTeamColors() {
        return new LinkedHashSet<>(teams.keySet());
    }

    public boolean hasTeam(UUID uuid) {
        return playerTeam.containsKey(uuid);
    }

    public String getPlayerTeamDisplay(UUID uuid) {
        TeamColor color = playerTeam.get(uuid);
        if (color == null) return "§7无队伍";
        return color.getColorCode() + color.getDisplayName();
    }

    public void broadcastTeamDisplay() {
        for (TeamColor color : teams.keySet()) {
            Set<UUID> members = teams.get(color);
            if (members == null || members.isEmpty()) continue;
            StringBuilder sb = new StringBuilder();
            sb.append("§6[大逃杀] §e队伍 ").append(color.getColorCode()).append(color.getDisplayName()).append(" §7(").append(members.size()).append("人): ");
            int i = 0;
            for (UUID uuid : members) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) {
                    if (i > 0) sb.append("§7, ");
                    sb.append(color.getColorCode()).append(p.getName());
                    i++;
                }
            }
            Bukkit.broadcastMessage(sb.toString());
        }
    }

    public Inventory createTeamModeGUI() {
        TeamMode[] modes = TeamMode.values();
        Inventory gui = Bukkit.createInventory(null, 9, "§8[§6组队模式§8]");
        for (int i = 0; i < modes.length; i++) {
            ItemStack item = new ItemStack(getTeamModeMaterial(modes[i]));
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§6§l" + getTeamModeDisplayName(modes[i]));
            List<String> lore = new ArrayList<>();
            lore.add("§7点击选择此模式");
            if (this.mode == modes[i]) {
                lore.add("§a✓ 当前模式");
            }
            meta.setLore(lore);
            item.setItemMeta(meta);
            gui.setItem(i, item);
        }
        return gui;
    }

    public boolean handleTeamModeGUIClick(Player player, Inventory inventory, int slot) {
        TeamMode[] modes = TeamMode.values();
        if (slot < 0 || slot >= modes.length) return false;

        TeamMode selected = modes[slot];
        if (this.mode == selected) {
            player.sendMessage("§6[大逃杀] §c已经是此模式了!");
            return true;
        }
        setMode(selected);
        cleanup();
        player.sendMessage("§6[大逃杀] §a已切换至: §e" + getTeamModeDisplayName());
        player.closeInventory();
        return true;
    }

    private Material getTeamModeMaterial(TeamMode mode) {
        return switch (mode) {
            case SOLO -> Material.WHITE_DYE;
            case DUO -> Material.LIME_DYE;
            case TRIO -> Material.LIGHT_BLUE_DYE;
            case QUAD -> Material.PURPLE_DYE;
            case HALF -> Material.RED_DYE;
        };
    }

    private String getTeamModeDisplayName(TeamMode mode) {
        return switch (mode) {
            case SOLO -> "个人战";
            case DUO -> "2人一队";
            case TRIO -> "3人一队";
            case QUAD -> "4人一队";
            case HALF -> "对半(红蓝)";
        };
    }

    public boolean isTeamFull(TeamColor color) {
        if (mode.isHalf()) return false;
        Set<UUID> members = teams.get(color);
        return members != null && members.size() >= mode.getTeamSize();
    }

    public Set<TeamColor> getAliveTeams() {
        Set<TeamColor> alive = new HashSet<>();
        for (Map.Entry<TeamColor, Set<UUID>> entry : teams.entrySet()) {
            for (UUID uuid : entry.getValue()) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null && p.isOnline()) {
                    if (p.getGameMode() != GameMode.SPECTATOR) {
                        alive.add(entry.getKey());
                        break;
                    }
                    if (AbilityManager.isQuantumState(uuid)) {
                        alive.add(entry.getKey());
                        break;
                    }
                }
            }
        }
        return alive;
    }

    public boolean isOneTeamLeft() {
        if (!mode.isTeamMode()) return false;
        return getAliveTeams().size() <= 1;
    }

    public TeamColor getWinningTeam() {
        if (!mode.isTeamMode()) return null;
        Set<TeamColor> alive = getAliveTeams();
        if (alive.size() == 1) {
            return alive.iterator().next();
        }
        return null;
    }

    public boolean allTeamsHavePlayers() {
        for (Map.Entry<TeamColor, Set<UUID>> entry : teams.entrySet()) {
            if (entry.getValue().isEmpty()) return false;
        }
        return true;
    }

    public boolean allPlayersInTeam(Collection<UUID> participantIds) {
        for (UUID uuid : participantIds) {
            if (!playerTeam.containsKey(uuid)) return false;
        }
        return true;
    }

    public boolean isTeamModeEnabled() {
        return mode.isTeamMode();
    }

    public void setAllToAdventure() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            GameMode gm = player.getGameMode();
            if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
                boolean hadFlight = player.getAllowFlight();
                boolean wasFlying = player.isFlying();
                player.setGameMode(GameMode.ADVENTURE);
                if (hadFlight) {
                    player.setAllowFlight(true);
                    if (wasFlying) {
                        player.setFlying(true);
                    }
                }
            }
        }
    }

    public void cleanup() {
        for (TeamColor color : TeamColor.values()) {
            Team team = scoreboard.getTeam(TEAM_PREFIX + color.name().toLowerCase());
            if (team != null) {
                team.unregister();
            }
        }

        for (Map.Entry<UUID, TeamColor> entry : playerTeam.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            if (p != null) {
                p.setPlayerListName(null);
            }
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            GameMode gm = player.getGameMode();
            if (gm == GameMode.ADVENTURE) {
                boolean hadFlight = player.getAllowFlight();
                boolean wasFlying = player.isFlying();
                player.setGameMode(GameMode.SURVIVAL);
                if (hadFlight) {
                    player.setAllowFlight(true);
                    if (wasFlying) {
                        player.setFlying(true);
                    }
                }
            }
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            for (TeamColor c : TeamColor.values()) {
                player.removeScoreboardTag(TEAM_PREFIX + c.name().toLowerCase());
            }
        }

        playerTeam.clear();
        teams.clear();
        initialized = false;
    }
}
