package com.cnl.battle;

import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;

@SuppressWarnings("deprecation")
public class BattleGameManager {

    private static final String PARTICIPANT_TAG = "battle_participant";

    public enum GameModeType {
        NORMAL("普通模式"),
        ETERNAL_DAY("永昼模式"),
        ETERNAL_NIGHT("永夜模式");

        private final String displayName;
        GameModeType(String displayName) { this.displayName = displayName; }
        public String getDisplayName() { return displayName; }
    }

    private final Main plugin;
    private boolean gameRunning = false;
    private final Set<UUID> participants = new HashSet<>();
    private final Set<UUID> confirmedPlayers = new HashSet<>();
    private boolean allReleased = false;
    private BukkitTask countdownTask;
    private int countdownSecondsLeft = 0;
    private final Map<UUID, List<String>> playerAbilityHistory = new HashMap<>();
    private final Map<UUID, AbilityType[]> pendingAbilityChoices = new HashMap<>();
    private BukkitTask gameTask;
    private BukkitTask damageTask;
    private BossBar bossBar;
    private BukkitTask lobbySaturationTask;
    private RerollManager rerollManager;
    private TeamManager teamManager;
    private GameModeType currentMode = GameModeType.NORMAL;

    private int currentCircle = 0;
    private int gameTimeSeconds = 0;
    private boolean noSafeZone = false;
    private double currentMinY;

    private BattleConfig battleConfig;
    private CircleStage[] stages;
    private double centerX;
    private double centerZ;
    private AbilityMasterManager abilityMasterManager;
    private boolean resetInProgress = false;
    private double animatedBorderSize;
    private static final Random random = new Random();
    private static final int LOBBY_Y = 0;
    private static final int LOBBY_WALL_H = 6;
    private final Map<UUID, UUID> lastDamagerMap = new HashMap<>();
    private World lobbyWorld;
    private final List<ArmorStand> lobbyHolograms = new ArrayList<>();
    private final ArmorStand[] buttonStands = new ArmorStand[9];
    private boolean hologramsCreated = false;

    public BattleGameManager(Main plugin, BattleConfig battleConfig) {
        this.plugin = plugin;
        this.battleConfig = battleConfig;
        this.centerX = battleConfig.getCenterX();
        this.centerZ = battleConfig.getCenterZ();
        initStages();
        initLobbySaturation();
    }

    private void initStages() {
        BattleConfig.CircleStageData[] data = battleConfig.getStages();
        stages = new CircleStage[data.length];
        for (int i = 0; i < data.length; i++) {
            stages[i] = new CircleStage(data[i].stage, data[i].overworldSize, data[i].netherSize, data[i].stayTime, data[i].shrinkTime);
        }
    }

    private void initLobbySaturation() {
        lobbySaturationTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (!gameRunning) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.setFoodLevel(20);
                    player.setSaturation(5);
                }
            }
        }, 0L, 40L);
    }

    public void setRerollManager(RerollManager rerollManager) {
        this.rerollManager = rerollManager;
    }

    public void setTeamManager(TeamManager teamManager) {
        this.teamManager = teamManager;
    }

    public void setAbilityMasterManager(AbilityMasterManager manager) {
        this.abilityMasterManager = manager;
    }

    public boolean isAbilityMasterMode() {
        return abilityMasterManager != null && abilityMasterManager.isActive();
    }

    public double getCenterX() {
        return centerX;
    }

    public double getCenterZ() {
        return centerZ;
    }

    public double getInitialBorderSize() {
        return stages.length > 0 ? stages[0].overworldSize : 2000.0;
    }

    public TeamManager getTeamManager() {
        return teamManager;
    }

    public World getLobbyWorld() {
        return lobbyWorld;
    }

    public boolean isResetInProgress() {
        return resetInProgress;
    }

    public boolean isTeamMode() {
        return teamManager != null && teamManager.isTeamModeEnabled();
    }

    public boolean isGameRunning() {
        return gameRunning;
    }

    public boolean isParticipant(Player player) {
        return participants.contains(player.getUniqueId());
    }

    public boolean isConfirmed(UUID uuid) {
        return confirmedPlayers.contains(uuid);
    }

    public boolean isReleased() {
        return allReleased;
    }

    public Set<UUID> getParticipants() {
        return Collections.unmodifiableSet(participants);
    }

    public Map<UUID, List<String>> getPlayerAbilityHistory() {
        return playerAbilityHistory;
    }

    public int getGameTimeSeconds() {
        return gameTimeSeconds;
    }

    public GameModeType getCurrentMode() {
        return currentMode;
    }

    public void cycleNextMode() {
        switch (currentMode) {
            case NORMAL -> currentMode = GameModeType.ETERNAL_DAY;
            case ETERNAL_DAY -> currentMode = GameModeType.ETERNAL_NIGHT;
            case ETERNAL_NIGHT -> currentMode = GameModeType.NORMAL;
        }
    }

    public void confirmPlayer(UUID uuid) {
        if (allReleased) return;
        if (confirmedPlayers.contains(uuid)) return;

        confirmedPlayers.add(uuid);
        Player player = Bukkit.getPlayer(uuid);
        if (player != null && player.isOnline()) {
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setSaturation(5);
            player.setRemainingAir(player.getMaximumAir());
            if (teamManager != null && teamManager.isTeamModeEnabled()) {
                teamManager.setReadyCheckmark(player, true);
            } else {
                player.setPlayerListName(player.getName() + " §a\u2714");
            }
            player.sendMessage("§6[大逃杀] §a已确认！(" + confirmedPlayers.size() + "/" + participants.size() + ")");
        }

        checkAllConfirmed();
    }

    private void checkAllConfirmed() {
        if (allReleased) return;

        for (UUID id : participants) {
            if (!confirmedPlayers.contains(id)) return;
        }

        startReleaseCountdown();
    }

    private void startReleaseCountdown() {
        if (countdownTask != null) return;

        countdownSecondsLeft = 5;
        Bukkit.broadcastMessage("§6[大逃杀] §e所有玩家已就绪！§c" + countdownSecondsLeft + " §e秒后开始！");

        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            countdownSecondsLeft--;
            if (countdownSecondsLeft > 0 && countdownSecondsLeft <= 3) {
                Bukkit.broadcastMessage("§6[大逃杀] §c" + countdownSecondsLeft + "...");
            }
            if (bossBar != null) {
                bossBar.setTitle("§6[大逃杀] §e即将开始 §c" + countdownSecondsLeft + "s");
                bossBar.setProgress(countdownSecondsLeft / 5.0);
            }
            if (countdownSecondsLeft <= 0) {
                if (countdownTask != null) {
                    countdownTask.cancel();
                    countdownTask = null;
                }
                releaseAllPlayers();
            }
        }, 0L, 20L);
    }

    private void startQuickCountdown() {
        countdownSecondsLeft = 10;
        Bukkit.broadcastMessage("§6[大逃杀] §e§l超能力大师！");
        Bukkit.broadcastMessage("§6[大逃杀] §e击杀敌人获得随机超能力！");
        Bukkit.broadcastMessage("§6[大逃杀] §c" + countdownSecondsLeft + " §e秒后开始！");

        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            countdownSecondsLeft--;
            if (countdownSecondsLeft > 0 && countdownSecondsLeft <= 3) {
                Bukkit.broadcastMessage("§6[大逃杀] §c" + countdownSecondsLeft + "...");
            }
            if (bossBar != null) {
                bossBar.setTitle("§6[大逃杀] §e超能力大师 §c" + countdownSecondsLeft + "s");
                bossBar.setProgress(countdownSecondsLeft / 10.0);
            }
            if (countdownSecondsLeft <= 0) {
                if (countdownTask != null) {
                    countdownTask.cancel();
                    countdownTask = null;
                }
                applyGameMode();
                allReleased = true;
                Bukkit.broadcastMessage("§6[大逃杀] §a§l战斗开始！击杀敌人获取全新超能力！");
                if (bossBar != null) {
                    int firstSize = stages.length > 0 ? (int) stages[0].overworldSize : 2000;
                    String modeSuffix = currentMode != GameModeType.NORMAL ? " §7[" + currentMode.getDisplayName() + "§7]" : "";
                    bossBar.setTitle("§6[大逃杀] §e超能力大师 §e圈1 (§f" + firstSize + "§e)" + modeSuffix);
                    bossBar.setProgress(1.0);
                }
                for (UUID id : participants) {
                    Player player = Bukkit.getPlayer(id);
                    if (player == null || !player.isOnline()) continue;
                    preserveFlightOnModeChange(player, true);
                    player.setHealth(player.getMaxHealth());
                    player.setFoodLevel(20);
                    player.setSaturation(5);
                    player.setRemainingAir(player.getMaximumAir());
                    for (org.bukkit.potion.PotionEffect effect : new ArrayList<>(player.getActivePotionEffects())) {
                        player.removePotionEffect(effect.getType());
                    }
                    player.setInvulnerable(false);
                    player.sendMessage("§6[大逃杀] §a战斗开始！击杀敌人获取全新超能力！");
                }
            }
        }, 0L, 20L);
    }

    private static void preserveFlightOnModeChange(Player player, boolean toSurvival) {
        boolean hadFlight = player.getAllowFlight();
        boolean wasFlying = player.isFlying();
        if (toSurvival) {
            player.setGameMode(GameMode.SURVIVAL);
        } else {
            player.setGameMode(GameMode.ADVENTURE);
        }
        if (hadFlight) {
            player.setAllowFlight(true);
            if (wasFlying) {
                player.setFlying(true);
            }
        }
    }

    private void releaseAllPlayers() {
        applyGameMode();
        allReleased = true;
        Bukkit.broadcastMessage("§6[大逃杀] §a§l战斗开始！");

        if (bossBar != null) {
            String modeSuffix = currentMode != GameModeType.NORMAL ? " §7[" + currentMode.getDisplayName() + "§7]" : "";
            int firstSize = stages.length > 0 ? (int) stages[0].overworldSize : 2000;
            bossBar.setTitle("§6[大逃杀] §e圈1 (§f" + firstSize + "§e) §bY≥" + (int) currentMinY + modeSuffix);
            bossBar.setProgress(1.0);
        }

        for (UUID id : participants) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) continue;

            preserveFlightOnModeChange(player, true);
            player.setInvulnerable(false);
            player.setHealth(player.getMaxHealth());
            player.setFoodLevel(20);
            player.setSaturation(5);
            player.setRemainingAir(player.getMaximumAir());

            if (teamManager != null && teamManager.isTeamModeEnabled()) {
                teamManager.updatePlayerListName(player);
            } else {
                player.setPlayerListName(null);
            }
            player.sendMessage("§6[大逃杀] §a战斗开始！你可以自由行动了！");
        }
    }

    public void startGame() {
        startGame(GameModeType.NORMAL);
    }

    public void startGame(GameModeType forcedMode) {
        if (gameRunning) return;
        gameRunning = true;
        currentCircle = 0;
        gameTimeSeconds = 0;
        participants.clear();
        playerAbilityHistory.clear();
        confirmedPlayers.clear();
        allReleased = false;
        noSafeZone = false;
        currentMinY = getCircleYLevel(0);
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
        if (rerollManager != null) rerollManager.reset();
        if (abilityMasterManager != null) abilityMasterManager.reset();

        initStages();

        World overworld = Bukkit.getWorlds().get(0);
        World nether = Bukkit.getWorld("world_nether");
        World end = Bukkit.getWorld("world_the_end");

        for (Player player : Bukkit.getOnlinePlayers()) {
            GameMode gm = player.getGameMode();
            if (gm == GameMode.SURVIVAL || gm == GameMode.ADVENTURE) {
                participants.add(player.getUniqueId());
                player.addScoreboardTag(PARTICIPANT_TAG);
            }
        }

        if (participants.isEmpty()) {
            gameRunning = false;
            Bukkit.broadcastMessage("§6[大逃杀] §c没有可参与的玩家!");
            return;
        }

        setParticipantsAdventure();

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.setFoodLevel(20);
            player.setSaturation(0);
        }

        if (teamManager != null && teamManager.isTeamModeEnabled()) {
            if (!teamManager.isInitialized()) {
                teamManager.initializeTeams(participants.size());
            }
            teamManager.autoAssignRemaining(participants);
            int assignedCount = 0;
            for (UUID uuid : participants) {
                if (teamManager.hasTeam(uuid)) assignedCount++;
            }
            Bukkit.broadcastMessage("§6[大逃杀] §e队伍已分配 (§a" + assignedCount + "§e/§a" + participants.size() + "§e)");
            for (UUID uuid : participants) {
                Player p = Bukkit.getPlayer(uuid);
                if (p != null) teamManager.updatePlayerListName(p);
            }
        }

        if (forcedMode == GameModeType.NORMAL) {
            if (random.nextDouble() < 0.1) {
                currentMode = random.nextBoolean() ? GameModeType.ETERNAL_DAY : GameModeType.ETERNAL_NIGHT;
            } else {
                currentMode = GameModeType.NORMAL;
            }
        } else {
            currentMode = forcedMode;
        }

        setupFirstCircle(overworld, nether, end);
        removeLobbyHolograms();

        teleportParticipants(overworld);

        if (isAbilityMasterMode()) {
            Bukkit.broadcastMessage("§6[大逃杀] §e§l\u2694 超能力大师模式！");
            Bukkit.broadcastMessage("§6[大逃杀] §e击杀敌人获得随机超能力，最后击杀数最高者获胜！");
            freezeTimeAtDay();
            assignAbilityRandomly();
            startBossBar();
            startQuickCountdown();
            gameTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickGame, 0L, 20L);
            damageTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> tickDamage(overworld, nether, end), 0L, 20L);
            return;
        }

        assignAbilities();

        freezeTimeAtDay();

        startBossBar();

        gameTask = Bukkit.getScheduler().runTaskTimer(plugin, this::tickGame, 0L, 20L);

        damageTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> tickDamage(overworld, nether, end), 0L, 20L);
    }

    private void applyGameMode() {
        World overworld = Bukkit.getWorlds().get(0);
        if (overworld == null) return;

        if (currentMode == GameModeType.NORMAL) {
            overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, true);
            overworld.setTime(0);
            return;
        }

        String modeName = currentMode.getDisplayName();
        Bukkit.broadcastMessage("§6[大逃杀] §e\u2726 §6§l特殊模式触发！");
        Bukkit.broadcastMessage("§6[大逃杀] §e本局游戏模式：§6§l" + modeName);

        if (currentMode == GameModeType.ETERNAL_DAY) {
            overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
            overworld.setTime(6000);
            Bukkit.broadcastMessage("§6[大逃杀] §e太阳将永远高悬，黑夜不会降临！");
        } else if (currentMode == GameModeType.ETERNAL_NIGHT) {
            overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
            overworld.setTime(18000);
            Bukkit.broadcastMessage("§6[大逃杀] §e月亮将永不落下，黑暗笼罩大地！");
        }
    }

    private void freezeTimeAtDay() {
        try {
            World overworld = Bukkit.getWorlds().get(0);
            if (overworld != null) {
                overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
                overworld.setTime(6000);
            }
        } catch (Exception ignored) {
        }
    }

    private void resetGameMode() {
        try {
            World overworld = Bukkit.getWorlds().get(0);
            if (overworld != null) {
                overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
                overworld.setTime(6000);
            }
        } catch (Exception ignored) {
        }
        currentMode = GameModeType.NORMAL;
    }

    public void stopGame() {
        if (!gameRunning) return;
        gameRunning = false;
        currentCircle = 0;
        gameTimeSeconds = 0;

        if (gameTask != null) {
            gameTask.cancel();
            gameTask = null;
        }
        if (damageTask != null) {
            damageTask.cancel();
            damageTask = null;
        }
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar = null;
        }
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }

        World overworld = Bukkit.getWorlds().get(0);
        if (overworld != null) {
            WorldBorder border = overworld.getWorldBorder();
            border.setSize(59999968);
            border.setDamageAmount(0.2);
            border.setDamageBuffer(5.0);
        }

        World nether = Bukkit.getWorld("world_nether");
        if (nether != null) {
            WorldBorder netherBorder = nether.getWorldBorder();
            netherBorder.setSize(250);
            netherBorder.setDamageAmount(0.2);
            netherBorder.setDamageBuffer(5.0);
        }

        for (UUID uuid : participants) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                player.removeScoreboardTag(PARTICIPANT_TAG);
                teleportToLobby(player);
            }
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!participants.contains(player.getUniqueId())) {
                teleportToLobby(player);
            }
        }

        participants.clear();
        confirmedPlayers.clear();
        allReleased = false;
        playerAbilityHistory.clear();
        pendingAbilityChoices.clear();
        lastDamagerMap.clear();
        if (rerollManager != null) rerollManager.reset();
        if (teamManager != null) teamManager.cleanup();
        resetGameMode();

        ensureLobbyHolograms();
    }

    public void forceWin(Player winner) {
        if (!gameRunning) return;
        if (!participants.contains(winner.getUniqueId())) return;

        showVictoryScreen(winner);

        for (UUID uuid : participants) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && !p.equals(winner)) {
                p.setGameMode(GameMode.SPECTATOR);
                p.removeScoreboardTag(PARTICIPANT_TAG);
            }
        }

        stopGame();
    }

    public void onParticipantDeath(Player player) {
        if (!participants.contains(player.getUniqueId())) return;

        if (isAbilityMasterMode()) {
            Player killer = getEffectiveKiller(player);
            boolean killedByPlayer = killer != null && participants.contains(killer.getUniqueId());
            if (killedByPlayer) {
                abilityMasterManager.onKill(killer, player);
            }
            abilityMasterManager.onDeath(player, killedByPlayer);
            return;
        }

        player.setGameMode(GameMode.SPECTATOR);
        player.removeScoreboardTag(PARTICIPANT_TAG);
        participants.remove(player.getUniqueId());
        confirmedPlayers.remove(player.getUniqueId());

        AbilityManager.removeAbility(player);

        if (teamManager != null && teamManager.isTeamModeEnabled()) {
            TeamManager.TeamColor teamColor = teamManager.getPlayerTeam(player.getUniqueId());
            String teamSuffix = teamColor != null ? " §7[" + teamColor.getColorCode() + teamColor.getDisplayName() + "§7]" : "";
            Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + teamSuffix + " §7已被淘汰！剩余 §e" + participants.size() + " §7人");
        } else {
            Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7已被淘汰！剩余 §e" + participants.size() + " §7人");
        }

        if (!allReleased) {
            checkAllConfirmed();
        }

        if (bossBar != null) {
            bossBar.removePlayer(player);
        }

        if (teamManager != null && teamManager.isTeamModeEnabled()) {
            if (teamManager.isOneTeamLeft()) {
                endTeamGameWithWinner();
            }
        } else if (participants.size() <= 1) {
            endGameWithWinner();
        }
    }

    public void respawnAsParticipant(Player player) {
        if (!participants.contains(player.getUniqueId())) return;

        if (!player.getScoreboardTags().contains(PARTICIPANT_TAG)) {
            player.addScoreboardTag(PARTICIPANT_TAG);
        }

        if (AbilityManager.getAbility(player) == null) {
            player.getInventory().clear();
            AbilityType randomAbility = AbilityManager.getRandomAbility();
            AbilityManager.setAbility(player, randomAbility);
            if (isAbilityMasterMode() && abilityMasterManager != null) {
                abilityMasterManager.recordUsedAbility(randomAbility.getDisplayName());
            }
            playerAbilityHistory.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>())
                .add(randomAbility.getDisplayName());
            player.sendMessage("§6[大逃杀] §a你重新获得了超能力: §e" + randomAbility.getDisplayId() + ". " + randomAbility.getDisplayName());
        } else if (allReleased) {
            AbilityType currentAbility = AbilityManager.getAbility(player);
            if (currentAbility == AbilityType.SUPERMAN || currentAbility == AbilityType.FAIRY) {
                player.setAllowFlight(true);
                if (currentAbility == AbilityType.FAIRY) {
                    player.setFlySpeed(0.05F);
                }
            }
        }

        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(5);
        player.setRemainingAir(player.getMaximumAir());

        if (allReleased) {
            preserveFlightOnModeChange(player, true);
            player.setInvulnerable(false);
        } else {
            preserveFlightOnModeChange(player, false);
            player.setInvulnerable(true);
        }

        if (bossBar != null) {
            bossBar.addPlayer(player);
        }

        player.sendMessage("§6[大逃杀] §a欢迎回来！你已重新加入游戏");
    }

    public void addSpectatorPlayer(Player player) {
        if (participants.contains(player.getUniqueId())) return;

        if (player.getScoreboardTags().contains("cnl_protected")) {
            player.removeScoreboardTag("cnl_protected");
        }

        AbilityManager.removeAbility(player);

        participants.add(player.getUniqueId());
        player.addScoreboardTag(PARTICIPANT_TAG);

        if (teamManager != null && teamManager.isTeamModeEnabled() && teamManager.isInitialized()) {
            if (!teamManager.hasTeam(player.getUniqueId())) {
                teamManager.randomAssignPlayer(player);
            }
            teamManager.updatePlayerListName(player);
        }

        player.getInventory().clear();
        player.getEnderChest().clear();

        AbilityType randomAbility = AbilityManager.getRandomAbility();
        AbilityManager.setAbility(player, randomAbility);
        playerAbilityHistory.computeIfAbsent(player.getUniqueId(), k -> new ArrayList<>())
            .add(randomAbility.getDisplayName());
        player.sendMessage("§6[大逃杀] §a你重新获得了超能力: §e" + randomAbility.getDisplayId() + ". " + randomAbility.getDisplayName());

        World world = Bukkit.getWorlds().get(0);
        if (world != null) {
            double borderSize = stages[0].overworldSize;
            double radius = borderSize / 2.0 - 10;
            if (radius <= 0) radius = 5;
            Location loc = findSafeLocation(world, radius);
            player.teleport(loc);
        }

        player.setInvulnerable(!allReleased);
        if (allReleased) {
            player.setGameMode(GameMode.SURVIVAL);
        } else {
            player.setGameMode(GameMode.ADVENTURE);
        }
        player.setAllowFlight(false);
        player.setFlying(false);

        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);

        if (bossBar != null) {
            bossBar.addPlayer(player);
        }

        Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7已重新加入战斗！");
    }

    public void removeParticipant(Player player) {
        UUID uuid = player.getUniqueId();
        if (participants.remove(uuid)) {
            player.removeScoreboardTag(PARTICIPANT_TAG);
            confirmedPlayers.remove(uuid);
            playerAbilityHistory.remove(uuid);
            pendingAbilityChoices.remove(uuid);
            lastDamagerMap.remove(uuid);
            if (bossBar != null) {
                bossBar.removePlayer(player);
            }
        }
    }

    public void readdParticipant(Player player) {
        if (!gameRunning) return;
        UUID uuid = player.getUniqueId();
        if (!participants.contains(uuid)) {
            participants.add(uuid);
            player.addScoreboardTag(PARTICIPANT_TAG);
            if (bossBar != null) {
                bossBar.addPlayer(player);
            }
        }
    }

    public void setLastDamager(UUID victim, UUID damager) {
        if (damager != null && !damager.equals(victim) && participants.contains(damager)) {
            lastDamagerMap.put(victim, damager);
        }
    }

    public void removeLastDamager(UUID victim) {
        lastDamagerMap.remove(victim);
    }

    public Player getEffectiveKiller(Player victim) {
        Player killer = victim.getKiller();
        if (killer != null) return killer;

        UUID damagerId = lastDamagerMap.remove(victim.getUniqueId());
        if (damagerId != null) {
            return Bukkit.getPlayer(damagerId);
        }

        UUID forcedId = AbilityManager.getForcedKiller(victim.getUniqueId());
        if (forcedId != null) {
            return Bukkit.getPlayer(forcedId);
        }
        return null;
    }

    public void teleportToLobby(Player player) {
        if (lobbyWorld == null) {
            initLobbyWorld();
        }
        if (lobbyWorld == null) return;

        ensureLobbyPlatform(lobbyWorld);

        try {
            World overworld = Bukkit.getWorlds().get(0);
            if (overworld != null) {
                overworld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
                overworld.setTime(6000);
            }
        } catch (Exception ignored) {
        }

        Location lobbyLoc = new Location(lobbyWorld, centerX, LOBBY_Y + 1, centerZ);
        player.setInvulnerable(true);
        player.teleport(lobbyLoc);
        player.setGameMode(GameMode.ADVENTURE);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(5);
        player.setRemainingAir(player.getMaximumAir());
        player.getInventory().clear();
        player.getEnderChest().clear();
        player.setFireTicks(0);

        if (AbilityManager.getAbility(player) != null) {
            AbilityManager.removeAbility(player);
        }

        ensureLobbyHolograms();
    }

    private void initLobbyWorld() {
        World existing = Bukkit.getWorld("battle_lobby");
        if (existing != null) {
            lobbyWorld = existing;
            return;
        }
        WorldCreator wc = new WorldCreator("battle_lobby");
        wc.generateStructures(false);
        wc.type(WorldType.FLAT);
        wc.generatorSettings("{\"layers\":[],\"biome\":\"minecraft:the_void\",\"structures\":{\"structures\":{}}}");
        lobbyWorld = Bukkit.createWorld(wc);
        if (lobbyWorld != null) {
            lobbyWorld.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
            lobbyWorld.setTime(6000);
            lobbyWorld.setGameRule(org.bukkit.GameRule.DO_WEATHER_CYCLE, false);
            lobbyWorld.setStorm(false);
            lobbyWorld.setGameRule(org.bukkit.GameRule.DO_MOB_SPAWNING, false);
            lobbyWorld.setGameRule(org.bukkit.GameRule.DO_FIRE_TICK, false);
            lobbyWorld.setGameRule(org.bukkit.GameRule.RANDOM_TICK_SPEED, 0);
        }
    }

    private void ensureLobbyPlatform(World world) {
        int bx = (int) Math.floor(centerX);
        int bz = (int) Math.floor(centerZ);

        if (world.getBlockAt(bx, LOBBY_Y, bz).getType() == Material.BEDROCK) return;

        int halfSize = 15;
        for (int dx = -halfSize; dx <= halfSize; dx++) {
            for (int dz = -halfSize; dz <= halfSize; dz++) {
                world.getBlockAt(bx + dx, LOBBY_Y, bz + dz).setType(Material.BEDROCK);
            }
        }

        for (int dy = 1; dy <= LOBBY_WALL_H; dy++) {
            for (int dx = -halfSize; dx <= halfSize; dx++) {
                for (int dz = -halfSize; dz <= halfSize; dz++) {
                    world.getBlockAt(bx + dx, LOBBY_Y + dy, bz + dz).setType(Material.AIR);
                }
            }
        }

        for (int dy = 1; dy <= LOBBY_WALL_H; dy++) {
            for (int dx = -halfSize; dx <= halfSize; dx++) {
                world.getBlockAt(bx + dx, LOBBY_Y + dy, bz - halfSize).setType(Material.BEDROCK);
                world.getBlockAt(bx + dx, LOBBY_Y + dy, bz + halfSize).setType(Material.BEDROCK);
            }
            for (int dz = -halfSize + 1; dz <= halfSize - 1; dz++) {
                world.getBlockAt(bx - halfSize, LOBBY_Y + dy, bz + dz).setType(Material.BEDROCK);
                world.getBlockAt(bx + halfSize, LOBBY_Y + dy, bz + dz).setType(Material.BEDROCK);
            }
        }
    }

    public void ensureLobbyHolograms() {
        if (hologramsCreated || lobbyWorld == null) return;
        hologramsCreated = true;

        int bx = (int) Math.floor(centerX);
        int bz = (int) Math.floor(centerZ);
        double hy = 3.0;
        double infoY = 4.5;
        int hs = 14;

        String[] btnTexts = getButtonTexts();
        int[] btnOffsets = {-10, -7, -4, -1, 2, 5, 8, 11, 14};
        for (int i = 0; i < 9; i++) {
            buttonStands[i] = spawnHoloText(lobbyWorld, bx + btnOffsets[i], hy, bz - hs, btnTexts[i], false);
        }

        spawnHoloText(lobbyWorld, bx, infoY, bz + hs, "§e作者：§fyue1413", true);
        spawnHoloText(lobbyWorld, bx, infoY - 0.5, bz + hs, "§e测试：§fyue1413 §f/buyantong §f/yuanyuanysy", true);
        spawnHoloText(lobbyWorld, bx, infoY - 1, bz + hs, "§e超能力设计灵感：§fyue1413 §f/buyantong §f/yuanyuanysy §f等", true);

        spawnHoloText(lobbyWorld, bx + hs, infoY + 1, bz, "§6§l✦ 更 新 公 告 ✦", true);
        spawnHoloText(lobbyWorld, bx + hs, infoY + 0.2, bz, "§e1. 更新了自定义按键系统", true);
        spawnHoloText(lobbyWorld, bx + hs, infoY - 0.3, bz, "§7可以自己设置技能按键了！", true);
        spawnHoloText(lobbyWorld, bx + hs, infoY - 0.8, bz, "§7什么，你没有？那快去装mod啊", true);
        spawnHoloText(lobbyWorld, bx + hs, infoY - 1.5, bz, "§e2. 更新了3选1系统", true);
        spawnHoloText(lobbyWorld, bx + hs, infoY - 2.0, bz, "§7终于不用考虑要不要roll一个了", true);
    }

    public void refreshLobbyHolograms() {
        if (!hologramsCreated || lobbyWorld == null) return;
        String[] texts = getButtonTexts();
        for (int i = 0; i < 9; i++) {
            if (buttonStands[i] != null) {
                buttonStands[i].setCustomName(texts[i]);
            }
        }
    }

    private String[] getButtonTexts() {
        return new String[]{
            "§a[ §e同队同出生点 §a] §7" + (teamManager != null && teamManager.isSameSpawn() ? "§a开" : "§c关"),
            "§a[ §e特殊模式 §a] §7" + currentMode.getDisplayName(),
            "§a[ §e随机分队 §a]" + (teamManager != null && teamManager.getMode() == TeamManager.TeamMode.SOLO ? " §c个人战不可用" : ""),
            "§a[ §e切换组队 §a] §7" + (teamManager != null ? teamManager.getTeamModeDisplayName() : ""),
            "§a[ §e开始游戏 §a]",
            "§a[ §e超能力大师 §a] §7" + (abilityMasterManager != null && abilityMasterManager.isActive() ? "§a开" : "§c关"),
            "§a[ §e重置世界 §a]",
            "§a[ §e友伤 §a] §7" + (teamManager != null && teamManager.isFriendlyFire() ? "§a开" : "§c关"),
            "§a[ §e本局旁观 §a]"
        };
    }

    private ArmorStand spawnHoloText(World world, double x, double y, double z, String text, boolean infoOnly) {
        ArmorStand stand = (ArmorStand) world.spawnEntity(new Location(world, x, y, z), EntityType.ARMOR_STAND);
        stand.setCustomNameVisible(true);
        stand.setCustomName(text);
        stand.setInvisible(true);
        stand.setGravity(false);
        stand.setAI(false);
        stand.setCanPickupItems(false);
        stand.setMarker(infoOnly);
        stand.setSilent(true);
        if (!infoOnly) {
            stand.setSmall(true);
        }
        lobbyHolograms.add(stand);
        return stand;
    }

    public void removeLobbyHolograms() {
        for (ArmorStand stand : lobbyHolograms) {
            stand.remove();
        }
        lobbyHolograms.clear();
        for (int i = 0; i < 9; i++) {
            buttonStands[i] = null;
        }
        hologramsCreated = false;
    }

    private void endGameWithWinner() {
        if (!gameRunning) return;

        if (participants.size() == 1) {
            UUID winnerId = participants.iterator().next();
            Player winner = Bukkit.getPlayer(winnerId);
            if (winner != null && winner.isOnline()) {
                showVictoryScreen(winner);
            }
        }

        stopGame();
    }

    private void endTeamGameWithWinner() {
        if (!gameRunning) return;
        if (teamManager == null) return;

        TeamManager.TeamColor winningTeam = teamManager.getWinningTeam();
        if (winningTeam == null) return;

        Set<UUID> members = teamManager.getTeamMembers(winningTeam);
        String teamName = winningTeam.getColorCode() + "§l" + winningTeam.getDisplayName();
        String playersInTeam = "";
        int count = 0;
        for (UUID uuid : members) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.getGameMode() != GameMode.SPECTATOR) {
                if (!playersInTeam.isEmpty()) playersInTeam += "§7, ";
                playersInTeam += winningTeam.getColorCode() + p.getName();
                count++;
            }
        }

        String winnerDisplay = teamName + "§r §6§l(" + count + "人)";

        Bukkit.broadcastMessage("§6[大逃杀] §e§l" + winnerDisplay + " §6§l赢得了本次大逃杀！恭喜！");
        if (!playersInTeam.isEmpty()) {
            Bukkit.broadcastMessage("§6[大逃杀] §e队伍成员: " + playersInTeam);
        }

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle("§6§l大逃杀结束", "§e§l获胜队伍: " + teamName, 10, 100, 20);
        }

        stopGame();
    }

    private void showVictoryScreen(Player winner) {
        String winnerName = winner.getName();
        Bukkit.broadcastMessage("§6[大逃杀] §e§l" + winnerName + " §6§l赢得了本次大逃杀！恭喜！");

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendTitle("§6§l大逃杀结束", "§e§l获胜者: §6§l" + winnerName, 10, 100, 20);
        }
    }

    private void setupFirstCircle(World overworld, World nether, World end) {
        animatedBorderSize = stages[0].overworldSize;

        if (overworld != null) {
            WorldBorder border = overworld.getWorldBorder();
            border.setCenter(centerX, centerZ);
            border.setSize(stages[0].overworldSize);
            border.setDamageAmount(0);
            border.setDamageBuffer(battleConfig.getCircleBuffer(0));
        }

        if (nether != null) {
            WorldBorder netherBorder = nether.getWorldBorder();
            netherBorder.setCenter(centerX, centerZ);
            netherBorder.setSize(stages[0].netherSize);
            netherBorder.setDamageAmount(0);
            netherBorder.setDamageBuffer(battleConfig.getCircleBuffer(0));
        }

        if (end != null) {
            WorldBorder endBorder = end.getWorldBorder();
            endBorder.setCenter(centerX, centerZ);
            endBorder.setSize(10);
            endBorder.setDamageAmount(10);
            endBorder.setDamageBuffer(0);
        }

        double radius = stages[0].overworldSize / 2.0;
        double nextRadius = stages[1].overworldSize / 2.0;
        stages[1].centerX = pickRandomCenter(centerX, radius - nextRadius);
        stages[1].centerZ = pickRandomCenter(centerZ, radius - nextRadius);
    }

    private double pickRandomCenter(double currentCenter, double maxOffset) {
        double offset = (random.nextDouble() * 2 - 1) * maxOffset;
        return currentCenter + offset;
    }

    private void teleportParticipants(World world) {
        if (teamManager != null && teamManager.isTeamModeEnabled() && teamManager.isInitialized() && teamManager.isSameSpawn()) {
            teleportParticipantsByTeam(world);
            return;
        }

        double borderSize = stages[0].overworldSize;
        double radius = borderSize / 2.0 - 10;
        if (radius <= 0) radius = 5;

        for (UUID uuid : participants) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) continue;

            Location loc = findSafeLocation(world, radius);
            player.setInvulnerable(true);
            player.teleport(loc);
            player.sendMessage("§6[大逃杀] §a你已被传送到安全区内!");
        }
    }

    private Location findSafeLocation(World world, double radius) {
        Location loc;
        int attempts = 0;
        do {
            double angle = random.nextDouble() * 2 * Math.PI;
            double distance = radius * (1 - random.nextDouble() * random.nextDouble());

            double x = centerX + distance * Math.cos(angle);
            double z = centerZ + distance * Math.sin(angle);

            int bx = (int) Math.floor(x);
            int bz = (int) Math.floor(z);
            world.getChunkAt(bx >> 4, bz >> 4);

            int y = world.getHighestBlockYAt(bx, bz);
            if (y < 0) y = 64;
            if (y > world.getMaxHeight() - 2) y = world.getMaxHeight() - 2;

            y = scanUpForSpace(world, bx, bz, y);

            loc = new Location(world, x, y + 1, z);
            attempts++;
        } while (attempts < 30 && (isLiquidLocation(loc) || isBelowLiquid(loc)));

        if (isLiquidLocation(loc) || isBelowLiquid(loc)) {
            int cx = (int) centerX;
            int cz = (int) centerZ;
            world.getChunkAt(cx >> 4, cz >> 4);
            int cy = world.getHighestBlockYAt(cx, cz);
            if (cy < 0) cy = 64;
            cy = scanUpForSpace(world, cx, cz, cy);
            loc = new Location(world, centerX, Math.max(cy + 1, 65), centerZ);
        }

        return loc;
    }

    private int scanUpForSpace(World world, int bx, int bz, int groundY) {
        int y = groundY;
        int maxY = world.getMaxHeight() - 2;
        while (y <= maxY) {
            if (!world.getBlockAt(bx, y + 1, bz).getType().isSolid()
                && !world.getBlockAt(bx, y + 2, bz).getType().isSolid()) {
                return y;
            }
            y++;
        }
        return groundY;
    }

    private boolean isBelowLiquid(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        Material below = loc.clone().add(0, -1, 0).getBlock().getType();
        return below == Material.WATER || below == Material.LAVA;
    }

    private void teleportParticipantsByTeam(World world) {
        double borderSize = stages[0].overworldSize;
        double radius = borderSize / 2.0 - 10;
        if (radius <= 0) radius = 5;

        double[][] spawnOffsets = {
            {0, 0}, {2, 0}, {0, 2}, {2, 2},
            {-2, 0}, {0, -2}, {-2, -2}, {2, -2},
            {-2, 2}, {0, -4}, {-4, 0}, {4, 0}
        };

        Set<TeamManager.TeamColor> teamColors = teamManager.getActiveTeamColors();

        for (TeamManager.TeamColor color : teamColors) {
            Set<UUID> members = teamManager.getTeamMembers(color);
            if (members.isEmpty()) continue;

            Location centerLoc = findSafeLocation(world, radius);
            int index = 0;

            for (UUID uuid : members) {
                Player player = Bukkit.getPlayer(uuid);
                if (player == null || !player.isOnline()) continue;
                if (!participants.contains(uuid)) continue;

                double ox = spawnOffsets[index % spawnOffsets.length][0];
                double oz = spawnOffsets[index % spawnOffsets.length][1];
                double px = centerLoc.getX() + ox;
                double pz = centerLoc.getZ() + oz;
                int pbx = (int) Math.floor(px);
                int pbz = (int) Math.floor(pz);
                world.getChunkAt(pbx >> 4, pbz >> 4);
                int py = world.getHighestBlockYAt(pbx, pbz);
                if (py < 0) py = 64;
                if (py > world.getMaxHeight() - 2) py = world.getMaxHeight() - 2;
                py = scanUpForSpace(world, pbx, pbz, py);
                Location loc = new Location(world, px, py + 1, pz);
                player.setInvulnerable(true);
                player.teleport(loc);
                player.sendMessage("§6[大逃杀] §a你和队友已传送到安全区内!");
                index++;
            }
        }
    }

    private boolean isLiquidLocation(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        Material standing = loc.getBlock().getType();
        Material head = loc.clone().add(0, 1, 0).getBlock().getType();
        return standing == Material.WATER || standing == Material.LAVA
            || standing == Material.KELP || standing == Material.KELP_PLANT
            || head == Material.WATER || head == Material.LAVA;
    }

    private void assignAbilityRandomly() {
        for (UUID uuid : participants) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) continue;

            player.getInventory().clear();
            player.getEnderChest().clear();
            player.setInvulnerable(true);

            AbilityType randomAbility = AbilityManager.getRandomAbility();
            AbilityManager.setAbility(player, randomAbility);
            playerAbilityHistory.computeIfAbsent(uuid, k -> new ArrayList<>())
                .add(randomAbility.getDisplayName());
            player.sendMessage("§6[大逃杀] §a你获得了超能力: §e" + randomAbility.getDisplayId() + ". " + randomAbility.getDisplayName());
        }

        Bukkit.broadcastMessage("§6[大逃杀] §e提示：刷新超能力会清空当前背包！所有玩家就绪后自动开始倒计时");
    }

    private void assignAbilities() {
        pendingAbilityChoices.clear();
        for (UUID uuid : participants) {
            Player player = Bukkit.getPlayer(uuid);
            if (player == null || !player.isOnline()) continue;

            player.getInventory().clear();
            player.getEnderChest().clear();
            player.setInvulnerable(true);

            AbilityType[] options = new AbilityType[3];
            for (int i = 0; i < 3; i++) {
                AbilityType candidate;
                int retries = 0;
                do {
                    candidate = AbilityManager.getRandomAbility();
                    retries++;
                } while (contains(options, i, candidate) && retries < 50);
                options[i] = candidate;
            }
            pendingAbilityChoices.put(uuid, options);

            player.sendMessage("§6[超能力选择] §e请选择一个超能力（聊天栏输入数字 1/2/3）：");
            player.sendMessage("§e1. §a" + options[0].getDisplayName() + (options[0].getDescription() != null ? " §7- " + options[0].getDescription() : ""));
            player.sendMessage("§e2. §a" + options[1].getDisplayName() + (options[1].getDescription() != null ? " §7- " + options[1].getDescription() : ""));
            player.sendMessage("§e3. §a" + options[2].getDisplayName() + (options[2].getDescription() != null ? " §7- " + options[2].getDescription() : ""));
        }

        Bukkit.broadcastMessage("§6[大逃杀] §e超能力已发放！请在聊天栏输入 1/2/3 选择你的超能力");
    }

    private boolean contains(AbilityType[] arr, int len, AbilityType target) {
        for (int i = 0; i < len; i++) {
            if (arr[i] == target) return true;
        }
        return false;
    }

    public void selectAbility(Player player, int choice) {
        UUID uuid = player.getUniqueId();
        if (allReleased) return;
        if (confirmedPlayers.contains(uuid)) return;
        if (!pendingAbilityChoices.containsKey(uuid)) return;
        if (choice < 1 || choice > 3) {
            player.sendMessage("§6[大逃杀] §c请输入 1, 2 或 3 选择超能力!");
            return;
        }

        AbilityType[] options = pendingAbilityChoices.remove(uuid);
        AbilityType selected = options[choice - 1];

        AbilityManager.setAbility(player, selected);
        playerAbilityHistory.computeIfAbsent(uuid, k -> new ArrayList<>())
            .add(selected.getDisplayName());
        player.sendMessage("§6[大逃杀] §a你选择了超能力: §e" + selected.getDisplayId() + ". " + selected.getDisplayName());

        confirmPlayer(uuid);
    }

    private void setParticipantsAdventure() {
        for (UUID id : participants) {
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                player.setGameMode(GameMode.ADVENTURE);
                player.setAllowFlight(false);
                player.setFlying(false);
            }
        }
    }

    private void startBossBar() {
        if (bossBar != null) {
            bossBar.removeAll();
        }
        bossBar = Bukkit.createBossBar(
            "§6[大逃杀] §e等待所有玩家确认...",
            BarColor.YELLOW,
            BarStyle.SOLID
        );
        for (UUID uuid : participants) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null && player.isOnline()) {
                bossBar.addPlayer(player);
            }
        }
        bossBar.setVisible(true);
        bossBar.setProgress(1.0);
    }

    private void tickGame() {
        if (!gameRunning || !allReleased) return;
        if (noSafeZone) return;
        gameTimeSeconds++;

        if (currentCircle >= stages.length) return;

        CircleStage stage = stages[currentCircle];

        if (gameTimeSeconds < stage.stayTime) {
            int remaining = stage.stayTime - gameTimeSeconds;
            updateBossBar(remaining, stage, false);
            if (remaining == 30 || remaining == 10) {
                Bukkit.broadcastMessage("§6[大逃杀] §e" + remaining + "秒后开始缩圈!");
            }
            return;
        }

        int shrinkElapsed = gameTimeSeconds - stage.stayTime;
        if (shrinkElapsed <= 0) return;

        if (shrinkElapsed == 1 && stage.shrinkTime > 0) {
            startShrink(stage);
        }

        if (stage.shrinkTime > 0 && shrinkElapsed <= stage.shrinkTime) {
            double progress = (double) shrinkElapsed / stage.shrinkTime;
            double targetSize = currentCircle + 1 < stages.length ? stages[currentCircle + 1].overworldSize : 1;
            animatedBorderSize = stage.overworldSize + (targetSize - stage.overworldSize) * progress;
            int remaining = stage.shrinkTime - shrinkElapsed;
            updateBossBar(remaining, stage, true);
            World overworld = Bukkit.getWorlds().get(0);
            if (overworld != null) {
                overworld.getWorldBorder().setSize(Math.max(1, animatedBorderSize));
            }
            World nether = Bukkit.getWorld("world_nether");
            if (nether != null) {
                nether.getWorldBorder().setSize(Math.max(1, animatedBorderSize / 8.0));
            }
        }

        if (shrinkElapsed >= stage.shrinkTime) {
            if (currentCircle + 1 < stages.length) {
                int expectedTotal = stage.stayTime + stage.shrinkTime;
                if (gameTimeSeconds < expectedTotal) return;
                currentCircle++;
                gameTimeSeconds = 0;
                currentMinY = getCircleYLevel(currentCircle);
                CircleStage enteredStage = stages[currentCircle];
                animatedBorderSize = enteredStage.overworldSize;
                updateBorderDamage(currentCircle);
                Bukkit.broadcastMessage("§6[大逃杀] §e圈 " + (currentCircle + 1) + " - " + (int) enteredStage.overworldSize + " 格");

                if (bossBar != null) {
                    String modeSuffix = currentMode != GameModeType.NORMAL ? " §7[" + currentMode.getDisplayName() + "§7]" : "";
                    bossBar.setTitle("§6[大逃杀] §e圈 " + (currentCircle + 1) + " (§f" + (int) enteredStage.overworldSize + "§e) §bY≥" + (int) currentMinY + modeSuffix);
                    bossBar.setProgress(1.0);
                }

                if (currentCircle < stages.length - 1) {
                    double currentRadius = enteredStage.overworldSize / 2.0;
                    double nextR = stages[currentCircle + 1].overworldSize / 2.0;
                    stages[currentCircle + 1].centerX = pickRandomCenter(enteredStage.centerX, currentRadius - nextR);
                    stages[currentCircle + 1].centerZ = pickRandomCenter(enteredStage.centerZ, currentRadius - nextR);
                }
            } else {
                int expectedTotal = stage.stayTime + stage.shrinkTime;
                if (gameTimeSeconds < expectedTotal) return;
                noSafeZone = true;
                Bukkit.broadcastMessage("§6[大逃杀] §c§l安全区已完全消失！所有人都将受到持续伤害！");
                if (bossBar != null) {
                    bossBar.setTitle("§6[大逃杀] §c§l无安全区!");
                    bossBar.setProgress(0);
                }
            }
        }
    }

    private void startShrink(CircleStage stage) {
        World overworld = Bukkit.getWorlds().get(0);
        World nether = Bukkit.getWorld("world_nether");

        if (currentCircle + 1 < stages.length) {
            CircleStage nextStage = stages[currentCircle + 1];

            if (overworld != null) {
                WorldBorder border = overworld.getWorldBorder();
                border.setCenter(nextStage.centerX, nextStage.centerZ);
            }

            if (nether != null) {
                WorldBorder netherBorder = nether.getWorldBorder();
                netherBorder.setCenter(nextStage.centerX, nextStage.centerZ);
            }

            int nextSize = (int) nextStage.overworldSize;
            int curSize = (int) stage.overworldSize;
            Bukkit.broadcastMessage("§6[大逃杀] §c缩圈: " + curSize + " \u2192 " + nextSize);
        } else {
            CircleStage lastStage = stages[currentCircle];
            int nextSize = (int) lastStage.overworldSize;
            Bukkit.broadcastMessage("§6[大逃杀] §c最终缩圈: " + nextSize + " \u2192 0");
        }
    }

    private void updateBorderDamage(int circleIndex) {
        World overworld = Bukkit.getWorlds().get(0);
        if (overworld != null) {
            WorldBorder border = overworld.getWorldBorder();
            border.setDamageAmount(0);
            border.setDamageBuffer(battleConfig.getCircleBuffer(circleIndex));
        }

        World nether = Bukkit.getWorld("world_nether");
        if (nether != null) {
            WorldBorder netherBorder = nether.getWorldBorder();
            netherBorder.setDamageAmount(0);
            netherBorder.setDamageBuffer(battleConfig.getCircleBuffer(circleIndex));
        }
    }

    private void tickDamage(World overworld, World nether, World end) {
        if (!gameRunning) return;

        if (noSafeZone) {
            if (isAbilityMasterMode()) {
                if (!gameRunning) return;
                Player winner = abilityMasterManager.getWinner();
                if (winner != null) {
                    int kills = abilityMasterManager.getKillCount(winner.getUniqueId());
                    Bukkit.broadcastMessage("§6[大逃杀] §e§l" + winner.getName() + " §6§l以 §e" + kills + " §6§l次击杀赢得超能力大师赛！");
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        p.sendTitle("§6§l比赛结束", "§e§l" + winner.getName() + " §6§l获胜！击杀: §e" + kills, 10, 100, 20);
                    }
                }
                stopGame();
                return;
            }

            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!participants.contains(player.getUniqueId())) continue;
                player.damage(8.0);
                player.sendActionBar("§c§l安全区已消失！持续受到伤害！");
            }
            return;
        }

        if (!allReleased) return;

        int nextIndex = currentCircle + 1;
        boolean hasNextCircle = nextIndex < stages.length && nextIndex > 0;

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!participants.contains(player.getUniqueId())) continue;

            World playerWorld = player.getWorld();

            if (end != null && playerWorld.equals(end)) {
                player.damage(10.0);
                player.sendMessage("§c[大逃杀] §4末地禁止进入！持续扣血！");
                continue;
            }

            if (nether != null && playerWorld.equals(nether)) {
                if (currentCircle >= 4) {
                    player.damage(5.0);
                    player.sendMessage("§c[大逃杀] §4最后阶段！请返回主世界！");
                }
                continue;
            }

            if (overworld != null && playerWorld.equals(overworld)) {
                WorldBorder border = overworld.getWorldBorder();
                double borderSize = animatedBorderSize / 2.0;
                double dx = Math.abs(player.getLocation().getX() - border.getCenter().getX());
                double dz = Math.abs(player.getLocation().getZ() - border.getCenter().getZ());
                double buffer = battleConfig.getCircleBuffer(currentCircle);
                double damage = battleConfig.getCircleDamage(currentCircle);

                if (dx > borderSize + buffer || dz > borderSize + buffer) {
                    player.damage(damage);
                }

                if (dx > borderSize + buffer + 10 || dz > borderSize + buffer + 10) {
                    player.damage(battleConfig.getOverLimitPenalty(currentCircle));
                    player.sendMessage("§c[大逃杀] §4超出边界过远！受到额外伤害！");
                }

                double playerY = player.getLocation().getY();
                if (playerY < currentMinY) {
                    player.damage(battleConfig.getCircleDamage(currentCircle));
                    player.sendActionBar("§c§l地面上升中！你在 §e" + (int) playerY + " §c格，安全高度 §e" + (int) currentMinY + " §c格！");
                } else if (hasNextCircle) {
                    CircleStage nextStage = stages[nextIndex];
                    double half = nextStage.overworldSize / 2.0;
                    double ndx = Math.abs(player.getLocation().getX() - nextStage.centerX) - half;
                    double ndz = Math.abs(player.getLocation().getZ() - nextStage.centerZ) - half;
                    double outside;
                    if (ndx <= 0 && ndz <= 0) {
                        outside = 0;
                    } else if (ndx <= 0) {
                        outside = ndz;
                    } else if (ndz <= 0) {
                        outside = ndx;
                    } else {
                        outside = Math.sqrt(ndx * ndx + ndz * ndz);
                    }

                    if (outside > 0) {
                        player.sendActionBar("§c§l距离安全区: " + (int) outside + " 格");
                    }
                }
            }
        }
    }

    private void updateBossBar(int remaining, CircleStage stage, boolean shrinking) {
        if (bossBar == null) return;

        double totalTime = shrinking ? stage.shrinkTime : stage.stayTime;
        double progress = totalTime > 0 ? (double) remaining / totalTime : 0;
        if (progress < 0) progress = 0;
        bossBar.setProgress(progress);

        String action = shrinking ? "缩圈中" : "停留中";
        int nextSize = currentCircle + 1 < stages.length ? (int) stages[currentCircle + 1].overworldSize : (int) stages[currentCircle].overworldSize;
        String modeSuffix = currentMode != GameModeType.NORMAL ? " §7[" + currentMode.getDisplayName() + "§7]" : "";
        bossBar.setTitle("§6[大逃杀] §e圈 " + (currentCircle + 1) + " " + action + " §c" + remaining + "秒 §7(" + (int) stage.overworldSize + "\u2192" + nextSize + ") §bY≥" + (int) currentMinY + modeSuffix);
    }

    public void forceNextCircle() {
        if (!gameRunning) return;
        if (currentCircle >= stages.length - 1) {
            if (!noSafeZone) {
                noSafeZone = true;
                World overworld = Bukkit.getWorlds().get(0);
                if (overworld != null) overworld.getWorldBorder().setSize(0);
                World nether = Bukkit.getWorld("world_nether");
                if (nether != null) nether.getWorldBorder().setSize(0);
                Bukkit.broadcastMessage("§6[大逃杀] §c§l安全区已完全消失！所有人都将受到持续伤害！");
                if (bossBar != null) {
                    bossBar.setTitle("§6[大逃杀] §c§l无安全区!");
                    bossBar.setProgress(0);
                }
            } else {
                Bukkit.broadcastMessage("§6[大逃杀] §e已经没有安全区了!");
            }
            return;
        }

        int nextIndex = currentCircle + 1;
        CircleStage targetStage = stages[nextIndex];

        World overworld = Bukkit.getWorlds().get(0);
        if (overworld != null) {
            WorldBorder border = overworld.getWorldBorder();
            border.setCenter(targetStage.centerX, targetStage.centerZ);
            border.setSize(targetStage.overworldSize);
            border.setDamageAmount(0);
            border.setDamageBuffer(battleConfig.getCircleBuffer(nextIndex));
        }

        World nether = Bukkit.getWorld("world_nether");
        if (nether != null) {
            WorldBorder netherBorder = nether.getWorldBorder();
            netherBorder.setCenter(targetStage.centerX, targetStage.centerZ);
            netherBorder.setSize(targetStage.netherSize);
            netherBorder.setDamageAmount(0);
            netherBorder.setDamageBuffer(battleConfig.getCircleBuffer(nextIndex));
        }

        currentCircle = nextIndex;
        gameTimeSeconds = 0;
        currentMinY = getCircleYLevel(currentCircle);

        Bukkit.broadcastMessage("§6[大逃杀] §e[测试] 强制进入圈 " + (currentCircle + 1) + " - " + (int) targetStage.overworldSize + " 格");

        if (currentCircle < stages.length - 1) {
            double currentRadius = targetStage.overworldSize / 2.0;
            double nextR = stages[currentCircle + 1].overworldSize / 2.0;
            stages[currentCircle + 1].centerX = pickRandomCenter(targetStage.centerX, currentRadius - nextR);
            stages[currentCircle + 1].centerZ = pickRandomCenter(targetStage.centerZ, currentRadius - nextR);
        }

        if (bossBar != null) {
            String modeSuffix = currentMode != GameModeType.NORMAL ? " §7[" + currentMode.getDisplayName() + "§7]" : "";
            bossBar.setTitle("§6[大逃杀] §e圈 " + (currentCircle + 1) + " (§f" + (int) targetStage.overworldSize + "§e) §bY≥" + (int) currentMinY + modeSuffix);
            bossBar.setProgress(1.0);
        }

        if (currentCircle >= stages.length - 1) {
            Bukkit.broadcastMessage("§6[大逃杀] §e所有缩圈完成！最终对决！");
            if (bossBar != null) {
                bossBar.setTitle("§6[大逃杀] §c最终对决!");
                bossBar.setProgress(1.0);
            }
        }
    }

    public void forceShrink() {
        if (!gameRunning) return;
        if (currentCircle >= stages.length - 1) {
            if (!noSafeZone) {
                noSafeZone = true;
                World overworld = Bukkit.getWorlds().get(0);
                if (overworld != null) overworld.getWorldBorder().setSize(0);
                World nether = Bukkit.getWorld("world_nether");
                if (nether != null) nether.getWorldBorder().setSize(0);
                Bukkit.broadcastMessage("§6[大逃杀] §e[测试] 跳过最终缩圈，安全区已完全消失!");
                if (bossBar != null) {
                    bossBar.setTitle("§6[大逃杀] §c§l无安全区!");
                    bossBar.setProgress(0);
                }
            } else {
                Bukkit.broadcastMessage("§6[大逃杀] §e已经是最后一个圈了!");
            }
            return;
        }
        CircleStage stage = stages[currentCircle];
        if (gameTimeSeconds < stage.stayTime) {
            gameTimeSeconds = stage.stayTime;
            Bukkit.broadcastMessage("§6[大逃杀] §e[测试] 跳过停留，开始缩圈!");
        } else {
            Bukkit.broadcastMessage("§6[大逃杀] §e已经在缩圈中了!");
        }
    }

    public void startSolo(Player player) {
        if (gameRunning) return;
        startGame(GameModeType.NORMAL);
    }

    public boolean resetWorlds() {
        resetInProgress = true;
        Bukkit.broadcastMessage("§6[大逃杀] §c§l地图重置中...");

        stopGame();
        removeLobbyHolograms();

        if (teamManager != null) {
            teamManager.cleanup();
        }

        for (World w : Bukkit.getWorlds()) {
            try { w.setAutoSave(false); } catch (Exception ignored) {}
        }

        Bukkit.savePlayers();

        for (Player player : Bukkit.getOnlinePlayers()) {
            player.kickPlayer("§6[大逃杀]\n§e广告位招租\n§e请稍候重新加入！");
        }

        String[][] worldsToReset = {
            {"world", null},
            {"world_nether", "NETHER"},
            {"battle_lobby", null}
        };

        File serverDir = Bukkit.getWorldContainer();

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (String[] entry : worldsToReset) {
                String worldName = entry[0];
                World world = Bukkit.getWorld(worldName);
                if (world != null) {
                    try { world.save(); } catch (Exception ignored) {}
                    Bukkit.unloadWorld(world, false);
                }
            }

            for (String[] entry : worldsToReset) {
                String worldName = entry[0];
                File worldFolder = new File(serverDir, worldName);
                if (worldFolder.exists()) {
                    deleteDirectory(worldFolder);
                    plugin.getLogger().info("已删除世界文件夹: " + worldName);
                }
            }

            Bukkit.broadcastMessage("§6[大逃杀] §a世界文件已删除！正在重启服务器...");
            try {
                new File(plugin.getDataFolder().getParentFile().getParentFile(), "restart.flag").createNewFile();
            } catch (Exception ignored) {}
            Bukkit.getServer().shutdown();
        }, 20L);

        return true;
    }

    private boolean deleteDirectory(File dir) {
        if (dir == null || !dir.exists()) return true;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    deleteDirectory(file);
                } else {
                    file.delete();
                }
            }
        }
        return dir.delete();
    }

    public int getCurrentCircle() {
        return currentCircle;
    }

    private double getCircleYLevel(int circleIndex) {
        int totalSteps = stages.length - 1;
        if (totalSteps <= 0) return battleConfig.getEndY();
        double progress = Math.min(1.0, (double) circleIndex / totalSteps);
        return battleConfig.getStartY() + (battleConfig.getEndY() - battleConfig.getStartY()) * progress;
    }

    CircleStage getCircleStage(int index) {
        if (index >= 0 && index < stages.length) {
            return stages[index];
        }
        return null;
    }

    private static class CircleStage {
        final int circleNumber;
        final double overworldSize;
        final double netherSize;
        final int stayTime;
        final int shrinkTime;
        double centerX;
        double centerZ;

        CircleStage(int circleNumber, double overworldSize, double netherSize, int stayTime, int shrinkTime) {
            this.circleNumber = circleNumber;
            this.overworldSize = overworldSize;
            this.netherSize = netherSize;
            this.stayTime = stayTime;
            this.shrinkTime = shrinkTime;
            this.centerX = 0;
            this.centerZ = 0;
        }
    }
}
