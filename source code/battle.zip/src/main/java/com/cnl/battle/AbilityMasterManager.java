package com.cnl.battle;

import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;

import java.util.*;

public class AbilityMasterManager {

    private boolean active = false;
    private final Main plugin;
    private BattleGameManager gameManager;
    private final Map<UUID, Integer> killCounts = new HashMap<>();
    private final Map<UUID, Integer> deathsWithCurrentAbility = new HashMap<>();
    private final Set<UUID> canReroll = new HashSet<>();
    private final Set<UUID> hasUsedAbility = new HashSet<>();
    private final Set<AbilityType> usedAbilities = new HashSet<>();

    public AbilityMasterManager(Main plugin, BattleGameManager gameManager) {
        this.plugin = plugin;
        this.gameManager = gameManager;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void reset() {
        killCounts.clear();
        deathsWithCurrentAbility.clear();
        canReroll.clear();
        hasUsedAbility.clear();
        usedAbilities.clear();
    }

    public int getKillCount(UUID uuid) {
        return killCounts.getOrDefault(uuid, 0);
    }

    public Map<UUID, Integer> getKillCounts() {
        return killCounts;
    }

    public boolean hasUsedAbility(UUID uuid) {
        return hasUsedAbility.contains(uuid);
    }

    public void recordUsedAbility(String abilityName) {
        if (abilityName != null && !abilityName.isEmpty()) {
            for (AbilityType type : AbilityType.values()) {
                if (type.getDisplayName().equals(abilityName)) {
                    usedAbilities.add(type);
                    break;
                }
            }
        }
    }

    public void onKill(Player killer, Player victim) {
        int kills = killCounts.merge(killer.getUniqueId(), 1, Integer::sum);
        deathsWithCurrentAbility.put(killer.getUniqueId(), 0);
        canReroll.remove(killer.getUniqueId());

        if (!hasUsedAbility.contains(killer.getUniqueId())) {
            hasUsedAbility.add(killer.getUniqueId());
        }

        AbilityType currentAbility = AbilityManager.getAbility(killer);
        String displayName = currentAbility != null ? currentAbility.getDisplayName() : "";
        AbilityType newAbility = getRandomUnusedAbility(displayName);
        AbilityManager.setAbility(killer, newAbility);
        killer.sendMessage("§6[大逃杀] §a你获得了新超能力: §e" + newAbility.getDisplayId() + ". " + newAbility.getDisplayName());
        killer.sendMessage("§6[大逃杀] §a当前击杀数: §e" + kills);

        Bukkit.broadcastMessage("§6[大逃杀] §e" + killer.getName() + " §7击杀 §e" + victim.getName() + " §7获得超能力！");

        updateTabLeader();
    }

    public void onDeath(Player player, boolean killedByPlayer) {
        if (!killedByPlayer) return;

        int deaths = deathsWithCurrentAbility.merge(player.getUniqueId(), 1, Integer::sum);

        if (deaths >= 3) {
            canReroll.add(player.getUniqueId());
            player.sendMessage("§6[大逃杀] §c§l你已被玩家击杀3次没有反杀！输入 §eroll §c§l刷新超能力！");
        }
    }

    public boolean tryMasterReroll(Player player) {
        if (!canReroll.contains(player.getUniqueId())) {
            player.sendMessage("§6[大逃杀] §c你没有可用的刷新次数！（连续死亡3次无击杀才可刷新）");
            return false;
        }

        AbilityType currentAbility = AbilityManager.getAbility(player);
        String currentName = currentAbility != null ? currentAbility.getDisplayName() : "";
        AbilityType newAbility = getRandomUnusedAbility(currentName);
        AbilityManager.setAbility(player, newAbility);
        player.getInventory().clear();
        deathsWithCurrentAbility.put(player.getUniqueId(), 0);
        canReroll.remove(player.getUniqueId());

        player.sendMessage("§6[大逃杀] §a你已刷新超能力: §e" + newAbility.getDisplayId() + ". " + newAbility.getDisplayName());
        Bukkit.broadcastMessage("§6[大逃杀] §e" + player.getName() + " §7刷新了超能力！");
        return true;
    }

    public Location getRespawnLocation() {
        World world = Bukkit.getWorlds().get(0);
        if (world == null) return null;

        WorldBorder border = world.getWorldBorder();
        Location center = border.getCenter();
        double borderSize = border.getSize();
        double radius = borderSize / 2.0 - 10;
        if (radius <= 0) radius = 5;

        Location loc;
        int attempts = 0;
        Random rand = new Random();
        do {
            double angle = rand.nextDouble() * 2 * Math.PI;
            double distance = radius * (1 - rand.nextDouble() * rand.nextDouble());
            double x = center.getX() + distance * Math.cos(angle);
            double z = center.getZ() + distance * Math.sin(angle);
            int bx = (int) Math.floor(x);
            int bz = (int) Math.floor(z);
            world.getChunkAt(bx >> 4, bz >> 4);
            int y = world.getHighestBlockYAt(bx, bz);
            if (y < 0) y = 64;
            if (y > world.getMaxHeight() - 2) y = world.getMaxHeight() - 2;
            loc = new Location(world, x, y + 1, z);
            attempts++;
        } while (attempts < 30 && isLiquid(loc));

        if (isLiquid(loc)) {
            int cx = (int) center.getX();
            int cz = (int) center.getZ();
            world.getChunkAt(cx >> 4, cz >> 4);
            int cy = world.getHighestBlockYAt(cx, cz);
            if (cy < 0) cy = 64;
            loc = new Location(world, center.getX(), Math.max(cy + 1, 65), center.getZ());
        }

        return loc;
    }

    public void applyRespawnEffects(Player player) {
        player.setInvulnerable(true);
        player.setHealth(player.getMaxHealth());
        player.setFoodLevel(20);
        player.setSaturation(5);
        player.setRemainingAir(player.getMaximumAir());

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            player.setInvulnerable(false);
        }, 100L);
    }

    public void respawnPlayer(Player player) {
        Location loc = getRespawnLocation();
        if (loc == null) return;
        player.teleport(loc);
        applyRespawnEffects(player);
    }

    public Player getWinner() {
        Player winner = null;
        int mostKills = -1;

        if (killCounts.isEmpty()) {
            for (UUID uuid : gameManager.getParticipants()) {
                Player player = Bukkit.getPlayer(uuid);
                if (player != null && player.isOnline()) {
                    winner = player;
                    break;
                }
            }
            return winner;
        }

        for (Map.Entry<UUID, Integer> entry : killCounts.entrySet()) {
            if (entry.getValue() > mostKills) {
                mostKills = entry.getValue();
                winner = Bukkit.getPlayer(entry.getKey());
            }
        }
        return winner != null && winner.isOnline() ? winner : null;
    }

    public String getLeaderDisplay() {
        Player leader = getWinner();
        if (leader == null) return "";
        return " §6[" + killCounts.getOrDefault(leader.getUniqueId(), 0) + "击杀]";
    }

    public void updateTabLeader() {
        String leaderSuffix = getLeaderDisplay();
        if (leaderSuffix.isEmpty()) return;

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (gameManager.getParticipants().contains(player.getUniqueId())) {
                UUID uuid = player.getUniqueId();
                Player leader = getWinner();
                if (leader != null && uuid.equals(leader.getUniqueId())) {
                    player.setPlayerListName(player.getName() + leaderSuffix);
                } else {
                    player.setPlayerListName(player.getName());
                }
            }
        }
    }

    private AbilityType getRandomUnusedAbility(String excludeAbilityName) {
        if (usedAbilities.size() >= AbilityType.values().length - 2) {
            usedAbilities.clear();
        }

        List<AbilityType> available = new ArrayList<>();
        for (AbilityType type : AbilityType.values()) {
            if (type == AbilityType.NONE || type == AbilityType.DAMAGE_TELEPORT) continue;
            if (type.getDisplayName().equals(excludeAbilityName)) continue;
            if (!usedAbilities.contains(type)) {
                available.add(type);
            }
        }

        if (available.isEmpty()) {
            usedAbilities.clear();
            for (AbilityType type : AbilityType.values()) {
                if (type == AbilityType.NONE || type == AbilityType.DAMAGE_TELEPORT) continue;
                if (type.getDisplayName().equals(excludeAbilityName)) continue;
                available.add(type);
            }
        }

        AbilityType chosen = available.get(new Random().nextInt(available.size()));
        usedAbilities.add(chosen);
        return chosen;
    }

    private boolean isLiquid(Location loc) {
        if (loc == null || loc.getWorld() == null) return false;
        Material standing = loc.getBlock().getType();
        Material head = loc.clone().add(0, 1, 0).getBlock().getType();
        Material below = loc.clone().add(0, -1, 0).getBlock().getType();
        return standing == Material.WATER || standing == Material.LAVA
            || standing == Material.KELP || standing == Material.KELP_PLANT
            || head == Material.WATER || head == Material.LAVA
            || below == Material.WATER || below == Material.LAVA;
    }
}
