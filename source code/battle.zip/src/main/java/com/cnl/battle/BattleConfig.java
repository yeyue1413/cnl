package com.cnl.battle;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class BattleConfig {

    private final double centerX;
    private final double centerZ;
    private final CircleStageData[] stages;
    private final double[] circleDamage;
    private final double[] circleBuffer;
    private final double[] overLimitPenalties;
    private final double startY;
    private final double endY;
    private final double yDamage;

    public BattleConfig(FileConfiguration config) {
        this.centerX = config.getDouble("center.x", 0.0);
        this.centerZ = config.getDouble("center.z", 0.0);

        List<?> rawCircles = config.getList("circles", new ArrayList<>());
        this.stages = new CircleStageData[rawCircles.size()];
        for (int i = 0; i < rawCircles.size(); i++) {
            Map<?, ?> section = (Map<?, ?>) rawCircles.get(i);
            int stage = ((Number) section.get("stage")).intValue();
            double overworldSize = ((Number) section.get("overworld_size")).doubleValue();
            double netherSize = ((Number) section.get("nether_size")).doubleValue();
            int stayTime = ((Number) section.get("stay_time")).intValue();
            int shrinkTime = ((Number) section.get("shrink_time")).intValue();
            stages[i] = new CircleStageData(stage, overworldSize, netherSize, stayTime, shrinkTime);
        }

        List<Double> rawDamage = config.getDoubleList("circle_damage");
        this.circleDamage = new double[rawDamage.size()];
        for (int i = 0; i < rawDamage.size(); i++) {
            circleDamage[i] = rawDamage.get(i);
        }

        List<Integer> rawBuffer = config.getIntegerList("circle_buffer");
        this.circleBuffer = new double[rawBuffer.size()];
        for (int i = 0; i < rawBuffer.size(); i++) {
            circleBuffer[i] = rawBuffer.get(i);
        }

        List<Double> rawPenalties = config.getDoubleList("over_limit_penalties");
        this.overLimitPenalties = new double[rawPenalties.size()];
        for (int i = 0; i < rawPenalties.size(); i++) {
            overLimitPenalties[i] = rawPenalties.get(i);
        }

        this.startY = config.getDouble("y_rise.start_y", -64.0);
        this.endY = config.getDouble("y_rise.end_y", 64.0);
        this.yDamage = config.getDouble("y_rise.y_damage", 2.0);
    }

    public double getCenterX() {
        return centerX;
    }

    public double getCenterZ() {
        return centerZ;
    }

    public int getStageCount() {
        return stages.length;
    }

    public CircleStageData getStage(int index) {
        if (index >= 0 && index < stages.length) {
            return stages[index];
        }
        return null;
    }

    public CircleStageData[] getStages() {
        return stages;
    }

    public double getCircleDamage(int circleIndex) {
        int idx = Math.min(circleIndex, circleDamage.length - 1);
        if (idx < 0) return 1.0;
        return circleDamage[idx];
    }

    public double getCircleBuffer(int circleIndex) {
        int idx = Math.min(circleIndex, circleBuffer.length - 1);
        if (idx < 0) return 5.0;
        return circleBuffer[idx];
    }

    public double getOverLimitPenalty(int circleIndex) {
        int idx = Math.min(circleIndex, overLimitPenalties.length - 1);
        if (idx < 0) return 1.0;
        return overLimitPenalties[idx];
    }

    public double getStartY() {
        return startY;
    }

    public double getEndY() {
        return endY;
    }

    public double getYDamage() {
        return yDamage;
    }

    public static class CircleStageData {
        final int stage;
        final double overworldSize;
        final double netherSize;
        final int stayTime;
        final int shrinkTime;

        CircleStageData(int stage, double overworldSize, double netherSize, int stayTime, int shrinkTime) {
            this.stage = stage;
            this.overworldSize = overworldSize;
            this.netherSize = netherSize;
            this.stayTime = stayTime;
            this.shrinkTime = shrinkTime;
        }
    }
}
