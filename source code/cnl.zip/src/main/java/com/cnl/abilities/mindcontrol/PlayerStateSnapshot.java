

package com.cnl.abilities.mindcontrol;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class PlayerStateSnapshot {
    private final Location location;
    private final GameMode gameMode;
    private final boolean allowFlight;
    private final boolean flying;
    private final float walkSpeed;
    private final float flySpeed;
    private final boolean collidable;

    public PlayerStateSnapshot(Player player) {
        this.location = player.getLocation().clone();
        this.gameMode = player.getGameMode();
        this.allowFlight = player.getAllowFlight();
        this.flying = player.isFlying();
        this.walkSpeed = player.getWalkSpeed();
        this.flySpeed = player.getFlySpeed();
        this.collidable = player.isCollidable();
    }

    public void restore(Player player) {
        player.setWalkSpeed(this.walkSpeed);
        player.setFlySpeed(this.flySpeed);
        player.setAllowFlight(this.allowFlight);
        player.setFlying(this.flying && this.allowFlight);
        player.setCollidable(this.collidable);
        player.setGameMode(this.gameMode);
        player.teleport(this.location);
    }

    public Location getLocation() {
        return this.location;
    }

    public GameMode getGameMode() {
        return this.gameMode;
    }

    public boolean isAllowFlight() {
        return this.allowFlight;
    }

    public boolean isFlying() {
        return this.flying;
    }

    public float getWalkSpeed() {
        return this.walkSpeed;
    }

    public float getFlySpeed() {
        return this.flySpeed;
    }

    public boolean isCollidable() {
        return this.collidable;
    }
}
