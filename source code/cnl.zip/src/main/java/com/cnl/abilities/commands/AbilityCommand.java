

package com.cnl.abilities.commands;

import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

public class AbilityCommand implements CommandExecutor, TabCompleter {
    public AbilityCommand() {
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player) {
                Player player = (Player)sender;
                this.showAbility(player, player);
            } else {
                sender.sendMessage("§6[超能力] §c请指定玩家!");
            }

            return true;
        } else {
            switch (args[0].toLowerCase()) {
                case "set":
                    this.handleSet(sender, args);
                    break;
                case "random":
                    this.handleRandom(sender, args);
                    break;
                case "toggle":
                    this.handleToggle(sender);
                    break;
                case "deathreset":
                    this.handleDeathReset(sender, args);
                    break;
                case "cooldown":
                    this.handleCooldown(sender, args);
                    break;
                case "protect":
                    this.handleProtect(sender, args);
                    break;
                case "list":
                    this.handleList(sender);
                    break;
                case "info":
                    this.handleInfo(sender, args);
                    break;
                case "help":
                    this.showHelp(sender);
                    break;
                default:
                    sender.sendMessage("§6[超能力] §c未知命令! 输入 /cnl help 查看帮助");
            }

            return true;
        }
    }

    private void handleSet(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
        } else if (args.length < 2) {
            sender.sendMessage("§6[超能力] §c用法: /cnl set <数字ID|s|random> [玩家]");
        } else if (args[1].equalsIgnoreCase("random")) {
            Player target;
            if (args.length >= 3) {
                target = Bukkit.getPlayer(args[2]);
                if (target == null) {
                    sender.sendMessage("§6[超能力] §c玩家不存在或离线!");
                    return;
                }

                this.setRandomAbility(sender, target);
            } else {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§6[超能力] §c控制台必须指定玩家!");
                    return;
                }

                target = (Player)sender;
                this.setRandomAbility(sender, target);
            }

        } else {
            AbilityType ability = AbilityType.fromDisplayId(args[1]);
            if (ability == null) {
                sender.sendMessage("§6[超能力] §c无效的超能力ID!");
            } else {
                Player target;
                if (args.length >= 3) {
                    target = Bukkit.getPlayer(args[2]);
                    if (target == null) {
                        sender.sendMessage("§6[超能力] §c玩家不存在或离线!");
                        return;
                    }

                    this.setPlayerAbility(sender, target, ability);
                } else {
                    if (!(sender instanceof Player)) {
                        sender.sendMessage("§6[超能力] §c控制台必须指定玩家!");
                        return;
                    }

                    target = (Player)sender;
                    this.setOwnAbility(target, ability);
                }

            }
        }
    }

    private void handleRandom(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
        } else {
            Player player;
            if (args.length >= 2 && args[1].equals("@a")) {
                Iterator var5 = Bukkit.getOnlinePlayers().iterator();

                while(var5.hasNext()) {
                    player = (Player)var5.next();
                    this.setRandomAbility(sender, player, false);
                }

                sender.sendMessage("§6[超能力] §a已为所有在线玩家随机分配超能力!");
            } else {
                Player target;
                if (args.length >= 2) {
                    target = Bukkit.getPlayer(args[1]);
                    if (target == null) {
                        sender.sendMessage("§6[超能力] §c玩家不存在或离线!");
                        return;
                    }
                } else {
                    if (!(sender instanceof Player)) {
                        sender.sendMessage("§6[超能力] §c控制台必须指定玩家!");
                        return;
                    }

                    player = (Player)sender;
                    target = player;
                }

                this.setRandomAbility(sender, target);
            }
        }
    }

    private void setRandomAbility(CommandSender sender, Player target) {
        this.setRandomAbility(sender, target, true);
    }

    private void setRandomAbility(CommandSender sender, Player target, boolean notify) {
        AbilityType randomAbility = AbilityManager.getRandomAbility();
        AbilityManager.setAbility(target, randomAbility);
        if (notify) {
            String var10001 = target.getName();
            sender.sendMessage("§6[超能力] §a已为 " + var10001 + " 随机分配: §e" + randomAbility.getDisplayId() + ". " + randomAbility.getDisplayName());
            var10001 = sender.equals(target) ? "你被随机分配了" : "管理员将你的超能力设置为";
            target.sendMessage("§6[超能力] §a" + var10001 + ": §e" + randomAbility.getDisplayId() + ". " + randomAbility.getDisplayName());
        }

    }

    private void handleList(CommandSender sender) {
        sender.sendMessage("§6==========[ 超能力列表 ]==========");
        int count = 0;
        AbilityType[] var3 = AbilityType.values();
        int var4 = var3.length;

        int var5;
        AbilityType type;
        for(var5 = 0; var5 < var4; ++var5) {
            type = var3[var5];
            if (type != AbilityType.NONE && type != AbilityType.DAMAGE_TELEPORT) {
                ++count;
            }
        }

        sender.sendMessage("§7共 " + count + " 种超能力");
        var3 = AbilityType.values();
        var4 = var3.length;

        for(var5 = 0; var5 < var4; ++var5) {
            type = var3[var5];
            if (type != AbilityType.NONE && type != AbilityType.DAMAGE_TELEPORT) {
                String var10001 = type.getDisplayId();
                sender.sendMessage("§e" + var10001 + ". " + type.getDisplayName());
            }
        }

        sender.sendMessage("§6================================");
        sender.sendMessage("§a输入 /cnl info <ID> 查看超能力简介");
    }

    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§6[超能力] §c用法: /cnl info <ID>");
        } else {
            AbilityType ability = AbilityType.fromDisplayId(args[1]);
            if (ability == null) {
                sender.sendMessage("§6[超能力] §c无效的超能力ID!");
            } else {
                sender.sendMessage("§6==========[ " + ability.getDisplayName() + " ]==========");
                sender.sendMessage("§eID: §f" + ability.getDisplayId());
                sender.sendMessage("§e名称: §f" + ability.getDisplayName());
                sender.sendMessage("§e简介: §f" + ability.getDescription());
                sender.sendMessage("§6================================");
            }
        }
    }

    private void handleToggle(CommandSender sender) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
        } else if (sender instanceof Player) {
            Player player = (Player)sender;
            AbilityManager.toggleSkill(player);
            boolean isActive = AbilityManager.isSkillActive(player);
            player.sendMessage("§6[超能力] §a主动技能已" + (isActive ? "激活" : "关闭") + "!");
        } else {
            sender.sendMessage("§6[超能力] §c只有玩家可以使用此命令!");
        }
    }

    private void handleDeathReset(CommandSender sender, String[] args) {
        if (sender instanceof Player player) {
            if (args.length == 1) {
                boolean current = AbilityManager.isDeathResetEnabled(player);
                player.sendMessage("§6[超能力] §a死亡重置当前状态: §e" + (current ? "开启" : "关闭"));
                player.sendMessage("§a使用 §e/cnl deathreset toggle §a切换状态");
            } else {
                boolean current;
                switch (args[1].toLowerCase()) {
                    case "toggle":
                        if (!sender.hasPermission("abilities.admin")) {
                            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
                            return;
                        }

                        current = AbilityManager.isDeathResetEnabled(player);
                        boolean newState = !current;
                        AbilityManager.setDeathResetEnabled(player, newState);
                        player.sendMessage("§6[超能力] §a死亡重置已" + (newState ? "开启" : "关闭") + "!");
                        if (newState) {
                            player.sendMessage("§7死亡后将随机获得新的超能力");
                        } else {
                            player.sendMessage("§7死亡后将保留当前超能力");
                        }
                        break;
                    case "on":
                        if (!sender.hasPermission("abilities.admin")) {
                            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
                            return;
                        }

                        AbilityManager.setDeathResetEnabled(player, true);
                        player.sendMessage("§6[超能力] §a死亡重置已开启!");
                        player.sendMessage("§7死亡后将随机获得新的超能力");
                        break;
                    case "off":
                        if (!sender.hasPermission("abilities.admin")) {
                            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
                            return;
                        }

                        AbilityManager.setDeathResetEnabled(player, false);
                        player.sendMessage("§6[超能力] §a死亡重置已关闭!");
                        player.sendMessage("§7死亡后将保留当前超能力");
                        break;
                    case "check":
                        current = AbilityManager.isDeathResetEnabled(player);
                        player.sendMessage("§6[超能力] §a死亡重置状态: §e" + (current ? "开启" : "关闭"));
                        break;
                    default:
                        player.sendMessage("§6[超能力] §c未知命令!");
                        player.sendMessage("§e/cnl deathreset §a- 查看当前状态");
                        player.sendMessage("§e/cnl deathreset toggle §a- 切换状态");
                        player.sendMessage("§e/cnl deathreset on §a- 开启");
                        player.sendMessage("§e/cnl deathreset off §a- 关闭");
                        player.sendMessage("§e/cnl deathreset check §a- 检查状态");
                }

            }
        } else {
            sender.sendMessage("§6[超能力] §c只有玩家可以使用此命令!");
        }
    }

    private void handleCooldown(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
        } else {
            Player target;
            if (args.length >= 2) {
                target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage("§6[超能力] §c玩家不存在或离线!");
                    return;
                }
            } else {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§6[超能力] §c请指定玩家!");
                    return;
                }

                Player player = (Player)sender;
                target = player;
            }

            UUID uuid = target.getUniqueId();
            boolean newState = AbilityManager.toggleNoCooldown(uuid);
            String var10001 = target.getName();
            sender.sendMessage("§6[超能力] §a" + var10001 + " 的无冷却模式已" + (newState ? "开启" : "关闭") + "!");
            if (!sender.equals(target)) {
                target.sendMessage("§6[超能力] §a管理员" + (newState ? "开启" : "关闭") + "了你的无冷却模式!");
            }

        }
    }

    private void handleProtect(CommandSender sender, String[] args) {
        if (!sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§6[超能力] §c你没有权限使用此命令!");
        } else {
            Player target;
            if (args.length >= 2) {
                target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage("§6[超能力] §c玩家不存在或离线!");
                    return;
                }
            } else {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("§6[超能力] §c请指定玩家!");
                    return;
                }

                Player player = (Player)sender;
                target = player;
            }

            boolean newState = AbilityManager.toggleCodeKillProtection(target);
            String var10001 = target.getName();
            sender.sendMessage("§6[超能力] §a" + var10001 + " 的代码杀保护已" + (newState ? "开启" : "关闭") + "!");
            if (!sender.equals(target)) {
                target.sendMessage("§6[超能力] §a管理员" + (newState ? "开启" : "关闭") + "了你的代码杀保护!");
            }

        }
    }

    private void setOwnAbility(Player player, AbilityType ability) {
        AbilityManager.setAbility(player, ability);
        String var10001 = ability.getDisplayId();
        player.sendMessage("§6[超能力] §a你的超能力已设置为: §e" + var10001 + ". " + ability.getDisplayName());
    }

    private void setPlayerAbility(CommandSender sender, Player target, AbilityType ability) {
        AbilityManager.setAbility(target, ability);
        String var10001 = target.getName();
        sender.sendMessage("§6[超能力] §a已为 " + var10001 + " 设置超能力: §e" + ability.getDisplayId() + ". " + ability.getDisplayName());
        var10001 = ability.getDisplayId();
        target.sendMessage("§6[超能力] §a管理员将你的超能力设置为: §e" + var10001 + ". " + ability.getDisplayName());
    }

    private void showAbility(Player viewer, Player target) {
        AbilityType ability = AbilityManager.getAbility(target);
        if (ability != null) {
            boolean deathReset = AbilityManager.isDeathResetEnabled(target);
            viewer.sendMessage("§6==========[ 超能力系统 ]==========");
            String var10001 = target.getName();
            viewer.sendMessage("§6玩家: §e" + var10001);
            var10001 = ability.getDisplayId();
            viewer.sendMessage("§6当前超能力: §e" + var10001 + ". " + ability.getDisplayName());
            viewer.sendMessage("§6死亡重置: §e" + (deathReset ? "开启" : "关闭"));
            viewer.sendMessage("§6================================");
            if (viewer.equals(target)) {
                viewer.sendMessage("§a输入 /cnl list 查看所有超能力");
                viewer.sendMessage("§e按技能键触发或开关主动技能");
            }
        } else {
            viewer.sendMessage("§6[超能力] §c该玩家没有任何超能力!");
        }

    }

    private void showHelp(CommandSender sender) {
        sender.sendMessage("§6==========[ 超能力命令 ]==========");
        sender.sendMessage("§e/cnl §a- 查看当前超能力");
        sender.sendMessage("§e/cnl list §a- 列出所有超能力");
        sender.sendMessage("§e/cnl info <ID> §a- 查看超能力简介");
        sender.sendMessage("§e/cnl deathreset check §a- 查看死亡重置状态");
        sender.sendMessage("");
        int abilityCount = 0;
        AbilityType[] var3 = AbilityType.values();
        int var4 = var3.length;

        int var5;
        AbilityType type;
        for(var5 = 0; var5 < var4; ++var5) {
            type = var3[var5];
            if (type != AbilityType.NONE && type != AbilityType.DAMAGE_TELEPORT) {
                ++abilityCount;
            }
        }

        sender.sendMessage("§6所有超能力(" + abilityCount + "种):");
        var3 = AbilityType.values();
        var4 = var3.length;

        for(var5 = 0; var5 < var4; ++var5) {
            type = var3[var5];
            if (type != AbilityType.NONE && type != AbilityType.DAMAGE_TELEPORT) {
                String var10001 = type.getDisplayId();
                sender.sendMessage("§e" + var10001 + ". " + type.getDisplayName());
            }
        }

        sender.sendMessage("§6================================");
        if (sender.hasPermission("abilities.admin")) {
            sender.sendMessage("§c管理员命令:");
            sender.sendMessage("§e/cnl set <ID> [玩家] §c- 设置(自己/他人)超能力");
            sender.sendMessage("§e/cnl set random [玩家] §c- 随机分配(自己/他人)");
            sender.sendMessage("§e/cnl random [玩家|@a] §c- 随机分配(个人/全体)超能力");
            sender.sendMessage("§e/cnl toggle §c- 切换主动技能开关");
            sender.sendMessage("§e/cnl deathreset [toggle|on|off] §c- 死亡重置开关控制");
            sender.sendMessage("§e/cnl cooldown [玩家] §c- 切换无冷却模式");
            sender.sendMessage("§e/cnl protect [玩家] §c- 切换代码杀保护(标签)");
        }

    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList();
        if (args.length == 1) {
            List<String> options = new ArrayList(Arrays.asList("list", "info", "set", "random", "toggle", "deathreset", "cooldown", "protect", "help"));
            StringUtil.copyPartialMatches(args[0], options, completions);
        } else if (args.length == 2) {
            Iterator var9;
            Player player;
            int var11;
            switch (args[0].toLowerCase()) {
                case "set":
                    if (sender.hasPermission("abilities.admin")) {
                        List<String> options = new ArrayList();
                        options.add("random");
                        options.add("0");
                        options.add("s");
                        AbilityType[] var19 = AbilityType.values();
                        var11 = var19.length;

                        for(int var20 = 0; var20 < var11; ++var20) {
                            AbilityType type = var19[var20];
                            if (type != AbilityType.NONE) {
                                options.add(String.valueOf(type.getDisplayId()));
                            }
                        }

                        StringUtil.copyPartialMatches(args[1], options, completions);
                    }
                    break;
                case "info":
                    completions.add("0");
                    completions.add("s");
                    AbilityType[] var16 = AbilityType.values();
                    int var18 = var16.length;

                    for(var11 = 0; var11 < var18; ++var11) {
                        AbilityType type = var16[var11];
                        if (type != AbilityType.NONE) {
                            completions.add(String.valueOf(type.getDisplayId()));
                        }
                    }

                    return completions;
                case "deathreset":
                    StringUtil.copyPartialMatches(args[1], Arrays.asList("toggle", "on", "off", "check"), completions);
                    break;
                case "random":
                    if (sender.hasPermission("abilities.admin")) {
                        completions.add("@a");
                        var9 = Bukkit.getOnlinePlayers().iterator();

                        while(var9.hasNext()) {
                            player = (Player)var9.next();
                            completions.add(player.getName());
                        }
                    }
                    break;
                case "cooldown":
                    if (sender.hasPermission("abilities.admin")) {
                        var9 = Bukkit.getOnlinePlayers().iterator();

                        while(var9.hasNext()) {
                            player = (Player)var9.next();
                            completions.add(player.getName());
                        }
                    }
                    break;
                case "protect":
                    if (sender.hasPermission("abilities.admin")) {
                        var9 = Bukkit.getOnlinePlayers().iterator();

                        while(var9.hasNext()) {
                            player = (Player)var9.next();
                            completions.add(player.getName());
                        }
                    }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("set") && sender.hasPermission("abilities.admin")) {
            Iterator var15 = Bukkit.getOnlinePlayers().iterator();

            while(var15.hasNext()) {
                Player player = (Player)var15.next();
                completions.add(player.getName());
            }
        }

        return completions;
    }
}
