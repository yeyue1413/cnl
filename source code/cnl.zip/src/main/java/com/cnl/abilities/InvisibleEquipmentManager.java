
package com.cnl.abilities;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class InvisibleEquipmentManager {
    private static boolean reflectionReady = false;
    private static Method getHandleMethod;
    private static Field connectionField;
    private static Method sendPacketMethod;
    private static Constructor<?> packetConstructor;
    private static Method pairOfMethod;
    private static Method asNMSCopyMethod;
    private static Enum<?>[] slotEnums;
    private static Object itemStackEmpty;
    private static final Set<Integer> hiddenPlayers = ConcurrentHashMap.newKeySet();
    private static final Map<Integer, BukkitTask> refreshTasks = new ConcurrentHashMap();

    public InvisibleEquipmentManager() {
    }

    public static void init() {
        try {
            Class<?> craftPlayerClass = Class.forName("org.bukkit.craftbukkit.entity.CraftPlayer");
            getHandleMethod = craftPlayerClass.getDeclaredMethod("getHandle");
            getHandleMethod.setAccessible(true);
            Class<?> serverPlayerClass = getHandleMethod.getReturnType();
            connectionField = serverPlayerClass.getDeclaredField("connection");
            connectionField.setAccessible(true);
            Class<?> connectionClass = connectionField.getType();
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.Packet");

            try {
                sendPacketMethod = connectionClass.getMethod("sendPacket", packetClass);
            } catch (NoSuchMethodException var12) {
                sendPacketMethod = connectionClass.getMethod("send", packetClass);
            }

            Class<?> equipmentSlotClass = Class.forName("net.minecraft.world.entity.EquipmentSlot");
            Class<? extends Enum> enumClass = equipmentSlotClass.asSubclass(Enum.class);
            slotEnums = new Enum[]{Enum.valueOf(enumClass, "MAINHAND"), Enum.valueOf(enumClass, "OFFHAND"), Enum.valueOf(enumClass, "HEAD"), Enum.valueOf(enumClass, "CHEST"), Enum.valueOf(enumClass, "LEGS"), Enum.valueOf(enumClass, "FEET")};
            Class<?> itemStackClass = Class.forName("net.minecraft.world.item.ItemStack");
            Field emptyField = itemStackClass.getField("EMPTY");
            itemStackEmpty = emptyField.get((Object)null);
            Class<?> pairOfClass = Class.forName("com.mojang.datafixers.util.Pair");
            pairOfMethod = pairOfClass.getMethod("of", Object.class, Object.class);
            Class<?> craftItemStackClass = Class.forName("org.bukkit.craftbukkit.inventory.CraftItemStack");
            asNMSCopyMethod = craftItemStackClass.getMethod("asNMSCopy", ItemStack.class);
            Class<?> equipPacketClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket");

            try {
                packetConstructor = equipPacketClass.getConstructor(Integer.TYPE, List.class);
            } catch (NoSuchMethodException var11) {
                packetConstructor = equipPacketClass.getConstructor(Integer.TYPE, List.class, Integer.TYPE);
            }

            reflectionReady = true;
            Main.getInstance().getLogger().info("InvisibleEquipmentManager 初始化成功");
        } catch (Exception var13) {
            Main.getInstance().getLogger().severe("InvisibleEquipmentManager 初始化失败: " + var13.getMessage());
        }

    }

    public static void hideEquipment(final Player player) {
        if (reflectionReady) {
            hiddenPlayers.add(player.getEntityId());
            sendEmptyEquipment(player);
            stripPotionParticles(player);
            BukkitTask existing = (BukkitTask)refreshTasks.get(player.getEntityId());
            if (existing != null) {
                existing.cancel();
            }

            BukkitTask task = (new BukkitRunnable() {
                public void run() {
                    if (player.isOnline() && InvisibleEquipmentManager.hiddenPlayers.contains(player.getEntityId())) {
                        InvisibleEquipmentManager.sendEmptyEquipment(player);
                        InvisibleEquipmentManager.stripPotionParticles(player);
                    } else {
                        this.cancel();
                        InvisibleEquipmentManager.refreshTasks.remove(player.getEntityId());
                    }
                }
            }).runTaskTimer(Main.getInstance(), 10L, 10L);
            refreshTasks.put(player.getEntityId(), task);
        }
    }

    public static void showEquipment(Player player) {
        BukkitTask task = (BukkitTask)refreshTasks.remove(player.getEntityId());
        if (task != null) {
            task.cancel();
        }

        hiddenPlayers.remove(player.getEntityId());
        sendRealEquipment(player);
    }

    public static void cleanup(Player player) {
        BukkitTask task = (BukkitTask)refreshTasks.remove(player.getEntityId());
        if (task != null) {
            task.cancel();
        }

        hiddenPlayers.remove(player.getEntityId());
    }

    private static void sendEmptyEquipment(Player player) {
        sendEquipment(player, true);
    }

    private static void sendRealEquipment(Player player) {
        if (reflectionReady) {
            try {
                List<Object> slotPairs = new ArrayList();
                slotPairs.add(makeRealPair(slotEnums[0], player.getInventory().getItemInMainHand()));
                slotPairs.add(makeRealPair(slotEnums[1], player.getInventory().getItemInOffHand()));
                slotPairs.add(makeRealPair(slotEnums[2], player.getInventory().getHelmet()));
                slotPairs.add(makeRealPair(slotEnums[3], player.getInventory().getChestplate()));
                slotPairs.add(makeRealPair(slotEnums[4], player.getInventory().getLeggings()));
                slotPairs.add(makeRealPair(slotEnums[5], player.getInventory().getBoots()));
                Object serverPlayer = getHandleMethod.invoke(player);
                Object connection = connectionField.get(serverPlayer);
                Object packet;
                if (packetConstructor.getParameterCount() == 3) {
                    packet = packetConstructor.newInstance(player.getEntityId(), slotPairs, 0);
                } else {
                    packet = packetConstructor.newInstance(player.getEntityId(), slotPairs);
                }

                Iterator var5 = Bukkit.getOnlinePlayers().iterator();

                while(var5.hasNext()) {
                    Player online = (Player)var5.next();
                    if (!online.equals(player)) {
                        Object viewerServerPlayer = getHandleMethod.invoke(online);
                        Object viewerConnection = connectionField.get(viewerServerPlayer);
                        sendPacketMethod.invoke(viewerConnection, packet);
                    }
                }
            } catch (Exception var9) {
                Main.getInstance().getLogger().warning("发送真实装备数据包失败: " + var9.getMessage());
            }

        }
    }

    private static void sendEquipment(Player player, boolean air) {
        if (reflectionReady) {
            try {
                Object serverPlayer = getHandleMethod.invoke(player);
                Object connection = connectionField.get(serverPlayer);
                List<Object> slotPairs = new ArrayList();

                for(int i = 0; i < 6; ++i) {
                    slotPairs.add(makePair(slotEnums[i], air));
                }

                Object packet;
                if (packetConstructor.getParameterCount() == 3) {
                    packet = packetConstructor.newInstance(player.getEntityId(), slotPairs, 0);
                } else {
                    packet = packetConstructor.newInstance(player.getEntityId(), slotPairs);
                }

                Iterator var6 = Bukkit.getOnlinePlayers().iterator();

                while(var6.hasNext()) {
                    Player online = (Player)var6.next();
                    if (!online.equals(player)) {
                        Object viewerServerPlayer = getHandleMethod.invoke(online);
                        Object viewerConnection = connectionField.get(viewerServerPlayer);
                        sendPacketMethod.invoke(viewerConnection, packet);
                    }
                }
            } catch (Exception var10) {
                Main.getInstance().getLogger().warning("发送空装备数据包失败: " + var10.getMessage());
            }

        }
    }

    private static Object makePair(Object slot, boolean air) {
        try {
            Object item = air ? itemStackEmpty : null;
            return pairOfMethod.invoke((Object)null, slot, item);
        } catch (Exception var3) {
            return null;
        }
    }

    private static Object makeRealPair(Object slot, ItemStack bukkitItem) {
        try {
            Object nmsItem;
            if (bukkitItem != null && !bukkitItem.getType().isAir()) {
                nmsItem = asNMSCopyMethod.invoke((Object)null, bukkitItem);
            } else {
                nmsItem = itemStackEmpty;
            }

            return pairOfMethod.invoke((Object)null, slot, nmsItem);
        } catch (Exception var3) {
            return null;
        }
    }

    public static void stripPotionParticles(Player player) {
        try {
            Iterator var1 = player.getActivePotionEffects().iterator();

            while(true) {
                PotionEffect effect;
                do {
                    do {
                        if (!var1.hasNext()) {
                            return;
                        }

                        effect = (PotionEffect)var1.next();
                    } while(effect.getType().equals(PotionEffectType.INVISIBILITY));
                } while(!effect.hasParticles() && !effect.hasIcon());

                player.addPotionEffect(new PotionEffect(effect.getType(), effect.getDuration(), effect.getAmplifier(), effect.isAmbient(), false, false), true);
            }
        } catch (Exception var3) {
        }
    }
}
