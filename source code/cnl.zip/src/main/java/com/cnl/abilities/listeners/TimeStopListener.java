
package com.cnl.abilities.listeners;

import com.cnl.abilities.AbilityManager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.projectiles.ProjectileSource;

public class TimeStopListener implements Listener {
    public TimeStopListener() {
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerMove(PlayerMoveEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerInteract(PlayerInteractEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerDropItem(PlayerDropItemEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerPickupItem(PlayerAttemptPickupItemEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerBucketFill(PlayerBucketFillEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerFish(PlayerFishEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopBlockBreak(BlockBreakEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopBlockPlace(BlockPlaceEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopInventoryClick(InventoryClickEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getWhoClicked();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }

            }
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopInventoryDrag(InventoryDragEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getWhoClicked();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }

            }
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityDamage(EntityDamageEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
            AbilityManager.accumulateDamage(event.getEntity().getUniqueId(), event.getFinalDamage(), (Entity)null);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
            AbilityManager.accumulateDamage(event.getEntity().getUniqueId(), event.getFinalDamage(), event.getDamager());
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityShootBow(EntityShootBowEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            LivingEntity var3 = event.getEntity();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                    return;
                }
            }

            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopProjectileLaunch(ProjectileLaunchEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            ProjectileSource var3 = event.getEntity().getShooter();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                    return;
                }

                if (AbilityManager.isTimeStopTriggerPlayer(player)) {
                    player.sendMessage("§c时停期间无法发射弹射物！");
                }
            }

            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopCreatureSpawn(CreatureSpawnEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopFoodLevelChange(FoodLevelChangeEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getEntity();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerItemDamage(PlayerItemDamageEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerItemConsume(PlayerItemConsumeEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
                player.sendMessage("§c时停期间无法使用命令！");
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopAsyncPlayerChat(AsyncPlayerChatEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
                player.sendMessage("§c时停期间无法聊天！");
            }

        }
    }
}
