
package com.cnl.abilities;

import com.cnl.abilities.mindcontrol.MindControlManager;
import com.cnl.abilities.mindcontrol.MindControlManager.ControlState;
import com.google.common.collect.Multimap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.TreeType;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.attribute.AttributeModifier.Operation;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AnimalTamer;
import org.bukkit.entity.Animals;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.EvokerFangs;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.LlamaSpit;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Snowball;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.entity.Vex;
import org.bukkit.entity.WitherSkull;
import org.bukkit.entity.AbstractArrow.PickupStatus;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.EntityTameEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerAttemptPickupItemEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class AbilityListener implements Listener {
    private static final Set<EntityType> UNDEAD_TYPES;
    private static final Map<AbilityType, Set<EntityType>> FRIENDLY_MOBS;
    private static final Map<Material, PotionEffectType> ORE_EFFECTS;
    private static final Map<Material, String> ORE_KEYS;
    private static final List<PotionEffectType> FOOD_BUFF_EFFECTS;
    private static final Set<EntityType> SMALL_ANIMALS;
    private static final Map<EntityType, Material> ANIMAL_FOOD_MAP;
    private static final Map<UUID, String> swallowedByTaotie;
    private static final Map<Material, Material> FOOD_UPGRADES;
    private static final Set<Material> HOT_BIOME_GROUND;
    private static final TreeType[] RANDOM_TREES;
    public static AbilityListener INSTANCE;
    private final Random random = new Random();
    private final Map<UUID, Integer> enchantCounts = new HashMap();
    private final Map<UUID, List<Long>> shotTimestamps = new HashMap();
    private final Map<UUID, String> projectileTypes = new HashMap();
    private final Map<UUID, Long> overloadEndTime = new HashMap();
    private final Map<UUID, Double> spitLostHealth = new HashMap();
    private static final double PROJECTILE_SPEED = 2.0;
    private static final long OVERLOAD_INTERVAL = 1000L;
    private static final int OVERLOAD_SHOTS = 5;
    private static final long PENALTY_DURATION = 30000L;
    private static final double SPIT_HEART_HP = 2.0;
    private final Map<UUID, BukkitTask> quantumRestoreTasks = new HashMap();
    private final Set<UUID> diedInQuantumState = new HashSet<>();
    private final Map<UUID, Long> fireTrailTick = new HashMap();
    private final Map<UUID, Set<Location>> icePlacedBlocks = new HashMap();
    private final Map<UUID, List<Location>> spiderWebs = new HashMap();
    private final Map<UUID, Location> recallLocations = new HashMap();
    private final Map<UUID, Long> recallCooldowns = new HashMap();
    private final Map<UUID, Long> recordCooldowns = new HashMap();
    private static final long RECALL_COOLDOWN_MS = 10000L;
    private static final long RECORD_COOLDOWN_MS = 1000L;
    private final Map<UUID, Long> teleportCooldowns = new HashMap();
    private static final long DAMAGE_TELEPORT_COOLDOWN_MS = 500L;
    private final Set<UUID> selfExplosionImmunity = new HashSet();
    private final Set<UUID> spartanHitPlayers = new HashSet();
    private final Map<UUID, List<CitizenCrime>> citizenCrimes = new HashMap();
    private static final Set<Material> NATURAL_BLOCKS = new HashSet(Arrays.asList(Material.DIRT, Material.GRASS_BLOCK, Material.STONE, Material.DEEPSLATE, Material.GRANITE, Material.DIORITE, Material.ANDESITE, Material.SAND, Material.RED_SAND, Material.GRAVEL, Material.CLAY, Material.MUD, Material.TUFF, Material.CALCITE, Material.DRIPSTONE_BLOCK, Material.SANDSTONE, Material.RED_SANDSTONE, Material.COBBLESTONE, Material.COBBLED_DEEPSLATE, Material.NETHERRACK, Material.SOUL_SAND, Material.SOUL_SOIL, Material.BASALT, Material.BLACKSTONE, Material.END_STONE, Material.OBSIDIAN, Material.GLOWSTONE, Material.SEA_LANTERN, Material.PRISMARINE, Material.SNOW_BLOCK, Material.ICE, Material.PACKED_ICE, Material.BLUE_ICE, Material.GRAVEL, Material.FLINT, Material.NETHER_GOLD_ORE, Material.ANCIENT_DEBRIS));

    public AbilityListener() {
        INSTANCE = this;
    }

    public static void executeFKey(Player player, Material simulatedItem) {
        AbilityType ability = AbilityManager.getAbility(player);
        if (ability == null) return;
        if (AbilityManager.isAbilityDisabledByGodsLeftHand(player.getUniqueId())) {
            player.sendMessage("§c☠ §4你的超能力暂时无效!");
            return;
        }
        if (ability == AbilityType.MIND_CONTROL && simulatedItem == Material.STICK) {
            INSTANCE.handleMindControl(player);
            return;
        }
        if (ability == AbilityType.MIND_CONTROL && simulatedItem == Material.CHEST) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null && mm.isControlling(player.getUniqueId())) {
                mm.openTargetInventory(player);
            } else {
                player.sendMessage("§c你当前没有控制任何玩家!");
            }
            return;
        }
        if (ability == AbilityType.MIND_CONTROL && simulatedItem == Material.BARRIER) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null && mm.releaseControl(player)) {
                player.sendMessage("§5[灵魂控制] §a已手动解除控制!");
            } else {
                player.sendMessage("§c你当前没有控制任何玩家!");
            }
            return;
        }
        if (ability == AbilityType.SOUL_SUMMONER && simulatedItem == Material.STICK) {
            INSTANCE.viewSouls(player);
            return;
        }
        if (ability == AbilityType.SOUL_SUMMONER && simulatedItem == Material.BONE) {
            INSTANCE.handleSoulSummon(player);
            return;
        }
        if (ability == AbilityType.BLACKSMITH) {
            ItemStack offHand = player.getInventory().getItemInOffHand();
            if (offHand.getType() == Material.LAPIS_LAZULI) {
                INSTANCE.handleBlacksmithEnchant(player);
            } else {
                int slot = findMaterial(player, Material.LAPIS_LAZULI);
                if (slot == -1) {
                    player.sendMessage("§c你没有青金石！");
                    return;
                }
                ItemStack stack = player.getInventory().getItem(slot);
                ItemStack savedOff = player.getInventory().getItemInOffHand().clone();
                if (stack.getAmount() > 1) {
                    stack.setAmount(stack.getAmount() - 1);
                    player.getInventory().setItem(slot, stack);
                } else {
                    player.getInventory().setItem(slot, null);
                }
                player.getInventory().setItemInOffHand(new ItemStack(Material.LAPIS_LAZULI));
                INSTANCE.handleBlacksmithEnchant(player);
                player.getInventory().setItemInOffHand(savedOff);
            }
            return;
        }
        if (ability == AbilityType.ORE_EATER) {
            ItemStack mainHand = player.getInventory().getItemInMainHand();
            if (mainHand.getType() == Material.AIR || !INSTANCE.isOreEaterFood(mainHand.getType())) {
                player.sendMessage("§c请主手持矿石/锭使用此技能!");
                return;
            }
            Material oreType = mainHand.getType();
            if (mainHand.getAmount() > 1) {
                mainHand.setAmount(mainHand.getAmount() - 1);
                player.getInventory().setItemInMainHand(mainHand);
            } else {
                player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
            }
            ItemStack savedOff = player.getInventory().getItemInOffHand().clone();
            player.getInventory().setItemInOffHand(new ItemStack(oreType));
            INSTANCE.handleOreEat(player);
            player.getInventory().setItemInOffHand(savedOff);
            return;
        }
        if (ability == AbilityType.GOD_LEFT_HAND) {
            INSTANCE.handleGodLeftHand(player);
            return;
        }
        if (ability == AbilityType.RICH_MAN) {
            ItemStack offHand = player.getInventory().getItemInOffHand();
            if (offHand.getType() == Material.DIAMOND_BLOCK) {
                INSTANCE.handleRichManSummon(player);
            } else {
                int slot = findMaterial(player, Material.DIAMOND_BLOCK);
                if (slot == -1) {
                    player.sendMessage("§c你没有钻石块！");
                    return;
                }
                ItemStack stack = player.getInventory().getItem(slot);
                ItemStack savedOff = player.getInventory().getItemInOffHand().clone();
                if (stack.getAmount() > 1) {
                    stack.setAmount(stack.getAmount() - 1);
                    player.getInventory().setItem(slot, stack);
                } else {
                    player.getInventory().setItem(slot, null);
                }
                player.getInventory().setItemInOffHand(new ItemStack(Material.DIAMOND_BLOCK));
                INSTANCE.handleRichManSummon(player);
                player.getInventory().setItemInOffHand(savedOff);
            }
            return;
        }
        switch (ability) {
            case ANT_MAN:
                if (player.isSneaking()) {
                    if (AbilityManager.isAntManShrunk(player)) {
                        AbilityManager.removeAntManEffect(player);
                    } else {
                        AbilityManager.removeAntManEffect(player);
                        AbilityManager.applyAntManSmallEffect(player);
                    }
                } else if (AbilityManager.isAntManBig(player)) {
                    AbilityManager.removeAntManEffect(player);
                } else {
                    AbilityManager.removeAntManEffect(player);
                    AbilityManager.applyAntManBigEffect(player);
                }
                break;
            case FIRE_MAN:
                if (player.isSneaking()) {
                    AbilityManager.toggleFireTrail(player);
                } else {
                    INSTANCE.handleFireManFireball(player);
                }
                break;
            case ICE_MAN:
                if (simulatedItem == Material.ICE) {
                    AbilityManager.toggleIceWalk(player);
                } else {
                    INSTANCE.handleIceManSnowball(player);
                }
                break;
            case ENDERLING:
                INSTANCE.handleEnderlingPearl(player);
                break;
            case SPIDER_MAN:
                if (simulatedItem != null) {
                    INSTANCE.handleSpiderManPull(player);
                } else {
                    INSTANCE.handleSpiderManWeb(player);
                }
                break;
            case THIEF:
                INSTANCE.handleThiefLifeSteal(player);
                break;
            case BOMBER:
                INSTANCE.handleBomberThrow(player);
                break;
            case TIME_STOPPER:
                INSTANCE.handleTimeStopTrigger(player);
                break;
            case RECALL:
                if (player.isSneaking()) {
                    INSTANCE.handleRecallRecord(player);
                } else {
                    INSTANCE.handleRecallTeleport(player);
                }
                break;
            case FIELD_WEAVER:
                INSTANCE.handleFieldWeaverActivate(player);
                break;
            case GUARDIAN:
                if (player.isSneaking()) {
                    Entity target = player.getTargetEntity(4);
                    if (target instanceof Player) {
                        Player targetPlayer = (Player)target;
                        if (!targetPlayer.equals(player)) {
                            UUID targetUuid = targetPlayer.getUniqueId();
                            UUID giverUuid = AbilityManager.getGuardianGiver(targetUuid);
                            if (giverUuid != null && giverUuid.equals(player.getUniqueId())) {
                                AbilityManager.removeGuardianTargetShield(player, targetPlayer);
                            } else if (!AbilityManager.canUseGuardian(player)) {
                                player.sendMessage("§c守护之盾冷却中!(60秒)");
                            } else if (AbilityManager.isGuardianShieldActive(player.getUniqueId())) {
                                player.sendMessage("§c你已有激活的护盾,无法再给予他人!");
                            } else if (AbilityManager.isGuardianShieldActive(targetUuid)) {
                                player.sendMessage("§c该玩家已有护盾!");
                            } else {
                                AbilityManager.giveGuardianShieldToTarget(player, targetPlayer);
                            }
                            return;
                        }
                    }
                    player.sendMessage("§c请对准一个玩家(4格内)!");
                } else if (!AbilityManager.canUseGuardian(player)) {
                    player.sendMessage("§c守护之盾冷却中!(60秒)");
                } else if (AbilityManager.isGuardianShieldActive(player.getUniqueId())) {
                    AbilityManager.deactivateGuardianShield(player);
                } else {
                    UUID givenTarget = AbilityManager.getGuardianGivenTarget(player.getUniqueId());
                    if (givenTarget != null) {
                        player.sendMessage("§c你已将护盾给予他人,无法同时给自己护盾!");
                    } else {
                        AbilityManager.activateGuardianShield(player);
                    }
                }
                break;
            case FAIRY:
                INSTANCE.handleFairyDebuff(player);
                break;
            case BIG_STOMACH:
                if (player.isSneaking()) {
                    INSTANCE.handleBigStomachEatAnimal(player);
                } else {
                    INSTANCE.handleBigStomachEatBlock(player);
                }
                break;
            case SPIT_EXPLOSION:
                INSTANCE.handleSpitShot(player);
                break;
            case SPARTAN:
                INSTANCE.handleSpartanPunch(player);
                break;
            case WITHER_KIN:
                INSTANCE.handleWitherSkull(player);
                break;
            case DEMON_SUMMONER:
                if (player.isSneaking()) {
                    INSTANCE.handleDemonVex(player);
                } else {
                    INSTANCE.handleDemonFang(player);
                }
                break;
            case LAWFUL_CITIZEN:
                INSTANCE.handleCitizenJail(player);
                break;
            case REFLECTOR:
                if (!AbilityManager.canUseReflector(player)) {
                    player.sendMessage("§c反射屏障冷却中!(60秒)");
                } else if (AbilityManager.isReflectorActive(player.getUniqueId())) {
                    AbilityManager.deactivateReflector(player);
                } else {
                    AbilityManager.activateReflector(player);
                }
                break;
            case ELF_RANGER:
                if (player.isSneaking()) {
                    INSTANCE.handleElfRangerTrackingArrows(player);
                } else {
                    INSTANCE.handleElfRangerArrow(player);
                }
                break;
            case WITCH_KIN:
                if (player.isSneaking()) {
                    INSTANCE.handleWitchRegen(player);
                } else {
                    INSTANCE.handleWitchPotion(player);
                }
                break;
            case NATURE_CHILD:
                Block targetBlock = player.getTargetBlockExact(10);
                if (targetBlock == null) {
                    targetBlock = player.getLocation().subtract(0.0, 1.0, 0.0).getBlock();
                }
                INSTANCE.handleNatureChildGrowTree(player, targetBlock);
                break;
            case LIGHTNING_KING:
                INSTANCE.handleLightningKing(player);
                break;
            case SENTINEL:
                if (player.isSneaking()) {
                    INSTANCE.handleSentinelSummon(player);
                }
                break;
            case SUMMONER:
                INSTANCE.handleSummoner(player);
                break;
            case REDEEMER:
                INSTANCE.handleRedeemer(player);
                break;
            default:
                AbilityManager.toggleSkill(player);
                boolean isActive = AbilityManager.isSkillActive(player);
                player.sendMessage("§6[超能力] §a主动技能已" + (isActive ? "激活" : "关闭") + "!");
        }
    }

    private static int findMaterial(Player player, Material material) {
        for (int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && item.getType() == material) {
                return i;
            }
        }
        return -1;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        MindControlManager mm;
        if (AbilityManager.isBattleModeActive()) {
            mm = MindControlManager.getInstance();
            if (mm != null) {
                mm.hideAllControllersFrom(player);
            }

        } else {
            AbilityType currentAbility;
            if (AbilityManager.getAbility(player) == null) {
                currentAbility = AbilityManager.getRandomAbility();
                AbilityManager.setAbility(player, currentAbility);
                int var10001 = currentAbility.getId();
                player.sendMessage("§6[超能力] §a你获得了: §e" + var10001 + ". " + currentAbility.getDisplayName());
            } else {
                currentAbility = AbilityManager.getAbility(player);
                if (currentAbility != null) {
                    AbilityManager.removeAbilityEffectsOnly(player, currentAbility);
                    AbilityManager.applyAbilityEffects(player, currentAbility);
                }

                AbilityManager.ensureRichManGolems(player);
            }

            this.applyKillerDamageModifier(player);
            mm = MindControlManager.getInstance();
            if (mm != null) {
                mm.hideAllControllersFrom(player);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.HIGH
    )
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();

        if (AbilityManager.isQuantumState(player.getUniqueId())) {
            diedInQuantumState.add(player.getUniqueId());
        }
        BukkitTask quantumTask = (BukkitTask)this.quantumRestoreTasks.remove(player.getUniqueId());
        if (quantumTask != null) {
            quantumTask.cancel();
        }
        AbilityManager.clearQuantumState(player.getUniqueId());
        if (AbilityManager.getFieldWeaverAffectedPlayers().contains(player.getUniqueId())) {
            AbilityManager.restoreFieldWeaverPlayer(player);
            AbilityManager.getFieldWeaverAffectedPlayers().remove(player.getUniqueId());
        }
        this.spitLostHealth.remove(player.getUniqueId());
        this.overloadEndTime.remove(player.getUniqueId());
        this.shotTimestamps.remove(player.getUniqueId());
        AttributeInstance healthAttr = player.getAttribute(Attribute.MAX_HEALTH);
        if (healthAttr != null) {
            healthAttr.setBaseValue(20.0);
        }

        this.removeSummonedMonsters(player);
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlling(player.getUniqueId())) {
                mm.releaseControl(player);
            } else if (mm.isControlled(player.getUniqueId())) {
                mm.releaseControlByTarget(player);
            }
        }

        String taotieName = (String)swallowedByTaotie.remove(player.getUniqueId());
        if (taotieName != null) {
            String var10001 = player.getName();
            event.setDeathMessage("§6[超能力] §c" + var10001 + " 被 " + taotieName + " 吞噬!");
        } else {
            Player killer = player.getKiller();
            if (killer != null && !killer.equals(player)) {
                this.trackCitizenCrime(killer.getUniqueId(), "kill", 20);
            }

            if (killer != null && AbilityManager.getAbility(killer) == AbilityType.HEX_MASTER && !killer.equals(player)) {
                AbilityManager.incrementHexKillCount(killer);
                int kills = AbilityManager.getHexKillCount(killer);
                if (kills % 3 == 0 && !AbilityManager.hasHexProtection(killer)) {
                    AbilityManager.setHexProtection(killer, true);
                    killer.sendMessage("§6[超能力] §a你的蛊术保护已恢复! (已击杀 " + kills + " 名玩家)");
                }
            }

            AbilityType ability = AbilityManager.getAbility(player);
            if (ability != null) {
                if (ability == AbilityType.FIRE_MAN) {
                    Location deathLoc = player.getLocation();

                    for(int i = 0; i < 8; ++i) {
                        double angle = 6.283185307179586 * (double)i / 8.0;
                        Location fireLoc = deathLoc.clone().add(Math.cos(angle), 0.0, Math.sin(angle));
                        Block fireBlock = fireLoc.getBlock();
                        if (fireBlock.getType() == Material.AIR) {
                            fireBlock.setType(Material.FIRE);
                        }
                    }

                    event.setDeathMessage("§6[超能力] §c" + player.getName() + " 化为了灰烬! (火焰人)");
                }

                Player playerKiller = player.getKiller();
                if (playerKiller != null && ability == AbilityType.LAWFUL_CITIZEN) {
                    this.sendToJail(playerKiller, 20, "§c法治社会敢杀人,进监狱去吧!");
                    this.confiscateToTeamOrRemove(playerKiller, player);
                }

                if (ability == AbilityType.HEX_MASTER && AbilityManager.hasHexProtection(player)) {
                    AbilityManager.setHexProtection(player, false);
                    player.sendMessage("§6[超能力] §a蛊术保护生效! 你免于死亡。");
                    event.getDrops().clear();
                    event.setDroppedExp(0);
                    event.setDeathMessage((String)null);
                } else {
                    if (ability == AbilityType.HYDROPHOBIC) {
                        EntityDamageEvent lastDamage = player.getLastDamageCause();
                        boolean waterDeath = false;
                        if (lastDamage != null) {
                            waterDeath = lastDamage.getCause() == DamageCause.DROWNING || lastDamage.getCause() == DamageCause.SUFFOCATION;
                        }

                        if (!waterDeath && this.isInWater(player)) {
                            waterDeath = true;
                        }

                        if (waterDeath) {
                            event.setDeathMessage("§6[超能力] §c" + player.getName() + " 因触碰水而死亡 (深信水有剧毒)");
                        }
                    }

                }
            }
        }

        if (AbilityManager.isBattleModeActive()) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.equals(player)) continue;
                if (p.getGameMode() == GameMode.SPECTATOR) continue;
                if (AbilityManager.isQuantumState(p.getUniqueId())) continue;
                if (AbilityManager.getAbility(p) == AbilityType.REDEEMER
                    && AbilityManager.isSameBattleTeam(p, player)) {
                    ItemStack paper = new ItemStack(Material.PAPER);
                    ItemMeta meta = paper.getItemMeta();
                    meta.setDisplayName("§c" + player.getName());
                    meta.setLore(Arrays.asList("§7手持此纸使用技能键救赎队友"));
                    paper.setItemMeta(meta);
                    p.getInventory().addItem(paper);
                    AbilityManager.addRedeemerPaper(p, player.getName());
                    p.sendMessage("§6[救赎者] §c队友 §e" + player.getName() + " §c已阵亡! 背包中已放入其灵魂纸");
                    p.sendMessage("§6[救赎者] §e手持此纸使用技能键，定身10秒后即可复活队友!");
                }
            }
        }
    }

    @EventHandler(
            priority = EventPriority.HIGHEST
    )
    public void onPlayerRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();

        if (diedInQuantumState.remove(player.getUniqueId())) {
            player.setGameMode(GameMode.SPECTATOR);
        }

        if (!AbilityManager.isBattleModeActive()) {
            Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                AbilityType currentAbility;
                int var10001;
                if (!AbilityManager.shouldResetOnDeath(player)) {
                    currentAbility = AbilityManager.getAbility(player);
                    if (currentAbility != null) {
                        AbilityManager.removeAbilityEffectsOnly(player, currentAbility);
                        AbilityManager.applyAbilityEffects(player, currentAbility);
                        var10001 = currentAbility.getId();
                        player.sendMessage("§6[超能力] §a你保留了超能力: §e" + var10001 + ". " + currentAbility.getDisplayName());
                    }

                } else {
                    AbilityManager.removeAbility(player);
                    currentAbility = AbilityManager.getRandomAbility();
                    AbilityManager.setAbility(player, currentAbility);
                    var10001 = currentAbility.getId();
                    player.sendMessage("§6[超能力] §a你死亡了! 重新获得新超能力: §e" + var10001 + ". " + currentAbility.getDisplayName());
                }
            }, 1L);
        }
    }

    @EventHandler
    public void onPlayerInteractEntity(PlayerInteractEntityEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        } else {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability != null) {
                if (player.getGameMode() != GameMode.SPECTATOR) {
                    if (AbilityManager.isAbilityDisabledByGodsLeftHand(player.getUniqueId())) {
                        event.setCancelled(true);
                        player.sendMessage("§c☠ §4你的超能力暂时无效!");
                    } else if (player.getInventory().getItemInMainHand().getType() == Material.AIR) {
                        if (event.getHand() == EquipmentSlot.HAND) {
                            Entity target = event.getRightClicked();
                            if (ability == AbilityType.THIEF && !player.isSneaking()) {
                                if (target instanceof Player) {
                                    Player targetPlayer = (Player)target;
                                    if (!target.equals(player)) {
                                        event.setCancelled(true);
                                        this.handleThiefStealFromPlayer(player, targetPlayer);
                                        return;
                                    }
                                }

                                if (target instanceof LivingEntity) {
                                    LivingEntity living = (LivingEntity)target;
                                    if (!target.equals(player)) {
                                        event.setCancelled(true);
                                        this.handleThiefStealFromMob(player, living);
                                    }
                                }

                            }
                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        } else {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability != null) {
                if (player.getGameMode() != GameMode.SPECTATOR) {
                    if (AbilityManager.isAbilityDisabledByGodsLeftHand(player.getUniqueId())) {
                        event.setCancelled(true);
                        player.sendMessage("§c☠ §4你的超能力暂时无效!");
                    } else if (ability == AbilityType.GOD_LEFT_HAND && event.getHand() == EquipmentSlot.HAND && (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK)) {
                        Entity godTarget = player.getTargetEntity(8);
                        if (godTarget instanceof Player && !godTarget.equals(player)) {
                            event.setCancelled(true);
                            this.handleGodLeftHand(player);
                        }
                    } else if (ability != AbilityType.AOE_ATTACK || event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.LEFT_CLICK_AIR && event.getAction() != Action.LEFT_CLICK_BLOCK) {
                        if (ability != AbilityType.SPIT_EXPLOSION || event.getHand() != EquipmentSlot.HAND || event.getAction() != Action.LEFT_CLICK_AIR && event.getAction() != Action.LEFT_CLICK_BLOCK) {
                            if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                                if (ability == AbilityType.ROMAN_LEGION && player.isSneaking() && player.getInventory().getItemInMainHand().getType() == Material.SHIELD) {
                                    if (!AbilityManager.canUseLegion(player)) {
                                        player.sendMessage("§c罗马防御阵型冷却中!(60秒)");
                                    } else if (!AbilityManager.isLegionFormationActive(player.getUniqueId())) {
                                        AbilityManager.setLegionFormation(player, true);
                                        player.sendMessage("§6[超能力] §b罗马防御阵型展开! 左右后侧绝对防御");
                                    }
                                } else if (ability == AbilityType.THIEF && event.getHand() == EquipmentSlot.HAND && player.getInventory().getItemInMainHand().getType() == Material.AIR) {
                                    Entity targetEntity = player.getTargetEntity(8);
                                    if (targetEntity instanceof Player) {
                                        Player targetPlayer = (Player)targetEntity;
                                        if (!targetPlayer.equals(player)) {
                                            event.setCancelled(true);
                                            this.handleThiefStealFromPlayer(player, targetPlayer);
                                            return;
                                        }
                                    }

                                    if (targetEntity instanceof LivingEntity) {
                                        LivingEntity living = (LivingEntity)targetEntity;
                                        if (!targetEntity.equals(player) && !(targetEntity instanceof Player)) {
                                            event.setCancelled(true);
                                            this.handleThiefStealFromMob(player, living);
                                        }
                                    }

                                } else if (event.getHand() == EquipmentSlot.OFF_HAND && event.getAction().name().contains("RIGHT") && player.isSneaking() && player.getInventory().getItemInOffHand().getType() == Material.STICK && (ability == AbilityType.FLASH || ability == AbilityType.ANT_MAN)) {
                                    AbilityManager.toggleSkill(player);
                                    boolean isActive = AbilityManager.isSkillActive(player);
                                    player.sendMessage("§6[超能力] §a主动技能已" + (isActive ? "激活" : "关闭") + "!");
                                } else if (ability != AbilityType.BLACKSMITH || event.getHand() != EquipmentSlot.OFF_HAND || event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
                                    if (ability == AbilityType.ORE_EATER && event.getHand() == EquipmentSlot.OFF_HAND && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && this.isOreEaterFood(player.getInventory().getItemInOffHand().getType())) {
                                        event.setCancelled(true);
                                        this.handleOreEat(player);
                                    } else if (ability == AbilityType.RICH_MAN && event.getHand() == EquipmentSlot.OFF_HAND && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && player.getInventory().getItemInOffHand().getType() == Material.DIAMOND_BLOCK) {
                                        event.setCancelled(true);
                                        this.handleRichManSummon(player);
                                    } else if (ability == AbilityType.SOUL_SUMMONER && event.getHand() == EquipmentSlot.HAND && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && player.getInventory().getItemInMainHand().getType() == Material.STICK) {
                                        event.setCancelled(true);
                                        this.viewSouls(player);
                                    } else if (ability == AbilityType.SOUL_SUMMONER && event.getHand() == EquipmentSlot.OFF_HAND && (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && player.getInventory().getItemInOffHand().getType() == Material.STICK) {
                                        event.setCancelled(true);
                                        this.handleSoulSummon(player);
                                    }
                                } else {
                                    this.handleBlacksmithEnchant(player);
                                }
                            }
                        }
                    } else {
                        this.handleAoeAttack(player);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        } else {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == AbilityType.BOMBER) {
                ;
            }
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        } else {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability != null) {
                boolean movedBlock = event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockZ() != event.getTo().getBlockZ() || event.getFrom().getBlockY() != event.getTo().getBlockY();
                boolean againstWall;
                if (ability == AbilityType.POSEIDON) {
                    boolean wasInWater = event.getFrom().getBlock().isLiquid() || event.getFrom().clone().add(0.0, 1.0, 0.0).getBlock().isLiquid();
                    againstWall = event.getTo().getBlock().isLiquid() || event.getTo().clone().add(0.0, 1.0, 0.0).getBlock().isLiquid();
                    if (!wasInWater && againstWall) {
                        AbilityManager.applyPoseidonEffects(player);
                    } else if (wasInWater && !againstWall) {
                        AbilityManager.removePoseidonEffects(player);
                    }
                }

                if (ability == AbilityType.INVISIBLE && !AbilityManager.isAbilityDisabledByGodsLeftHand(player.getUniqueId())) {
                    AbilityManager.applyInvisibilityEffect(player);
                }

                if (ability == AbilityType.SUN_CHILD && movedBlock) {
                    AbilityManager.applySunChildEffects(player);
                }

                if (ability == AbilityType.HYDROPHOBIC && this.isInWater(player)) {
                    player.setHealth(0.0);
                }

                Location playerLoc;
                if (AbilityManager.isLegionFormationActive(player.getUniqueId()) && event.getFrom().getY() < event.getTo().getY() && !player.isOnGround()) {
                    playerLoc = event.getFrom().clone();
                    event.setTo(playerLoc);
                }

                if (ability == AbilityType.WITHER_KIN && player.getHealth() <= player.getMaxHealth() / 2.0) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 0, false, false, true));
                }
                if (ability == AbilityType.FIRE_MAN && movedBlock && player.isOnGround() && AbilityManager.isFireTrailEnabled(player)) {
                    Block footBlock = player.getLocation().getBlock();
                    Block groundBlock = footBlock.getType().isSolid() ? footBlock : footBlock.getRelative(BlockFace.DOWN);
                    if (groundBlock.getType().isSolid() && groundBlock.getType() != Material.BEDROCK) {
                        Block fireSpot = groundBlock.getRelative(BlockFace.UP);
                        if (fireSpot.getType() == Material.AIR && !fireSpot.isLiquid()) {
                            fireSpot.setType(Material.FIRE);
                            this.trackCitizenCrime(player.getUniqueId(), "arson", 5);
                        }
                    }
                }

                if (ability == AbilityType.FIRE_MAN && this.isInWater(player)) {
                    player.damage(Math.max(player.getMaxHealth() / 2.0, 1.0));
                    player.sendMessage("§c水是你的克星! 火焰人在水中受到重创!");
                }

                if (ability == AbilityType.ICE_MAN && movedBlock && player.isOnGround() && AbilityManager.isIceWalkEnabled(player)) {
                    playerLoc = player.getLocation();
                    int radius = 3;
                    Block feetBlock = playerLoc.getBlock();
                    Block groundBlock = feetBlock.getRelative(BlockFace.DOWN);
                    Set<Location> iceBlocks = (Set)this.icePlacedBlocks.computeIfAbsent(player.getUniqueId(), (k) -> {
                        return new HashSet();
                    });

                    for(int x = -radius; x <= radius; ++x) {
                        for(int z = -radius; z <= radius; ++z) {
                            if (x * x + z * z <= radius * radius) {
                                for(int y = 0; y <= 1; ++y) {
                                    Block check = groundBlock.getRelative(x, y, z);
                                    if (check.getType() == Material.WATER || check.getType() == Material.WATER_CAULDRON) {
                                        check.setType(Material.ICE);
                                        iceBlocks.add(check.getLocation());
                                    }
                                }
                            }
                        }
                    }

                    if (feetBlock.getType() == Material.AIR && groundBlock.getType().isSolid() && groundBlock.getType() != Material.BEDROCK) {
                        feetBlock.setType(Material.SNOW);
                    }
                }

                if (ability == AbilityType.SPIDER_MAN) {
                    Block spiderBlock = player.getLocation().getBlock();
                    againstWall = false;
                    BlockFace[] var18 = new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST};
                    int var22 = var18.length;

                    for(int var24 = 0; var24 < var22; ++var24) {
                        BlockFace face = var18[var24];
                        Block relative = spiderBlock.getRelative(face);
                        if (relative.getType().isSolid()) {
                            againstWall = true;
                            break;
                        }
                    }

                    if (againstWall) {
                        player.setFallDistance(0.0F);
                        if (!player.getAllowFlight()) {
                            player.setAllowFlight(true);
                        }

                        if (!player.isFlying()) {
                            player.setFlying(true);
                        }

                        player.setFlySpeed(0.03F);
                    } else {
                        player.setFlySpeed(0.1F);
                        if (player.getGameMode() != GameMode.CREATIVE && player.getGameMode() != GameMode.SPECTATOR) {
                            if (player.getAllowFlight()) {
                                player.setAllowFlight(false);
                            }

                            if (player.isFlying()) {
                                player.setFlying(false);
                            }
                        }
                    }
                }

                if (ability == AbilityType.NATURE_CHILD && movedBlock) {
                    Block natureBlock = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
                    Material belowType = natureBlock.getType();
                    if (belowType != Material.GRASS_BLOCK && belowType != Material.DIRT && belowType != Material.SAND && belowType != Material.RED_SAND && belowType != Material.PODZOL && belowType != Material.COARSE_DIRT && belowType != Material.MYCELIUM) {
                        player.removePotionEffect(PotionEffectType.RESISTANCE);
                        player.removePotionEffect(PotionEffectType.SPEED);
                    } else {
                        player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 80, 0, true, false));
                        player.setFoodLevel(Math.min(player.getFoodLevel() + 1, 20));
                        if (!player.hasPotionEffect(PotionEffectType.RESISTANCE)) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, -1, 0, true, false));
                        }

                        if (!player.hasPotionEffect(PotionEffectType.SPEED)) {
                            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, -1, 0, true, false));
                        }
                    }
                }

                if (ability == AbilityType.ICE_MAN && movedBlock) {
                    Block iceManBlock = player.getLocation().getBlock().getRelative(BlockFace.DOWN);
                    if (HOT_BIOME_GROUND.contains(iceManBlock.getType())) {
                        String biome = player.getLocation().getBlock().getBiome().name();
                        if (biome.contains("DESERT") || biome.contains("NETHER") || biome.contains("BADLANDS") || biome.contains("SAVANNA") || biome.contains("JUNGLE")) {
                            player.damage(1.0);
                        }
                    }
                }

                if (ability == AbilityType.ENDERLING && this.isInWater(player)) {
                    player.damage(4.0);
                }

                if (ability == AbilityType.THIEF) {
                    player.setInvisible(player.isSneaking());
                }

                if (AbilityManager.isPlayerInFieldWeaverZone(player.getUniqueId())) {
                    double yDiff = event.getTo().getY() - event.getFrom().getY();
                    if (yDiff > 0.0) {
                        Location clamped = event.getTo().clone();
                        clamped.setY(event.getFrom().getY());
                        event.setTo(clamped);
                    }
                }

            }
        }
    }

    @EventHandler
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        if (AbilityManager.isPlayerInFieldWeaverZone(player.getUniqueId())) {
            event.setCancelled(true);
            player.setAllowFlight(false);
            player.setFlying(false);
        }

    }

    private void handleBigStomachEatBlock(Player player) {
        if (AbilityManager.canEatBlock(player)) {
            Block clicked = player.getTargetBlockExact(5);
            if (clicked != null && clicked.getType() != Material.AIR) {
                Material type = clicked.getType();
                if (type != Material.BEDROCK && type != Material.BARRIER && type != Material.COMMAND_BLOCK && type != Material.STRUCTURE_BLOCK && type != Material.END_PORTAL_FRAME && type != Material.END_PORTAL) {
                    clicked.setType(Material.AIR);
                    player.setFoodLevel(Math.min(player.getFoodLevel() + 1, 20));
                    player.setSaturation(Math.min(player.getSaturation() + 0.5F, 20.0F));
                    player.sendMessage("§a你吃了 " + type.name() + " 恢复了一点饱食度");
                    AbilityManager.setBlockEatCooldown(player);
                    player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0F, 1.0F);
                    this.checkBigStomachEffects(player);
                } else {
                    player.sendMessage("§c这个方块不能吃!");
                }
            } else {
                player.sendMessage("§c请对准一个方块!");
            }
        }
    }

    private void handleBigStomachEatAnimal(Player player) {
        if (!AbilityManager.canEatAnimal(player)) {
            player.sendMessage("§c你刚刚才吃过东西!");
        } else {
            Entity target = player.getTargetEntity(10);
            if (target != null && target instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)target;
                if (!living.isDead() && !(living.getHealth() >= 10.0)) {
                    if (target instanceof Player) {
                        Player targetPlayer = (Player)target;
                        if (AbilityManager.isCodeKillProtected(targetPlayer)) {
                            player.sendMessage("§c该玩家受到保护，无法吞噬!");
                            return;
                        }

                        swallowedByTaotie.put(targetPlayer.getUniqueId(), player.getName());
                        AbilityManager.setForcedKiller(targetPlayer.getUniqueId(), player.getUniqueId());
                        targetPlayer.setHealth(0.0);
                        player.sendMessage("§a你吞噬了玩家 " + targetPlayer.getName() + "!");
                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0F, 1.0F);
                        AbilityManager.setAnimalEatCooldown(player);
                        this.checkBigStomachEffects(player);
                        return;
                    }

                    Material food = (Material)ANIMAL_FOOD_MAP.getOrDefault(target.getType(), Material.COOKED_BEEF);
                    int hungerRestore = 0;
                    if (food != Material.COOKED_BEEF && food != Material.COOKED_PORKCHOP && food != Material.COOKED_MUTTON) {
                        if (food != Material.COOKED_CHICKEN && food != Material.COOKED_RABBIT) {
                            hungerRestore = 4;
                        } else {
                            hungerRestore = 6;
                        }
                    } else {
                        hungerRestore = 8;
                    }

                    String var10001 = this.getChineseMobName(target.getType());
                    player.sendMessage("§a你吞噬了 " + var10001 + "! 获得了大量饱食度");
                    player.setFoodLevel(Math.min(player.getFoodLevel() + hungerRestore, 20));
                    player.setSaturation(Math.min(player.getSaturation() + (float)hungerRestore, 20.0F));
                    living.remove();
                    AbilityManager.setAnimalEatCooldown(player);
                    player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0F, 1.0F);
                    this.checkBigStomachEffects(player);
                    return;
                }
            }

            player.sendMessage("§c请对准一个当前血量低于10的生物!");
        }
    }

    private void checkBigStomachEffects(Player player) {
        int foodLevel = player.getFoodLevel();
        player.removePotionEffect(PotionEffectType.STRENGTH);
        player.removePotionEffect(PotionEffectType.RESISTANCE);
        player.removePotionEffect(PotionEffectType.WEAKNESS);
        if (foodLevel >= 20) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, -1, 1, true, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, -1, 1, true, false));
            player.sendMessage("§6[超能力] §a饱食度满! 获得力量II和抗性II!");
        } else if (foodLevel < 3) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, -1, 0, true, false));
        }

    }

    private void handleNatureChildGrowTree(Player player, Block block) {
        if (!AbilityManager.canGrowTree(player)) {
            player.sendMessage("§c种树冷却中!(1秒)");
        } else {
            TreeType tree = RANDOM_TREES[this.random.nextInt(RANDOM_TREES.length)];
            Location treeLoc = block.getLocation().add(0.0, 1.0, 0.0);
            player.getWorld().generateTree(treeLoc, tree);
            AbilityManager.setTreeCooldown(player);
            player.sendMessage("§a一颗树木拔地而起!");
            player.getWorld().playSound(treeLoc, Sound.BLOCK_GRASS_PLACE, 1.0F, 1.0F);
        }
    }

    private void handleFairyDebuff(Player player) {
        if (!AbilityManager.canUseFairyDebuff(player)) {
            player.sendMessage("§c妖精的debuff还在冷却中!(30秒)");
        } else {
            Entity target = player.getTargetEntity(10);
            if (target instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)target;
                if (!target.equals(player)) {
                    living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 200, 1));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 200, 0));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 200, 0));
                    living.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 200, 0));
                    if (living instanceof Player) {
                        Player targetPlayer = (Player)living;
                        targetPlayer.sendMessage("§c你被妖精的魔法击中了! (缓慢II+反胃+失明+黑暗 10秒)");
                    }

                    String var10001 = living instanceof Player ? living.getName() : this.getChineseMobName(living.getType());
                    player.sendMessage("§6[超能力] §a你向 " + var10001 + " 释放了妖精魔法!");
                    AbilityManager.setFairyDebuffCooldown(player);
                    player.getWorld().spawnParticle(Particle.ENCHANT, living.getLocation().add(0.0, 1.0, 0.0), 50, 0.5, 0.5, 0.5, 1.0);
                    return;
                }
            }

            player.sendMessage("§c请对准一个生物!");
        }
    }

    private void handleFireManFireball(Player player) {
        if (!AbilityManager.canFireSkill(player)) {
            player.sendMessage("§c火焰弹冷却中!(5秒)");
        } else {
            Location spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize());
            Fireball fireball = (Fireball)player.getWorld().spawn(spawnLoc, Fireball.class);
            fireball.setShooter(player);
            fireball.setYield(2.0F);
            fireball.setIsIncendiary(true);
            fireball.setVelocity(player.getLocation().getDirection().normalize().multiply(1.5));
            AbilityManager.setFireSkillCooldown(player);
            player.sendMessage("§6[超能力] §c你发射了一枚火焰弹!");
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0F, 1.0F);
        }
    }

    private void handleIceManSnowball(Player player) {
        if (!AbilityManager.canIceSkill(player)) {
            player.sendMessage("§c冰冻雪球冷却中!(5秒)");
        } else {
            Location spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize());
            Snowball snowball = (Snowball)player.getWorld().spawn(spawnLoc, Snowball.class);
            snowball.setShooter(player);
            snowball.setVelocity(player.getLocation().getDirection().normalize().multiply(2));
            snowball.setMetadata("ice_man_snowball", new FixedMetadataValue(Main.getInstance(), true));
            AbilityManager.setIceSkillCooldown(player);
            player.sendMessage("§6[超能力] §b你发射了一颗冰冻雪球!");
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1.0F, 1.0F);
        }
    }

    @EventHandler
    public void onIceManSnowballHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof Snowball snowball) {
            if (snowball.hasMetadata("ice_man_snowball")) {
                ProjectileSource var4 = snowball.getShooter();
                if (var4 instanceof Player) {
                    Player shooter = (Player)var4;
                    Location hitLoc;
                    if (event.getHitBlock() != null) {
                        hitLoc = event.getHitBlock().getLocation().add(0.5, 1.0, 0.5);
                    } else if (event.getHitEntity() != null) {
                        hitLoc = event.getHitEntity().getLocation();
                    } else {
                        hitLoc = snowball.getLocation();
                    }

                    Iterator var5 = hitLoc.getWorld().getNearbyEntities(hitLoc, 5.0, 5.0, 5.0).iterator();

                    while(true) {
                        Entity entity;
                        LivingEntity living;
                        do {
                            do {
                                if (!var5.hasNext()) {
                                    for(int x = -2; x <= 2; ++x) {
                                        for(int z = -2; z <= 2; ++z) {
                                            for(int y = -1; y <= 1; ++y) {
                                                Block block = hitLoc.clone().add((double)x, (double)y, (double)z).getBlock();
                                                if (block.getType() != Material.WATER && block.getType() != Material.WATER_CAULDRON) {
                                                    if (block.getType() == Material.LAVA) {
                                                        block.setType(Material.OBSIDIAN);
                                                    }
                                                } else {
                                                    block.setType(Material.ICE);
                                                    ((Set)this.icePlacedBlocks.computeIfAbsent(shooter.getUniqueId(), (k) -> {
                                                        return new HashSet();
                                                    })).add(block.getLocation());
                                                }
                                            }
                                        }
                                    }

                                    hitLoc.getWorld().spawnParticle(Particle.SNOWFLAKE, hitLoc, 100, 3.0, 2.0, 3.0, 0.0);
                                    hitLoc.getWorld().playSound(hitLoc, Sound.BLOCK_GLASS_BREAK, 1.0F, 1.0F);
                                    return;
                                }

                                entity = (Entity)var5.next();
                            } while(!(entity instanceof LivingEntity));

                            living = (LivingEntity)entity;
                        } while(entity.equals(shooter));

                        living.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 3));
                        living.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, 100, 0));
                        living.setFreezeTicks(140);

                        for(int i = 1; i <= 4; ++i) {
                            LivingEntity livingFinal = living;
                            Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                                if (livingFinal.isValid() && !livingFinal.isDead()) {
                                    livingFinal.damage(1.0, shooter);
                                }

                            }, (long)i * 20L);
                        }

                        if (living instanceof Player) {
                            Player target = (Player)living;
                            target.sendMessage("§b你被冰冻雪球命中! 减速中!");
                        }
                    }
                }
            }
        }
    }

    private void handleBomberThrow(Player player) {
        if (!AbilityManager.canPlaceTNT(player)) {
            player.sendMessage("§c炸弹冷却中!(3秒)");
        } else {
            ItemStack[] contents = player.getInventory().getContents();
            List<Integer> nonEmptySlots = new ArrayList();

            int i;
            for(i = 0; i < contents.length; ++i) {
                if (contents[i] != null && contents[i].getType() != Material.AIR) {
                    nonEmptySlots.add(i);
                }
            }

            if (nonEmptySlots.size() < 3) {
                player.sendMessage("§c背包里至少需要3个物品才能使用!");
            } else {
                for(i = 0; i < 3; ++i) {
                    ItemStack[] cur = player.getInventory().getContents();
                    List<Integer> available = new ArrayList();

                    int s;
                    for(s = 0; s < cur.length; ++s) {
                        if (cur[s] != null && cur[s].getType() != Material.AIR) {
                            available.add(s);
                        }
                    }

                    if (available.isEmpty()) {
                        break;
                    }

                    s = (Integer)available.get(this.random.nextInt(available.size()));
                    ItemStack removed = cur[s].clone();
                    removed.setAmount(1);
                    player.getInventory().removeItem(new ItemStack[]{removed});
                }

                AbilityManager.setTntCooldown(player);
                Location spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize());
                Snowball snowball = (Snowball)player.getWorld().spawn(spawnLoc, Snowball.class);
                snowball.setShooter(player);
                snowball.setVelocity(player.getLocation().getDirection().normalize().multiply(2.0));
                snowball.setMetadata("bomber_snowball", new FixedMetadataValue(Main.getInstance(), true));
                player.sendMessage("§6[超能力] §a你消耗了3个物品，发射了一颗炸弹雪球!");
                player.getWorld().playSound(player.getLocation(), Sound.ENTITY_SNOWBALL_THROW, 1.0F, 1.0F);
            }
        }
    }

    @EventHandler
    public void onBomberSnowballHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof Snowball snowball) {
            if (snowball.hasMetadata("bomber_snowball")) {
                ProjectileSource var4 = snowball.getShooter();
                if (var4 instanceof Player) {
                    Player player = (Player)var4;
                    if (AbilityManager.getAbility(player) == AbilityType.BOMBER) {
                        Location hitLoc;
                        if (event.getHitBlock() != null) {
                            hitLoc = event.getHitBlock().getLocation().add(0.5, 0.5, 0.5);
                        } else if (event.getHitEntity() != null) {
                            hitLoc = event.getHitEntity().getLocation();
                        } else {
                            hitLoc = snowball.getLocation();
                        }

                        player.getWorld().createExplosion(player, hitLoc, 4.0F, true, true);
                        player.getWorld().playSound(hitLoc, Sound.ENTITY_GENERIC_EXPLODE, 1.0F, 1.0F);
                        this.trackCitizenCrime(player.getUniqueId(), "explode", 5);
                    }
                }
            }
        }
    }

    private void handleEnderlingPearl(Player player) {
        if (!AbilityManager.canThrowPearl(player)) {
            player.sendMessage("§c末影珍珠冷却中!(1秒)");
        } else {
            Location spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize());
            Snowball pearl = (Snowball)player.getWorld().spawn(spawnLoc, Snowball.class);
            pearl.setShooter(player);
            pearl.setVelocity(player.getLocation().getDirection().normalize().multiply(3.0));
            pearl.setMetadata("enderling_pearl", new FixedMetadataValue(Main.getInstance(), true));
            AbilityManager.setPearlCooldown(player);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_PEARL_THROW, 1.0F, 1.0F);
        }
    }

    @EventHandler
    public void onEnderlingFallDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var4 = AbilityManager.getAbility(player);
            if (var4 == AbilityType.ENDERLING) {
                if (event.getCause() == DamageCause.FALL) {
                    event.setCancelled(true);
                }

            }
        }
    }

    @EventHandler
    public void onEnderlingProjectileHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof Snowball snowball) {
            if (snowball.hasMetadata("enderling_pearl")) {
                ProjectileSource var4 = snowball.getShooter();
                if (var4 instanceof Player) {
                    Player player = (Player)var4;
                    if (AbilityManager.getAbility(player) == AbilityType.ENDERLING) {
                        Location hitLoc;
                        if (event.getHitBlock() != null) {
                            hitLoc = event.getHitBlock().getLocation().add(0.5, 1.0, 0.5);
                        } else if (event.getHitEntity() != null) {
                            hitLoc = event.getHitEntity().getLocation();
                        } else {
                            hitLoc = snowball.getLocation();
                        }

                        Location safeLoc = hitLoc.clone();
                        Block hitBlock = safeLoc.getBlock();
                        Block above = safeLoc.clone().add(0.0, 1.0, 0.0).getBlock();
                        if (hitBlock.getType().isSolid() || hitBlock.isLiquid()) {
                            safeLoc.add(0.0, 1.0, 0.0);
                            above = safeLoc.clone().add(0.0, 1.0, 0.0).getBlock();
                        }

                        if (!above.getType().isSolid() && !above.isLiquid()) {
                            safeLoc.setYaw(player.getLocation().getYaw());
                            safeLoc.setPitch(player.getLocation().getPitch());
                            player.teleport(safeLoc);
                        } else {
                            Location highestLoc = player.getWorld().getHighestBlockAt(safeLoc).getLocation().add(0.5, 1.0, 0.5);
                            highestLoc.setYaw(player.getLocation().getYaw());
                            highestLoc.setPitch(player.getLocation().getPitch());
                            player.teleport(highestLoc);
                        }

                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                    }
                }
            }
        }
    }

    private void handleSpiderManWeb(Player player) {
        if (!AbilityManager.canShootWeb(player)) {
            player.sendMessage("§c蛛网冷却中!(2秒)");
        } else {
            Block targetBlock = player.getTargetBlockExact(30);
            if (targetBlock == null) {
                player.sendMessage("§c请对准一个位置(最远30格)");
            } else {
                BlockFace targetFace = player.getTargetBlockFace(30);
                Location webLoc;
                if (targetFace != null) {
                    webLoc = targetBlock.getRelative(targetFace).getLocation();
                } else {
                    webLoc = targetBlock.getRelative(BlockFace.UP).getLocation();
                }

                Block webBlock = webLoc.getBlock();
                if (webBlock.getType() != Material.AIR) {
                    player.sendMessage("§c目标位置没有足够空间放置蛛网!");
                } else {
                    webBlock.setType(Material.COBWEB);
                    ((List)this.spiderWebs.computeIfAbsent(player.getUniqueId(), (k) -> {
                        return new ArrayList();
                    })).add(webLoc);
                    AbilityManager.setWebCooldown(player);
                    player.sendMessage("§6[超能力] §f你发射了蛛网!");
                    player.getWorld().spawnParticle(Particle.CLOUD, webLoc.add(0.5, 0.5, 0.5), 30, 0.5, 0.5, 0.5, 0.05);
                    Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                        Block block = webLoc.getBlock();
                        if (block.getType() == Material.COBWEB) {
                            block.setType(Material.AIR);
                        }

                    }, 300L);
                }
            }
        }
    }

    private void spawnSpiderParticleLine(Location from, Location to, World world) {
        Vector direction = to.toVector().subtract(from.toVector());
        double length = direction.length();
        direction.normalize();
        int steps = Math.max((int)(length * 2.0), 1);

        for(int i = 0; i <= steps; ++i) {
            Location point = from.clone().add(direction.clone().multiply(length * (double)i / (double)steps));
            world.spawnParticle(Particle.END_ROD, point, 1, 0.0, 0.0, 0.0, 0.0);
        }

    }

    private void handleSpiderManPull(final Player player) {
        if (!AbilityManager.canPullWeb(player)) {
            player.sendMessage("§c蛛丝冷却中!(2秒)");
        } else {
            LivingEntity targetLiving = null;
            Entity targetEntity = player.getTargetEntity(50);
            if (targetEntity instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)targetEntity;
                if (!living.equals(player)) {
                    targetLiving = living;
                }
            }

            Location targetLoc;
            Block targetBlock;
            if (targetLiving == null) {
                targetBlock = player.getTargetBlockExact(50);
                if (targetBlock != null) {
                    targetLoc = targetBlock.getLocation().add(0.5, 0.5, 0.5);
                    Iterator var6 = player.getWorld().getNearbyEntities(targetLoc, 2.5, 2.5, 2.5).iterator();

                    while(var6.hasNext()) {
                        Entity entity = (Entity)var6.next();
                        if (entity instanceof LivingEntity) {
                            LivingEntity le = (LivingEntity)entity;
                            if (!le.equals(player)) {
                                targetLiving = le;
                                break;
                            }
                        }
                    }
                }
            }

            if (targetLiving != null) {
                final LivingEntity finalTarget = targetLiving;
                AbilityManager.setPullCooldown(player);
                this.spawnSpiderParticleLine(player.getLocation().add(0.0, 1.0, 0.0), finalTarget.getLocation().add(0.0, 1.0, 0.0), player.getWorld());
                String var10001 = finalTarget instanceof Player ? finalTarget.getName() : this.getChineseMobName(finalTarget.getType());
                player.sendMessage("§6[超能力] §f你发射了蛛丝,将 " + var10001 + " 拉向自己!");
                (new BukkitRunnable() {
                    int ticks = 0;

                    public void run() {
                        ++this.ticks;
                        if (player.isOnline() && finalTarget.isValid() && !finalTarget.isDead() && this.ticks <= 100) {
                            double distanceSquared = finalTarget.getLocation().distanceSquared(player.getLocation());
                            Vector direction;
                            if (distanceSquared < 1.5) {
                                direction = new Vector(0.0, 0.3, 0.0);
                                finalTarget.setVelocity(direction);
                                this.cancel();
                            } else {
                                if (this.ticks % 4 == 0) {
                                    AbilityListener.this.spawnSpiderParticleLine(player.getLocation().add(0.0, 1.0, 0.0), finalTarget.getLocation().add(0.0, 1.0, 0.0), player.getWorld());
                                }

                                direction = player.getLocation().toVector().subtract(finalTarget.getLocation().toVector()).normalize();
                                double speed = Math.min(0.8 + distanceSquared * 0.02, 3.5);
                                finalTarget.setVelocity(direction.multiply(speed));
                                finalTarget.setFallDistance(0.0F);
                            }
                        } else {
                            this.cancel();
                        }
                    }
                }).runTaskTimer(Main.getInstance(), 0L, 1L);
            } else {
                targetBlock = player.getTargetBlockExact(50);
                if (targetBlock == null) {
                    player.sendMessage("§c请对准一个方块或生物(最远50格)");
                } else {
                    targetLoc = targetBlock.getLocation().add(0.5, 0.5, 0.5);
                    player.setFallDistance(0.0F);
                    AbilityManager.setPullCooldown(player);
                    this.spawnSpiderParticleLine(player.getLocation().add(0.0, 1.0, 0.0), targetLoc, player.getWorld());
                    player.sendMessage("§6[超能力] §f你发射了蛛丝,被拉向目标!");
                    player.setAllowFlight(true);
                    player.setFlying(true);
                    Location targetLocFinal = targetLoc;
                    Block targetBlockFinal = targetBlock;
                    (new BukkitRunnable() {
                        int ticks = 0;

                        public void run() {
                            ++this.ticks;
                            if (player.isOnline() && this.ticks <= 100) {
                                Location playerLoc = player.getLocation();
                                double distanceSquared = playerLoc.distanceSquared(targetLocFinal);
                                Block playerBlock = playerLoc.getBlock();
                                if (distanceSquared < 1.5 || playerBlock.getX() == targetBlockFinal.getX() && playerBlock.getY() == targetBlockFinal.getY() && playerBlock.getZ() == targetBlockFinal.getZ()) {
                                    player.setFlying(false);
                                    player.setAllowFlight(false);
                                    this.cancel();
                                } else {
                                    if (this.ticks % 4 == 0) {
                                        AbilityListener.this.spawnSpiderParticleLine(player.getLocation().add(0.0, 1.0, 0.0), targetLocFinal, player.getWorld());
                                    }

                                    Vector direction = targetLocFinal.toVector().subtract(playerLoc.toVector()).normalize();
                                    double distance = Math.sqrt(distanceSquared);
                                    double moveAmount = Math.min(0.8 + distance * 0.04, 3.0);
                                    Location newLoc = playerLoc.add(direction.multiply(moveAmount));
                                    player.teleport(newLoc);
                                    player.setFallDistance(0.0F);
                                }
                            } else {
                                if (player.isOnline()) {
                                    player.setFlying(false);
                                    player.setAllowFlight(false);
                                }

                                this.cancel();
                            }
                        }
                    }).runTaskTimer(Main.getInstance(), 0L, 1L);
                    Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                        if (player.isOnline()) {
                            player.setFlying(false);
                            player.setAllowFlight(false);
                        }

                    }, 120L);
                }
            }
        }
    }

    private void handleThiefStealFromPlayer(Player player, Player targetPlayer) {
        if (player.getGameMode() != GameMode.SPECTATOR) {
            if (targetPlayer.getGameMode() == GameMode.SPECTATOR) {
                player.sendMessage("§c目标玩家已死亡!");
            } else if (!AbilityManager.canStealItem(player)) {
                player.sendMessage("§c偷窃冷却中!(10秒)");
            } else {
                ItemStack[] contents = targetPlayer.getInventory().getContents();
                List<ItemStack> nonEmpty = new ArrayList();
                ItemStack[] var5 = contents;
                int var6 = contents.length;

                for(int var7 = 0; var7 < var6; ++var7) {
                    ItemStack item = var5[var7];
                    if (item != null && item.getType() != Material.AIR) {
                        nonEmpty.add(item);
                    }
                }

                if (nonEmpty.isEmpty()) {
                    player.sendMessage("§c目标玩家背包是空的!");
                } else {
                    ItemStack stolen = (ItemStack)nonEmpty.get(this.random.nextInt(nonEmpty.size()));
                    ItemStack stolenClone = stolen.clone();
                    stolenClone.setAmount(1);
                    targetPlayer.getInventory().removeItem(new ItemStack[]{stolenClone});
                    player.getInventory().addItem(new ItemStack[]{stolenClone});
                    String var10001 = targetPlayer.getName();
                    player.sendMessage("§6[超能力] §a你从 " + var10001 + " 那里偷到了 " + stolenClone.getType().name());
                    var10001 = stolenClone.getType().name();
                    targetPlayer.sendMessage("§6[超能力] §c你的 " + var10001 + " 被 " + player.getName() + " 偷走了!");
                    AbilityManager.setItemStealCooldown(player);
                }
            }
        }
    }

    private void handleThiefStealFromMob(Player player, LivingEntity target) {
        if (player.getGameMode() != GameMode.SPECTATOR) {
            if (!AbilityManager.canStealItem(player)) {
                player.sendMessage("§c偷窃冷却中!(10秒)");
            } else {
                if (target.hasMetadata("thief_used")) {
                    target.removeMetadata("thief_used", Main.getInstance());
                }

                target.setMetadata("thief_used", new FixedMetadataValue(Main.getInstance(), true));
                Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                    if (target.isValid()) {
                        target.removeMetadata("thief_used", Main.getInstance());
                    }

                }, 1200L);
                List<ItemStack> dropList = new ArrayList();
                ItemStack[] var4 = this.generateMobDrops(target.getType());
                int var5 = var4.length;

                for(int var6 = 0; var6 < var5; ++var6) {
                    ItemStack drop = var4[var6];
                    if (drop != null && drop.getType() != Material.AIR && drop.getAmount() > 0) {
                        dropList.add(drop);
                    }
                }

                String var10001;
                if (!dropList.isEmpty()) {
                    ItemStack drop = (ItemStack)dropList.get(this.random.nextInt(dropList.size()));
                    player.getInventory().addItem(new ItemStack[]{drop});
                    var10001 = this.getChineseMobName(target.getType());
                    player.sendMessage("§6[超能力] §a你从 " + var10001 + " 那里偷到了 " + drop.getType().name());
                } else {
                    var10001 = this.getChineseMobName(target.getType());
                    player.sendMessage("§6[超能力] §a你从 " + var10001 + " 那里什么都偷不到...");
                }

                AbilityManager.setItemStealCooldown(player);
            }
        }
    }

    private void handleThiefLifeSteal(Player player) {
        if (!AbilityManager.canStealLife(player)) {
            player.sendMessage("§c生命窃取冷却中!(30秒)");
        } else {
            Entity target = player.getTargetEntity(8);
            if (target instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)target;
                if (!target.equals(player)) {
                    String var10001;
                    if (target instanceof Player) {
                        Player targetPlayer = (Player)target;
                        if (AbilityManager.isCodeKillProtected(targetPlayer)) {
                            player.sendMessage("§c该玩家受到保护，无法窃取!");
                            return;
                        }

                        if (this.random.nextBoolean()) {
                            int stealAmount = 3 + this.random.nextInt(13);
                            double currentHealth = targetPlayer.getHealth();
                            if (currentHealth <= (double)stealAmount) {
                                AbilityManager.setForcedKiller(targetPlayer.getUniqueId(), player.getUniqueId());
                                targetPlayer.setHealth(0.0);
                                player.sendMessage("§6[超能力] §c你窃取了 " + targetPlayer.getName() + " 的全部生命! 目标死亡!");
                            } else {
                                targetPlayer.setHealth(currentHealth - (double)stealAmount);
                                player.setHealth(Math.min(player.getHealth() + (double)stealAmount, player.getMaxHealth()));
                                var10001 = targetPlayer.getName();
                                player.sendMessage("§6[超能力] §a你窃取了 " + var10001 + " 的 " + String.format("%.1f", (double)stealAmount / 2.0) + " 颗心!");
                                var10001 = String.format("%.1f", (double)stealAmount / 2.0);
                                targetPlayer.sendMessage("§6[超能力] §c你的 " + var10001 + " 颗心被 " + player.getName() + " 窃取了!");
                            }
                        } else {
                            Collection<PotionEffectType> activeEffects = targetPlayer.getActivePotionEffects().stream().map(PotionEffect::getType).toList();
                            if (activeEffects.isEmpty()) {
                                player.sendMessage("§c目标没有可窃取的buff!");
                                return;
                            }

                            List<PotionEffectType> effectList = new ArrayList(activeEffects);
                            PotionEffectType stolen = (PotionEffectType)effectList.get(this.random.nextInt(effectList.size()));
                            PotionEffect currentEffect = targetPlayer.getPotionEffect(stolen);
                            if (currentEffect != null) {
                                targetPlayer.removePotionEffect(stolen);
                                UUID uuid = player.getUniqueId();
                                PotionEffectType existing = AbilityManager.getStolenBuff(uuid);
                                if (existing != null) {
                                    player.removePotionEffect(existing);
                                }

                                player.addPotionEffect(new PotionEffect(stolen, currentEffect.getDuration(), 0, true, false));
                                AbilityManager.setStolenBuff(uuid, stolen);
                                var10001 = targetPlayer.getName();
                                player.sendMessage("§6[超能力] §a你窃取了 " + var10001 + " 的 " + this.getBuffEffectName(stolen) + " 效果!");
                                var10001 = this.getBuffEffectName(stolen);
                                targetPlayer.sendMessage("§6[超能力] §c你的 " + var10001 + " 效果被 " + player.getName() + " 窃取了!");
                            }
                        }
                    } else if (target instanceof LivingEntity) {
                        LivingEntity mob = (LivingEntity)target;
                        if (!target.equals(player)) {
                            double stealAmount = (double)(3 + this.random.nextInt(13));
                            double currentHealth = mob.getHealth();
                            if (currentHealth <= stealAmount) {
                                mob.setHealth(0.0);
                                var10001 = this.getChineseMobName(mob.getType());
                                player.sendMessage("§6[超能力] §c你窃取了 " + var10001 + " 的全部生命!");
                            } else {
                                mob.setHealth(currentHealth - stealAmount);
                                player.setHealth(Math.min(player.getHealth() + stealAmount, player.getMaxHealth()));
                                var10001 = this.getChineseMobName(mob.getType());
                                player.sendMessage("§6[超能力] §a你窃取了 " + var10001 + " 的 " + String.format("%.1f", stealAmount / 2.0) + " 颗心!");
                            }
                        }
                    }

                    AbilityManager.setLifeStealCooldown(player);
                    return;
                }
            }

            player.sendMessage("§c请对准一个玩家或生物!");
        }
    }

    @EventHandler
    public void onRubberManDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var4 = AbilityManager.getAbility(player);
            if (var4 == AbilityType.RUBBER_MAN) {
                if (event.getCause() == DamageCause.FALL) {
                    event.setCancelled(true);
                } else {
                    if (event.getCause() == DamageCause.FIRE || event.getCause() == DamageCause.FIRE_TICK || event.getCause() == DamageCause.LAVA || event.getCause() == DamageCause.HOT_FLOOR) {
                        event.setDamage(event.getDamage() * 2.0);
                    }

                }
            }
        }
    }

    @EventHandler
    public void onRubberManSharpness(EntityDamageByEntityEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var7 = AbilityManager.getAbility(player);
            if (var7 == AbilityType.RUBBER_MAN) {
                ItemStack weapon = null;
                Entity var6 = event.getDamager();
                if (var6 instanceof Player) {
                    Player attacker = (Player)var6;
                    weapon = attacker.getInventory().getItemInMainHand();
                }

                if (weapon != null) {
                    Iterator var8 = weapon.getEnchantments().keySet().iterator();

                    while(var8.hasNext()) {
                        Enchantment ench = (Enchantment)var8.next();
                        if (ench.getKey().getKey().contains("sharpness")) {
                            event.setDamage(event.getDamage() * 2.0);
                            break;
                        }
                    }
                }

            }
        }
    }

    @EventHandler
    public void onRubberManFireTick(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var4 = AbilityManager.getAbility(player);
            if (var4 == AbilityType.RUBBER_MAN) {
                if (event.getCause() == DamageCause.FIRE_TICK) {
                    if (this.isInWater(player)) {
                        player.setFireTicks(0);
                    } else {
                        player.setFireTicks(99999);
                    }
                }

            }
        }
    }

    @EventHandler
    public void onQuantumManDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            if (AbilityManager.isRestoringQuantumDamage(player.getUniqueId())) return;
            AbilityType var5 = AbilityManager.getAbility(player);
            if (var5 == AbilityType.QUANTUM_MAN) {
                if (!event.isCancelled()) {
                    if (!(event.getDamage() <= 0.0)) {
                        if (AbilityManager.isQuantumState(player.getUniqueId())) {
                            event.setCancelled(true);
                        } else {
                            if (this.random.nextDouble() < 0.4) {
                                double rawDamage = event.getDamage();
                                event.setCancelled(true);
                                AbilityManager.setQuantumState(player, 5000L, rawDamage);
                                BukkitTask task = Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                                    if (AbilityManager.getAbility(player) == AbilityType.QUANTUM_MAN) {
                                        AbilityManager.restoreFromQuantum(player);
                                        player.sendMessage("§6[超能力] §a你从量子态恢复了!");
                                    }

                                }, 100L);
                                this.quantumRestoreTasks.put(player.getUniqueId(), task);
                                player.sendMessage("§6[超能力] §d你进入了量子态! (旁观模式5秒)");
                            }

                        }
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEnderlingProjectileDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var7 = AbilityManager.getAbility(player);
            if (var7 == AbilityType.ENDERLING) {
                if (event.getDamager() instanceof Projectile) {
                    event.setCancelled(true);
                    Location teleportLoc = player.getLocation().add(this.random.nextDouble() * 10.0 - 5.0, 0.0, this.random.nextDouble() * 10.0 - 5.0);
                    Block teleportBlock = teleportLoc.getBlock();
                    if (teleportBlock.getType().isSolid() || teleportBlock.isLiquid()) {
                        teleportLoc = player.getWorld().getHighestBlockAt(teleportLoc).getLocation().add(0.5, 1.0, 0.5);
                    }

                    Block aboveTeleport = teleportLoc.clone().add(0.0, 1.0, 0.0).getBlock();
                    if (aboveTeleport.getType().isSolid() || aboveTeleport.isLiquid()) {
                        teleportLoc = player.getWorld().getHighestBlockAt(teleportLoc).getLocation().add(0.5, 1.0, 0.5);
                    }

                    player.teleport(teleportLoc);
                    player.getWorld().playSound(teleportLoc, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                    player.sendMessage("§6[超能力] §d你被远程攻击击中,自动瞬移躲避!");
                }

            }
        }
    }

    private void handleBlacksmithEnchant(Player player) {
        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (offHand.getType() == Material.LAPIS_LAZULI) {
            ItemStack mainHand = player.getInventory().getItemInMainHand();
            if (mainHand.getType() != Material.AIR) {
                UUID itemId = this.getItemUUID(mainHand);
                int usedCount = (Integer)this.enchantCounts.getOrDefault(itemId, 0);
                if (usedCount >= 3) {
                    player.sendMessage("§c这件装备已经使用了3次附魔机会，无法再附魔!");
                } else {
                    List<Enchantment> applicable = new ArrayList();
                    Iterator var7 = Registry.ENCHANTMENT.iterator();

                    while(var7.hasNext()) {
                        Enchantment enchantment = (Enchantment)var7.next();

                        try {
                            if (enchantment.canEnchantItem(mainHand)) {
                                applicable.add(enchantment);
                            }
                        } catch (Exception var14) {
                        }
                    }

                    if (applicable.isEmpty()) {
                        player.sendMessage("§c这个物品无法被附魔");
                    } else {
                        int enchantCount = 1 + this.random.nextInt(Math.min(3, applicable.size()));
                        List<Enchantment> selected = new ArrayList();
                        List<Enchantment> pool = new ArrayList(applicable);
                        StringBuilder message = new StringBuilder("§a✨ 随机附魔成功! (剩余" + (2 - usedCount) + "次)");

                        Enchantment enchantment;
                        for(int i = 0; i < enchantCount && !pool.isEmpty(); ++i) {
                            enchantment = (Enchantment)pool.remove(this.random.nextInt(pool.size()));
                            selected.add(enchantment);
                        }

                        Iterator var17 = selected.iterator();

                        while(var17.hasNext()) {
                            enchantment = (Enchantment)var17.next();
                            int level = 1 + this.random.nextInt(enchantment.getMaxLevel());
                            mainHand.addUnsafeEnchantment(enchantment, level);
                            message.append("\n§7  - §f").append(this.getChineseEnchantName(enchantment)).append(" ").append(this.toRoman(level));
                        }

                        offHand.setAmount(offHand.getAmount() - 1);
                        player.getInventory().setItemInOffHand(offHand);
                        this.enchantCounts.put(itemId, usedCount + 1);
                        player.sendMessage(message.toString());
                    }
                }
            }
        }
    }

    private UUID getItemUUID(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            NamespacedKey key = new NamespacedKey(Main.getInstance(), "item_uuid");
            if (meta.getPersistentDataContainer().has(key, PersistentDataType.STRING)) {
                return UUID.fromString((String)meta.getPersistentDataContainer().get(key, PersistentDataType.STRING));
            } else {
                UUID uuid = UUID.randomUUID();
                meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, uuid.toString());
                item.setItemMeta(meta);
                return uuid;
            }
        } else {
            return UUID.randomUUID();
        }
    }

    @EventHandler
    public void onAntManDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player player) {
            AbilityType var6 = AbilityManager.getAbility(player);
            if (var6 == AbilityType.ANT_MAN) {
                if (AbilityManager.isAntManShrunk(player)) {
                    Entity var5 = event.getEntity();
                    if (var5 instanceof LivingEntity) {
                        LivingEntity target = (LivingEntity)var5;
                        event.setDamage(4.0);
                        String var10001 = target instanceof Player ? target.getName() : this.getChineseMobName(target.getType());
                        player.sendMessage("§6[超能力] §a蚁人真伤! 对 " + var10001 + " 造成了2颗心的伤害!");
                    }
                }
            }
        }
    }

    @EventHandler
    public void onIceManMelee(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player player) {
            AbilityType var6 = AbilityManager.getAbility(player);
            if (var6 == AbilityType.ICE_MAN) {
                Entity var5 = event.getEntity();
                if (var5 instanceof LivingEntity) {
                    LivingEntity target = (LivingEntity)var5;
                    if (this.random.nextDouble() < 0.25) {
                        target.setFreezeTicks(140);
                        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 2));
                        if (target instanceof Player) {
                            Player targetPlayer = (Player)target;
                            targetPlayer.sendMessage("§b你被冰人冻结了!");
                        }

                        player.sendMessage("§6[超能力] §b冰冻效果触发!");
                    }

                }
            }
        }
    }

    @EventHandler
    public void onFireManMelee(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player player) {
            AbilityType var6 = AbilityManager.getAbility(player);
            if (var6 == AbilityType.FIRE_MAN) {
                Entity var5 = event.getEntity();
                if (var5 instanceof LivingEntity) {
                    LivingEntity target = (LivingEntity)var5;
                    target.setFireTicks(100);
                }
            }
        }
    }

    @EventHandler
    public void onFireManWaterDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var4 = AbilityManager.getAbility(player);
            if (var4 == AbilityType.FIRE_MAN) {
                if (this.isInWater(player) && (event.getCause() == DamageCause.DROWNING || event.getCause() == DamageCause.SUFFOCATION)) {
                    event.setCancelled(true);
                }

            }
        }
    }

    private void handleAoeAttack(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        double attackDamage = this.getItemAttackDamage(item);
        if (!(attackDamage <= 0.0)) {
            Location playerLocation = player.getLocation();
            int mobCount = 0;
            Iterator var7 = player.getNearbyEntities(5.0, 5.0, 5.0).iterator();

            while(true) {
                Entity entity;
                LivingEntity livingEntity;
                do {
                    do {
                        do {
                            if (!var7.hasNext()) {
                                if (mobCount > 0 && item.getType() != Material.AIR) {
                                    ItemMeta var11 = item.getItemMeta();
                                    if (var11 instanceof Damageable) {
                                        Damageable damageable = (Damageable)var11;
                                        if (item.getType().getMaxDurability() > 0) {
                                            int newDamage = damageable.getDamage() + mobCount;
                                            if (newDamage >= item.getType().getMaxDurability()) {
                                                item.setAmount(0);
                                            } else {
                                                damageable.setDamage(newDamage);
                                                item.setItemMeta(damageable);
                                            }
                                        }
                                    }
                                }

                                return;
                            }

                            entity = (Entity)var7.next();
                        } while(!(entity instanceof LivingEntity));

                        livingEntity = (LivingEntity)entity;
                    } while(entity.equals(player));
                } while(entity instanceof Player && ((Player)entity).getGameMode() == GameMode.SPECTATOR);

                if (livingEntity.getLocation().distance(playerLocation) <= 5.0) {
                    livingEntity.damage(attackDamage, player);
                    ++mobCount;
                }
            }
        }
    }

    private double getItemAttackDamage(ItemStack item) {
        if (item != null && item.getType() != Material.AIR) {
            Multimap<Attribute, AttributeModifier> attributes = item.getType().getDefaultAttributeModifiers(EquipmentSlot.HAND);
            if (attributes != null && attributes.containsKey(Attribute.ATTACK_DAMAGE)) {
                double totalDamage = 0.0;

                AttributeModifier modifier;
                for(Iterator var5 = attributes.get(Attribute.ATTACK_DAMAGE).iterator(); var5.hasNext(); totalDamage += modifier.getAmount()) {
                    modifier = (AttributeModifier)var5.next();
                }

                return totalDamage;
            } else {
                return 1.0;
            }
        } else {
            return 2.0;
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onTotemDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var7 = AbilityManager.getAbility(player);
            if (var7 == AbilityType.TOTEM_BODY) {
                if (player.getGameMode() != GameMode.CREATIVE && player.getGameMode() != GameMode.SPECTATOR) {
                    if (!AbilityManager.isAbilityDisabledByGodsLeftHand(player.getUniqueId())) {
                        double finalDamage = event.getFinalDamage();
                        if (!(player.getHealth() - finalDamage > 0.0)) {
                            ItemStack mainHand = player.getInventory().getItemInMainHand();
                            if (mainHand.getType() != Material.AIR) {
                                if (AbilityManager.hasUsedTotemItem(player, mainHand.getType())) {
                                    player.sendMessage("§c这个物品已经使用过了，无法再次触发图腾效果!");
                                } else {
                                    event.setCancelled(true);
                                    player.setHealth(1.0);
                                    player.clearActivePotionEffects();
                                    player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 900, 1));
                                    player.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
                                    player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 800, 0));
                                    player.getWorld().playSound(player.getLocation(), Sound.ITEM_TOTEM_USE, 1.0F, 1.0F);
                                    player.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, player.getLocation().add(0.0, 1.0, 0.0), 100, 0.5, 0.5, 0.5, 0.1);
                                    AbilityManager.markTotemItemUsed(player, mainHand.getType());
                                    if (mainHand.getAmount() > 1) {
                                        mainHand.setAmount(mainHand.getAmount() - 1);
                                    } else {
                                        player.getInventory().setItemInMainHand((ItemStack)null);
                                    }

                                    String var10001 = this.getMaterialName(mainHand.getType());
                                    player.sendMessage("§6[超能力] §a图腾之体触发! " + var10001 + " 救了你一命!");
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private boolean isOreEaterFood(Material material) {
        return material == Material.NETHERITE_INGOT || material == Material.NETHERITE_BLOCK || ORE_EFFECTS.containsKey(material);
    }

    private void handleOreEat(Player player) {
        ItemStack item = player.getInventory().getItemInOffHand();
        if (item != null && item.getType() != Material.AIR) {
            Material type = item.getType();
            if (type == Material.NETHERITE_INGOT) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 1200, 254, false, true, true));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 1200, 254, false, true, true));
                player.sendMessage("§5↑ 你吃了下界合金锭获得1分钟无敌");
                this.playEatSound(player);
                this.spawnParticles(player);
                this.consumeOffHand(player);
            } else if (type == Material.NETHERITE_BLOCK) {
                player.sendMessage("§5↑ 你吃了下界合金块，但块只能用于升级，没有效果");
                this.playEatSound(player);
                this.consumeOffHand(player);
            } else {
                boolean isBlock = type.name().endsWith("_BLOCK");
                PotionEffectType effect = (PotionEffectType)ORE_EFFECTS.get(type);
                if (effect != null) {
                    String var10001;
                    if (isBlock) {
                        String oreKey = (String)ORE_KEYS.get(type);
                        if (oreKey == null) {
                            return;
                        }

                        int blockCount = AbilityManager.getOreBlockEatCount(player.getUniqueId(), oreKey) + 1;
                        AbilityManager.incrementOreBlockEatCount(player.getUniqueId(), oreKey);
                        if (blockCount % 5 == 0) {
                            int newLevel = AbilityManager.getOreLevel(player.getUniqueId(), oreKey);
                            var10001 = this.getOreDisplayName(oreKey);
                            player.sendMessage("§6[超能力] §a食矿者 " + var10001 + " 等级提升! 当前等级: §e" + newLevel);
                        } else {
                            var10001 = this.getOreName(type);
                            player.sendMessage("§a↑ 你吃了" + var10001 + "块 (" + blockCount + "/5)");
                        }

                        this.playEatSound(player);
                        this.consumeOffHand(player);
                    } else {
                        if (!AbilityManager.canEatOre(player, type)) {
                            player.sendMessage("§c这种矿石还在冷却中(1分钟)! 请稍后再吃");
                            return;
                        }

                        String oreKey = this.getOreKey(type);
                        int oreLevel = AbilityManager.getOreLevel(player.getUniqueId(), oreKey);
                        int amplifier = oreLevel;
                        player.addPotionEffect(new PotionEffect(effect, 1200, amplifier, false, true, true));
                        var10001 = this.getOreName(type);
                        String levelInfo = amplifier > 0 ? " (等级" + (amplifier + 1) + ")" : "";
                        player.sendMessage("§a↑ 你吃了" + var10001 + "获得1分钟效果" + levelInfo);
                        AbilityManager.setOreCooldown(player, type);
                        this.playEatSound(player);
                        this.spawnParticles(player);
                        this.consumeOffHand(player);
                    }

                }
            }
        }
    }

    private void handleRichManSummon(Player player) {
        ItemStack item = player.getInventory().getItemInOffHand();
        if (item != null && item.getType() != Material.AIR) {
            if (item.getType() == Material.DIAMOND_BLOCK) {
                UUID uuid = player.getUniqueId();
                int count = AbilityManager.getRichManDiamondCount(uuid) + 1;
                AbilityManager.incrementRichManDiamondCount(uuid);
                this.consumeOffHand(player);
                player.getWorld().playSound(player.getLocation(), Sound.BLOCK_METAL_HIT, 1.0F, 1.0F);
                if (count % 5 == 0) {
                    AbilityManager.spawnSingleGolemForRichMan(player);
                } else {
                    int remaining = 5 - count % 5;
                    player.sendMessage("§6[超能力] §a消耗了1个钻石块 §7(" + count + "/5, 还需 §e" + remaining + " §7个召唤保镖)");
                }

            }
        }
    }

    private void consumeOffHand(Player player) {
        ItemStack hand = player.getInventory().getItemInOffHand();
        if (hand.getAmount() > 1) {
            hand.setAmount(hand.getAmount() - 1);
            player.getInventory().setItemInOffHand(hand);
        } else {
            player.getInventory().setItemInOffHand((ItemStack)null);
        }

    }

    private void playEatSound(Player player) {
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 1.0F, 1.0F);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_BURP, 1.0F, 1.2F);
    }

    private void spawnParticles(Player player) {
        player.getWorld().spawnParticle(Particle.ENCHANT, player.getLocation().add(0.0, 1.0, 0.0), 30, 0.5, 0.5, 0.5, 1.0);
    }

    @EventHandler(
            priority = EventPriority.HIGHEST
    )
    public void onDamageExplosion(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var7 = AbilityManager.getAbility(player);
            if (var7 == AbilityType.DAMAGE_EXPLOSION) {
                if (!event.isCancelled()) {
                    if (event.getCause() != DamageCause.ENTITY_EXPLOSION && event.getCause() != DamageCause.BLOCK_EXPLOSION) {
                        double finalDamage = event.getFinalDamage();
                        if (!(finalDamage <= 0.0)) {
                            float power = (float)(finalDamage / 2.0);
                            if (power < 0.5F) {
                                power = 0.5F;
                            }

                            if (power > 20.0F) {
                                power = 20.0F;
                            }

                            this.selfExplosionImmunity.add(player.getUniqueId());
                            player.getWorld().createExplosion(player, player.getLocation(), power, false, true);
                            this.trackCitizenCrime(player.getUniqueId(), "explode", 5);
                            Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                                this.selfExplosionImmunity.remove(player.getUniqueId());
                            }, 2L);
                        }
                    }
                }
            }
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onDamageExplosionSelfDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            if (this.selfExplosionImmunity.contains(player.getUniqueId())) {
                if (event.getCause() == DamageCause.ENTITY_EXPLOSION || event.getCause() == DamageCause.BLOCK_EXPLOSION) {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onDamageTeleport(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var17 = AbilityManager.getAbility(player);
            if (var17 == AbilityType.DAMAGE_TELEPORT) {
                if (!event.isCancelled()) {
                    event.setCancelled(true);
                    UUID uuid = player.getUniqueId();
                    long now = System.currentTimeMillis();
                    Long lastTeleport = (Long)this.teleportCooldowns.get(uuid);
                    if (lastTeleport == null || now - lastTeleport >= 500L) {
                        this.teleportCooldowns.put(uuid, now);
                        Location origin = player.getLocation();
                        World world = origin.getWorld();
                        if (world != null) {
                            double angle = this.random.nextDouble() * 2.0 * Math.PI;
                            int distance = 5 + this.random.nextInt(11);
                            int targetX = origin.getBlockX() + (int)Math.round((double)distance * Math.cos(angle));
                            int targetZ = origin.getBlockZ() + (int)Math.round((double)distance * Math.sin(angle));
                            int highestY = world.getHighestBlockYAt(targetX, targetZ);
                            Location target = new Location(world, (double)targetX + 0.5, (double)highestY + 1.0, (double)targetZ + 0.5);
                            target.setYaw(origin.getYaw());
                            target.setPitch(origin.getPitch());
                            player.teleport(target);
                            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                            player.sendMessage("§6[受伤瞬移] §a你免疫了伤害并随机瞬移!");
                        }
                    }
                }
            }
        }
    }

    private void handleSpitShot(Player player) {
        long now = System.currentTimeMillis();
        Long penaltyEnd = (Long)this.overloadEndTime.get(player.getUniqueId());
        if (penaltyEnd != null && now < penaltyEnd) {
            this.spitLostHealth.merge(player.getUniqueId(), 2.0, Double::sum);
            this.applySpitMaxHealth(player);
            Object[] var10002 = new Object[]{(Double)this.spitLostHealth.get(player.getUniqueId()) / 2.0};
            player.sendMessage("§c§l惩罚期内射击! 生命上限永久扣除 " + String.format("%.0f", var10002) + " 颗心");
        }

        List<Long> timestamps = (List)this.shotTimestamps.computeIfAbsent(player.getUniqueId(), (k) -> {
            return new ArrayList();
        });
        timestamps.removeIf((t) -> {
            return now - t > 1000L;
        });
        timestamps.add(now);
        if (timestamps.size() >= 5) {
            timestamps.clear();
            this.triggerOverload(player);
        } else {
            this.fireNormalShot(player);
        }

    }

    private void fireNormalShot(Player player) {
        Location spawnLoc = player.getEyeLocation();
        Vector dir = spawnLoc.getDirection().normalize().multiply(2.0);
        LlamaSpit spit = (LlamaSpit)player.getWorld().spawn(spawnLoc, LlamaSpit.class);
        spit.setShooter(player);
        spit.setVelocity(dir);
        this.projectileTypes.put(spit.getUniqueId(), "normal");
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_LLAMA_SPIT, 0.8F, 1.2F);
    }

    private void triggerOverload(Player player) {
        Location spawnLoc = player.getEyeLocation();
        Vector forwardDir = spawnLoc.getDirection().normalize();
        LlamaSpit forward = (LlamaSpit)player.getWorld().spawn(spawnLoc, LlamaSpit.class);
        forward.setShooter(player);
        forward.setVelocity(forwardDir.multiply(2.0));
        this.projectileTypes.put(forward.getUniqueId(), "overload_forward");
        double yaw = Math.toRadians((double)player.getLocation().getYaw());

        for(int i = 1; i < 8; ++i) {
            double angle = yaw + Math.toRadians((double)(i * 45));
            double vx = -Math.sin(angle);
            double vz = Math.cos(angle);
            Vector sideVel = (new Vector(vx, 0.1, vz)).normalize().multiply(2.0);
            LlamaSpit side = (LlamaSpit)player.getWorld().spawn(spawnLoc, LlamaSpit.class);
            side.setShooter(player);
            side.setVelocity(sideVel);
            this.projectileTypes.put(side.getUniqueId(), "overload_side");
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 600, 2, false, true, true));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 600, 1, false, true, true));
        this.overloadEndTime.put(player.getUniqueId(), System.currentTimeMillis() + 30000L);
        player.sendMessage("§c§l过载射击! 获得虚弱II和缓慢I效果(30秒), 惩罚期内射击将永久扣除生命上限");
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0F, 0.8F);
    }

    @EventHandler
    public void onSpitHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof LlamaSpit spit) {
            String type = (String)this.projectileTypes.remove(spit.getUniqueId());
            if (type != null) {
                ProjectileSource var5 = spit.getShooter();
                if (var5 instanceof Player) {
                    Player player = (Player)var5;
                    AbilityType var14 = AbilityManager.getAbility(player);
                    if (var14 == AbilityType.SPIT_EXPLOSION) {
                        boolean isLarge = type.equals("overload_forward");
                        if (event.getHitBlock() != null) {
                            this.destroyBlocks(event.getHitBlock(), isLarge ? 5 : 3);
                        } else {
                            Entity var8 = event.getHitEntity();
                            if (var8 instanceof LivingEntity) {
                                LivingEntity living = (LivingEntity)var8;
                                living.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 100, 0, false, true, true));
                                double[] damages = isLarge ? new double[]{8.0, 4.0, 2.0} : new double[]{4.0, 2.0, 1.0};
                                living.damage(damages[0], player);

                                for(int i = 1; i < damages.length; ++i) {
                                    int delay = i * 20;
                                    double dmg = damages[i];
                                    Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                                        if (living.isValid() && !living.isDead()) {
                                            living.damage(dmg, player);
                                        }

                                    }, (long)delay);
                                }
                            }
                        }

                    }
                }
            }
        }
    }

    private void applySpitMaxHealth(Player player) {
        double lost = (Double)this.spitLostHealth.getOrDefault(player.getUniqueId(), 0.0);
        AttributeInstance attr = player.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) {
            attr.setBaseValue(Math.max(1.0, 20.0 - lost));
        }

    }

    private void destroyBlocks(Block center, int size) {
        int radius = size / 2;
        World world = center.getWorld();

        for(int x = -radius; x <= radius; ++x) {
            for(int y = -radius; y <= radius; ++y) {
                for(int z = -radius; z <= radius; ++z) {
                    Block block = center.getRelative(x, y, z);
                    Material type = block.getType();
                    if (type != Material.BEDROCK && type != Material.BARRIER && type != Material.END_PORTAL_FRAME && type != Material.END_PORTAL && type != Material.NETHER_PORTAL && type != Material.COMMAND_BLOCK && type != Material.CHAIN_COMMAND_BLOCK && type != Material.REPEATING_COMMAND_BLOCK && type != Material.STRUCTURE_BLOCK && type != Material.STRUCTURE_VOID && type != Material.JIGSAW && type != Material.LIGHT) {
                        block.breakNaturally();
                    }
                }
            }
        }

    }

    private void handleSpartanPunch(Player player) {
        if (!AbilityManager.canUseSpartan(player)) {
            player.sendMessage("§c斯巴达之击冷却中!(60秒)");
        } else {
            Entity target = player.getTargetEntity(4);
            if (target instanceof LivingEntity) {
                LivingEntity living = (LivingEntity)target;
                if (!target.equals(player)) {
                    living.damage(6.0, player);
                    Vector knockback = player.getLocation().getDirection().normalize().multiply(-0.22);
                    knockback.setY(1.8);
                    living.setVelocity(knockback);
                    if (target instanceof Player) {
                        Player targetPlayer = (Player)target;
                        this.spartanHitPlayers.add(targetPlayer.getUniqueId());
                        player.sendMessage("§6[超能力] §a斯巴达之击! 将 " + targetPlayer.getName() + " 击飞!");
                        targetPlayer.sendMessage("§c你被斯巴达勇士击飞了!");
                        AbilityManager.setSpartanCooldownMillis(player, 10000L);
                        Player finalPlayer = player;
                        Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                            if (targetPlayer.isDead() || targetPlayer.getHealth() <= 0.0) {
                                AbilityManager.resetSpartanCooldown(finalPlayer);
                                finalPlayer.sendMessage("§6[超能力] §a技能已刷新!");
                            }
                        }, 2L);
                    } else {
                        player.sendMessage("§6[超能力] §a斯巴达之击! 击飞了生物!");
                        AbilityManager.setSpartanCooldown(player);
                    }

                    player.getWorld().playSound(player.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, 1.0F);
                    return;
                }
            }

            player.sendMessage("§c请对准一个生物!");
        }
    }

    @EventHandler
    public void onSpartanFallDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player target) {
            if (event.getCause() == DamageCause.FALL) {
                if (this.spartanHitPlayers.contains(target.getUniqueId())) {
                    this.spartanHitPlayers.remove(target.getUniqueId());
                    double finalDamage = event.getFinalDamage();
                    if (!(target.getHealth() - finalDamage > 0.0)) {
                        Player killer = target.getKiller();
                        if (killer == null) {
                            Iterator var6 = target.getNearbyEntities(10.0, 10.0, 10.0).iterator();

                            while(var6.hasNext()) {
                                Entity entity = (Entity)var6.next();
                                if (entity instanceof Player) {
                                    Player p = (Player)entity;
                                    if (AbilityManager.getAbility(p) == AbilityType.SPARTAN) {
                                        killer = p;
                                        break;
                                    }
                                }
                            }
                        }

                        if (killer != null && AbilityManager.getAbility(killer) == AbilityType.SPARTAN) {
                            AbilityManager.applySpartanStrength(killer);
                            AbilityManager.resetSpartanCooldown(killer);
                            killer.sendMessage("§6[超能力] §a技能已刷新!");
                        }
                    }
                }
            }
        }
    }

    private void handleWitherSkull(Player player) {
        if (!AbilityManager.canUseWitherSkill(player)) {
            player.sendMessage("§c凋零头颅冷却中!(5秒)");
        } else {
            Location spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize());
            WitherSkull skull = (WitherSkull)player.getWorld().spawn(spawnLoc, WitherSkull.class);
            skull.setShooter(player);
            skull.setVelocity(player.getLocation().getDirection().normalize().multiply(1.5));
            AbilityManager.setWitherSkillCooldown(player);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITHER_SHOOT, 0.5F, 1.0F);
        }
    }

    @EventHandler
    public void onWitherSkullHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof WitherSkull skull) {
            ProjectileSource var4 = skull.getShooter();
            if (var4 instanceof Player player) {
                if (AbilityManager.getAbility(player) == AbilityType.WITHER_KIN) {
                    Entity var5 = event.getHitEntity();
                    if (var5 instanceof LivingEntity target && !target.equals(player)) {
                        event.setCancelled(true);
                        if (!(target instanceof Player targetPlayer
                            && AbilityManager.getAbility(targetPlayer) == AbilityType.WITHER_KIN)) {
                            target.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 1));
                        }
                        target.damage(6.0, player);
                    }
                }
            }
        }
    }

    private void handleElfRangerArrow(Player player) {
        if (!AbilityManager.canUseElfRanger(player)) {
            player.sendMessage("§c箭矢冷却中!(0.5秒)");
        } else {
            Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
            arrow.setShooter(player);
            arrow.setVelocity(player.getLocation().getDirection().normalize().multiply(2.5));
            arrow.setPickupStatus(PickupStatus.DISALLOWED);
            arrow.getPersistentDataContainer().set(new NamespacedKey(Main.getInstance(), "elf_arrow"), PersistentDataType.BOOLEAN, true);
            AbilityManager.setElfRangerCooldown(player);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 0.5F, 1.0F);
        }
    }

    private void handleElfRangerTrackingArrows(Player player) {
        if (!AbilityManager.canUseElfRangerTracking(player)) {
            player.sendMessage("§c追踪箭冷却中!(15秒)");
            return;
        }
        Vector lookDir = player.getEyeLocation().getDirection().normalize();
        Location eyeLoc = player.getEyeLocation();
        LivingEntity trackTarget = null;
        double bestDot = -1.0;
        for (Entity entity : player.getWorld().getNearbyEntities(eyeLoc, 40.0, 40.0, 40.0)) {
            if (entity.equals(player)) continue;
            if (!(entity instanceof LivingEntity living)) continue;
            if (living.isDead()) continue;
            if (living instanceof Player p && AbilityManager.isSameBattleTeam(player, p)) continue;
            Vector toEntity = living.getEyeLocation().toVector().subtract(eyeLoc.toVector()).normalize();
            double dot = lookDir.dot(toEntity);
            if (dot <= bestDot) continue;
            boolean isPlayer = entity instanceof Player;
            boolean bestIsPlayer = trackTarget instanceof Player;
            if (trackTarget == null || dot > bestDot + 0.15 || (isPlayer && !bestIsPlayer)) {
                bestDot = dot;
                trackTarget = living;
            }
        }
        if (trackTarget == null || bestDot < 0.5) {
            player.sendMessage("§c附近没有可追踪的目标!");
            return;
        }
        if (trackTarget instanceof Player targetPlayer) {
            if (AbilityManager.getAbility(targetPlayer) == AbilityType.ENDERLING) {
                for (int i = 0; i < 3; ++i) {
                    Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
                    arrow.setShooter(player);
                    arrow.setVelocity(player.getLocation().getDirection().normalize().multiply(2.5));
                    arrow.setPickupStatus(PickupStatus.DISALLOWED);
                }
                player.sendMessage("§e对方免疫远程伤害,追踪箭转为普通箭矢,冷却减少10秒!");
                AbilityManager.setElfRangerTrackingCooldown(player);
                return;
            }
        }
        AbilityManager.setElfRangerTrackingCooldown(player);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ARROW_SHOOT, 0.5F, 1.0F);
        final LivingEntity finalTarget = trackTarget;
        NamespacedKey trackingKey = new NamespacedKey(Main.getInstance(), "elf_tracking_target");
        final NamespacedKey finalTrackingKey = trackingKey;
        for (int i = 0; i < 3; ++i) {
            Arrow arrow = (Arrow)player.launchProjectile(Arrow.class);
            arrow.setShooter(player);
            arrow.setGravity(false);
            Vector baseVel = player.getLocation().getDirection().normalize().multiply(2.0);
            arrow.setVelocity(baseVel.add(new Vector((Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.5, (Math.random() - 0.5) * 0.5)));
            arrow.setPickupStatus(PickupStatus.DISALLOWED);
            arrow.setPierceLevel(127);
            arrow.getPersistentDataContainer().set(new NamespacedKey(Main.getInstance(), "elf_tracking_arrow"), PersistentDataType.BOOLEAN, true);
            arrow.getPersistentDataContainer().set(trackingKey, PersistentDataType.STRING, finalTarget.getUniqueId().toString());
        }
        Bukkit.getScheduler().runTaskTimer(Main.getInstance(), new Runnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (++ticks > 100 || finalTarget.isDead() || !finalTarget.isValid()) {
                    return;
                }
                for (Arrow arrow : player.getWorld().getEntitiesByClass(Arrow.class)) {
                    if (arrow.getShooter() instanceof Player && arrow.getShooter().equals(player)) {
                        if (arrow.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "elf_tracking_arrow"), PersistentDataType.BOOLEAN)) {
                            String storedTarget = arrow.getPersistentDataContainer().get(finalTrackingKey, PersistentDataType.STRING);
                            if (storedTarget != null && storedTarget.equals(finalTarget.getUniqueId().toString())) {
                                if (!arrow.isDead() && arrow.isValid()) {
                                    if (arrow.isOnGround()) {
                                        Vector dir = finalTarget.getLocation().toVector().subtract(arrow.getLocation().toVector());
                                        if (dir.lengthSquared() > 0.01) {
                                            arrow.teleport(arrow.getLocation().add(dir.normalize().multiply(1.5)));
                                        }
                                    }
                                    Vector toTargetDir = finalTarget.getLocation().add(0.0, 1.0, 0.0).subtract(arrow.getLocation()).toVector();
                                    if (toTargetDir.lengthSquared() > 0.01) {
                                        arrow.setVelocity(toTargetDir.normalize().multiply(2.5));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }, 0L, 1L);
        player.sendMessage("§6[超能力] §a发射了3支追踪箭! §7目标: " + (trackTarget instanceof Player ? ((Player)trackTarget).getName() : trackTarget.getType().name()));
    }

    @EventHandler
    public void onElfArrowHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof Arrow arrow) {
            if (arrow.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "elf_arrow"), PersistentDataType.BOOLEAN)) {
                ProjectileSource var4 = arrow.getShooter();
                if (var4 instanceof Player) {
                    Player shooter = (Player)var4;
                    if (event.getHitEntity() instanceof LivingEntity) {
                        shooter.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 0));
                    }
                }
            }
        }
    }

    @EventHandler
    public void onElfArrowEntityDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Arrow arrow) {
            if (arrow.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "elf_arrow"), PersistentDataType.BOOLEAN) ||
                arrow.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "elf_tracking_arrow"), PersistentDataType.BOOLEAN)) {
                Entity victim = event.getEntity();
                if (victim instanceof Player targetPlayer) {
                    AbilityType targetAbility = AbilityManager.getAbility(targetPlayer);
                    if (targetAbility == AbilityType.SUPERMAN || targetAbility == AbilityType.FAIRY) {
                        event.setDamage(event.getDamage() * 2.0);
                    }
                }
                NamespacedKey trackingKey = new NamespacedKey(Main.getInstance(), "elf_tracking_arrow");
                if (arrow.getPersistentDataContainer().has(trackingKey, PersistentDataType.BOOLEAN)) {
                    arrow.getPersistentDataContainer().remove(trackingKey);
                }
            }
        }
    }

    @EventHandler
    public void onSentinelSnowballHit(ProjectileHitEvent event) {
        Projectile var3 = event.getEntity();
        if (var3 instanceof Snowball snowball) {
            if (snowball.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "sentinel_snowball"), PersistentDataType.BOOLEAN)) {
                Entity hitEntity = event.getHitEntity();
                if (hitEntity instanceof LivingEntity living) {
                    ProjectileSource shooterSource = snowball.getShooter();
                    Player shooter = (shooterSource instanceof Player) ? (Player) shooterSource : null;
                    if (shooter != null && living instanceof Player targetPlayer) {
                        if (AbilityManager.isSameBattleTeam(shooter, targetPlayer)) {
                            return;
                        }
                    }
                    double damage = 4.0;
                    if (living instanceof Player targetPlayer) {
                        AbilityType tAbility = AbilityManager.getAbility(targetPlayer);
                        if (tAbility == AbilityType.SUPERMAN || tAbility == AbilityType.FAIRY) {
                            damage = 8.0;
                        }
                    }
                    if (shooter != null) {
                        living.damage(damage, shooter);
                    } else {
                        living.damage(damage);
                    }
                }
            }
        }
    }

    @EventHandler
    public void onSentinelArmorStandDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof ArmorStand stand) {
            if (stand.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "sentinel_owner"), PersistentDataType.STRING)) {
                String ownerId = stand.getPersistentDataContainer().get(new NamespacedKey(Main.getInstance(), "sentinel_owner"), PersistentDataType.STRING);
                if (ownerId != null) {
                    Player owner = Bukkit.getPlayer(UUID.fromString(ownerId));
                    if (owner != null) {
                        UUID standUuid = stand.getUniqueId();
                        AbilityManager.incrementSentinelHits(standUuid);
                        if (AbilityManager.getSentinelHits(standUuid) >= 4) {
                            stand.remove();
                            AbilityManager.removeSentinelArmorStand(owner.getUniqueId(), standUuid);
                            if (event.getDamager() instanceof Player damager) {
                                damager.sendMessage("§c炮塔已被摧毁!");
                            }
                            owner.sendMessage("§c你的炮塔已被摧毁!");
                        }
                        event.setCancelled(true);
                    }
                }
            }
        }
    }

    private void handleWitchPotion(Player player) {
        if (!AbilityManager.canUseWitchKin(player)) {
            player.sendMessage("§c药水冷却中!(10秒)");
        } else {
            ItemStack potionItem = new ItemStack(Material.SPLASH_POTION);
            PotionMeta meta = (PotionMeta)potionItem.getItemMeta();
            PotionEffect[] NEGATIVE_EFFECTS = new PotionEffect[]{new PotionEffect(PotionEffectType.POISON, 100, this.random.nextInt(4)), new PotionEffect(PotionEffectType.WITHER, 100, this.random.nextInt(2)), new PotionEffect(PotionEffectType.SLOWNESS, 100, this.random.nextInt(3)), new PotionEffect(PotionEffectType.WEAKNESS, 100, this.random.nextInt(3)), new PotionEffect(PotionEffectType.HUNGER, 100, this.random.nextInt(3)), new PotionEffect(PotionEffectType.BLINDNESS, 100, 0), new PotionEffect(PotionEffectType.NAUSEA, 100, 0), new PotionEffect(PotionEffectType.LEVITATION, 100, this.random.nextInt(2))};
            PotionEffect chosen = NEGATIVE_EFFECTS[this.random.nextInt(NEGATIVE_EFFECTS.length)];
            meta.addCustomEffect(chosen, true);
            potionItem.setItemMeta(meta);
            ThrownPotion potion = (ThrownPotion)player.launchProjectile(ThrownPotion.class);
            potion.setItem(potionItem);
            potion.setShooter(player);
            potion.setVelocity(player.getLocation().getDirection().normalize().multiply(1.5));
            AbilityManager.setWitchKinCooldown(player);
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITCH_THROW, 0.5F, 1.0F);
        }
    }

    private void handleWitchRegen(Player player) {
        if (!AbilityManager.canUseWitchRegen(player)) {
            player.sendMessage("§c生命恢复冷却中!(30秒)");
        } else {
            player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 200, 0));
            AbilityManager.setWitchRegenCooldown(player);
            player.sendMessage("§6[超能力] §a你获得了10秒生命恢复I!");
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_WITCH_DRINK, 0.5F, 1.0F);
        }
    }

    private void handleSentinelSummon(Player player) {
        if (!AbilityManager.canUseSentinel(player)) {
            return;
        }
        Block targetBlock = player.getTargetBlockExact(5);
        Location spawnLoc;
        if (targetBlock != null) {
            spawnLoc = targetBlock.getLocation().add(0.5, 1.5, 0.5);
        } else {
            spawnLoc = player.getEyeLocation().add(player.getLocation().getDirection().normalize().multiply(3));
            spawnLoc.setY(spawnLoc.getBlockY());
        }
        World world = player.getWorld();
        ArmorStand stand = (ArmorStand)world.spawn(spawnLoc, ArmorStand.class);
        stand.setVisible(false);
        stand.setGravity(false);
        stand.setSmall(false);
        stand.setBasePlate(false);
        stand.setArms(false);
        stand.setCanPickupItems(false);
        stand.setInvulnerable(false);
        stand.setCollidable(true);
        stand.setCustomName("§b" + player.getName() + "的炮塔");
        stand.setCustomNameVisible(true);
        stand.getEquipment().setHelmet(new ItemStack(Material.CARVED_PUMPKIN));
        NamespacedKey ownerKey = new NamespacedKey(Main.getInstance(), "sentinel_owner");
        stand.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, player.getUniqueId().toString());
        AbilityManager.addSentinelArmorStand(player.getUniqueId(), stand.getUniqueId());
        final UUID standUuid = stand.getUniqueId();
        final Location sentinelLoc = stand.getLocation().clone();
        final BukkitTask[] taskRef = new BukkitTask[1];
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            ArmorStand s = (ArmorStand)Bukkit.getEntity(standUuid);
            if (s == null || s.isDead() || !s.isValid()) {
                AbilityManager.removeSentinelArmorStand(player.getUniqueId(), standUuid);
                if (taskRef[0] != null) {
                    taskRef[0].cancel();
                    AbilityManager.removeSentinelTask(player.getUniqueId(), taskRef[0]);
                }
                return;
            }
            LivingEntity target = null;
            double closestDist = Double.MAX_VALUE;
            for (Entity entity : world.getNearbyEntities(sentinelLoc, 16.0, 40.0, 16.0)) {
                if (!(entity instanceof LivingEntity living)) continue;
                if (living.equals(player)) continue;
                if (living instanceof ArmorStand) continue;
                if (living instanceof Player p && AbilityManager.isSameBattleTeam(player, p)) continue;
                if (AbilityManager.getSummonedKey() != null && living.getPersistentDataContainer().has(AbilityManager.getSummonedKey(), PersistentDataType.STRING)) {
                      String ownerId = living.getPersistentDataContainer().get(AbilityManager.getSummonedKey(), PersistentDataType.STRING);
                    if (ownerId != null) {
                        Player owner = Bukkit.getPlayer(UUID.fromString(ownerId));
                        if (owner != null && AbilityManager.isSameBattleTeam(player, owner)) continue;
                    }
                }
                if (living instanceof Player targetPlayer) {
                    AbilityType tAbility = AbilityManager.getAbility(targetPlayer);
                    if (tAbility == AbilityType.SUPERMAN || tAbility == AbilityType.FAIRY) {
                        target = living;
                        break;
                    }
                    if (target == null || !(target instanceof Player)) {
                        target = living;
                    }
                } else if (target == null) {
                    double dist = living.getLocation().distanceSquared(sentinelLoc);
                    if (dist < closestDist) {
                        closestDist = dist;
                        target = living;
                    }
                }
            }
            if (target != null) {
                double damage = 4.0;
                if (target instanceof Player targetPlayer) {
                    AbilityType tAbility = AbilityManager.getAbility(targetPlayer);
                    if (tAbility == AbilityType.SUPERMAN || tAbility == AbilityType.FAIRY) {
                        damage = 8.0;
                    }
                }
                target.damage(damage, player);
            }
        }, 20L, 30L);
        taskRef[0] = task;
        AbilityManager.addSentinelTask(player.getUniqueId(), task);
        AbilityManager.setSentinelCooldown(player);
        player.sendMessage("§6[超能力] §a炮塔已部署!");
        player.getWorld().playSound(player.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.5F, 1.0F);
    }

    private void handleSummoner(Player player) {
        if (!AbilityManager.canUseSummoner(player)) {
            return;
        }
        String teamTag = null;
        for (String tag : player.getScoreboardTags()) {
            if (tag.startsWith("battle_team_")) {
                teamTag = tag;
                break;
            }
        }
        if (teamTag == null) {
            player.sendMessage("§6[召集者] §c你当前没有队伍!");
            return;
        }
        int count = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (target.equals(player)) continue;
            if (!target.getScoreboardTags().contains(teamTag)) continue;
            if (target.getGameMode() == GameMode.SPECTATOR) continue;
            Location tpLoc = player.getLocation().add((Math.random() - 0.5) * 2.0, 0.0, (Math.random() - 0.5) * 2.0);
            tpLoc.setYaw(target.getLocation().getYaw());
            tpLoc.setPitch(target.getLocation().getPitch());
            target.teleport(tpLoc);
            target.sendMessage("§6[召集者] §a你被 §e" + player.getName() + " §a召集到了身边!");
            target.playSound(target.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5F, 1.0F);
            count++;
        }
        if (count == 0) {
            player.sendMessage("§6[召集者] §c没有同队伍队友在线!");
            return;
        }
        AbilityManager.setSummonerCooldown(player);
        player.sendMessage("§6[召集者] §a成功召集了 §e" + count + " §a名队友!");
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5F, 1.0F);
        player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0.0, 1.0, 0.0), 50, 1.0, 1.0, 1.0, 0.5);
    }

    private void handleRedeemer(Player player) {
        ItemStack mainHand = player.getInventory().getItemInMainHand();
        if (mainHand.getType() != Material.PAPER || !mainHand.hasItemMeta()) {
            player.sendMessage("§6[救赎者] §c请手持队友的灵魂纸后使用技能!");
            return;
        }
        String deadName = mainHand.getItemMeta().getDisplayName();
        if (!deadName.startsWith("§c") || !AbilityManager.hasRedeemerPaper(player, deadName.substring(2))) {
            player.sendMessage("§6[救赎者] §c无效的灵魂纸!");
            return;
        }
        deadName = deadName.substring(2);

        Player deadPlayer = Bukkit.getPlayer(deadName);
        if (deadPlayer != null && deadPlayer.isOnline()
            && deadPlayer.getGameMode() != GameMode.SPECTATOR
            && deadPlayer.getHealth() > 0.0) {
            player.sendMessage("§6[救赎者] §c该玩家已经自行复活，无需救赎!");
            return;
        }

        if (!AbilityManager.canUseRedeemer(player)) return;

        if (mainHand.getAmount() > 1) {
            mainHand.setAmount(mainHand.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand(null);
        }
        AbilityManager.removeRedeemerPaper(player, deadName);

        int cd = AbilityManager.getRedeemerCooldownSeconds(player);
        player.sendMessage("§6[救赎者] §e正在施救! 定身10秒...");
        player.sendMessage("§6[救赎者] §e本次冷却: §c" + (cd / 60) + "分" + (cd % 60) + "秒");
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 200, 0, false, false));
        AbilityManager.saveRedeemerSpeed(player);
        player.setWalkSpeed(0);
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 200, 200, false, false));

        Location loc = player.getLocation();
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        Bukkit.broadcastMessage("§6[救赎者] §e" + player.getName() + " 的坐标为: §b" + x + "§e, §b" + y + "§e, §b" + z);

        UUID playerUuid = player.getUniqueId();
        String finalDeadName = deadName;
        BukkitTask task = Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
            Player p = Bukkit.getPlayer(playerUuid);
            if (p == null || !p.isOnline()) return;
            AbilityManager.restoreRedeemerSpeed(p);
            p.removePotionEffect(PotionEffectType.GLOWING);
            p.removePotionEffect(PotionEffectType.JUMP_BOOST);
            p.sendMessage("§6[救赎者] §a施救完成!");

            for (Player target : Bukkit.getOnlinePlayers()) {
                if (target.getName().equals(finalDeadName)) {
                    AbilityType newAbility = AbilityManager.getRandomAbility();
                    AbilityManager.setAbility(target, newAbility);
                    target.setHealth(target.getMaxHealth());
                    target.setFoodLevel(20);
                    target.setGameMode(GameMode.SURVIVAL);
                    target.teleport(p.getLocation().add(0.5, 1.0, 0.5));
                    target.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 100, 1, false, false));
                    target.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 100, 1, false, false));
                    target.sendMessage("§6[救赎者] §a你被 §e" + p.getName() + " §a救赎复活! 获得了新超能力: §e" + newAbility.getDisplayId() + ". " + newAbility.getDisplayName());
                    Bukkit.broadcastMessage("§6[救赎者] §e" + p.getName() + " §7成功救赎了 §e" + finalDeadName + "§7!");
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.5F, 1.0F);
                    p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0.0, 1.0, 0.0), 50, 1.0, 1.0, 1.0, 0.5);
                    AbilityManager.notifyRedeemerRevive(target);
                    break;
                }
            }
        }, 200L);
        AbilityManager.addRedeemerTask(playerUuid, task);
        AbilityManager.setRedeemerCooldown(player);
    }

    private void handleLightningKing(Player player) {
        if (player.isSneaking()) {
            if (!AbilityManager.canUseLightningKingMass(player)) {
            } else {
                Entity targetEntity = player.getTargetEntity(50);
                Location loc;
                if (targetEntity != null) {
                    loc = targetEntity.getLocation();
                } else {
                    Block targetBlock = player.getTargetBlockExact(50);
                    if (targetBlock != null) {
                        loc = targetBlock.getLocation().add(0.5, 1.0, 0.5);
                    } else {
                        loc = player.getEyeLocation().add(player.getLocation().getDirection().normalize().multiply(10));
                        loc.setY(player.getWorld().getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ()) + 1);
                    }
                }
                AbilityManager.setLightningKingMassCooldown(player);
                for (int i = 0; i < 5; ++i) {
                    Location strikeLoc = loc.clone().add((Math.random() - 0.5) * 4.0, 0.0, (Math.random() - 0.5) * 4.0);
                    setLightningKillers(player, strikeLoc);
                    player.getWorld().strikeLightning(strikeLoc);
                }
                player.sendMessage("§6[雷电法王] §e五雷轰顶!");
            }
        } else if (AbilityManager.canUseLightningKing(player)) {
            Entity targetEntity = player.getTargetEntity(50);
            Location loc;
            if (targetEntity != null) {
                loc = targetEntity.getLocation();
            } else {
                Block targetBlock = player.getTargetBlockExact(50);
                if (targetBlock != null) {
                    loc = targetBlock.getLocation().add(0.5, 1.0, 0.5);
                } else {
                    loc = player.getEyeLocation().add(player.getLocation().getDirection().normalize().multiply(10));
                    loc.setY(player.getWorld().getHighestBlockYAt(loc.getBlockX(), loc.getBlockZ()) + 1);
                }
            }
            AbilityManager.setLightningKingCooldown(player);
            setLightningKillers(player, loc);
            player.getWorld().strikeLightning(loc);
            player.sendMessage("§6[雷电法王] §e天降正义!");
        }
    }

    private void setLightningKillers(Player caster, Location loc) {
        for (Entity entity : loc.getWorld().getNearbyEntities(loc, 3.0, 3.0, 3.0)) {
            if (entity instanceof Player victim && !victim.equals(caster)) {
                AbilityManager.setForcedKiller(victim.getUniqueId(), caster.getUniqueId());
            }
        }
    }

    private void handleDemonFang(Player player) {
        if (!AbilityManager.canUseDemonFang(player)) {
            player.sendMessage("§c尖牙冷却中!(5秒)");
            return;
        }
        Location center = player.getLocation();
        Vector playerDir = center.getDirection();
        double range = 15.0;
        LivingEntity target = null;
        int targetPriority = -1;
        double targetDistance = range + 1.0;
        for (Entity entity : player.getNearbyEntities(range, range, range)) {
            if (!(entity instanceof LivingEntity living) || entity.equals(player)) continue;
            if (living.isDead()) continue;
            if (living instanceof ArmorStand) continue;
            Vector toEntity = living.getLocation().toVector().subtract(center.toVector());
            double distance = toEntity.length();
            if (distance > range || distance < 1.0) continue;
            double dot = playerDir.dot(toEntity.normalize());
            if (dot < 0.5) continue;
            int priority;
            if (living instanceof Player targetPlayer) {
                if (isSameBattleTeam(player, targetPlayer)) continue;
                priority = 3;
            } else if (living instanceof Monster) {
                priority = 2;
            } else if (living instanceof Animals) {
                priority = 1;
            } else {
                continue;
            }
            if (priority > targetPriority || (priority == targetPriority && distance < targetDistance)) {
                target = living;
                targetPriority = priority;
                targetDistance = distance;
            }
        }
        if (target == null) {
            player.sendMessage("§c前方没有可攻击的生物!");
            return;
        }
        Location fangLoc = target.getLocation().subtract(0.0, 1.0, 0.0);
        EvokerFangs fang = (EvokerFangs)player.getWorld().spawn(fangLoc, EvokerFangs.class);
        fang.getPersistentDataContainer().set(new NamespacedKey(Main.getInstance(), "fang_caster"), PersistentDataType.STRING, player.getUniqueId().toString());
        AbilityManager.setDemonFangCooldown(player);
        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_EVOKER_CAST_SPELL, 0.5F, 1.0F);
    }

    private void handleDemonVex(Player player) {
        if (!AbilityManager.canUseDemonVex(player)) {
            player.sendMessage("§c恼鬼召唤冷却中!(60秒)");
            return;
        }
        int vexCount = AbilityManager.getDemonVexCount(player.getUniqueId());
        if (vexCount >= 3) {
            player.sendMessage("§6[超能力] §c你已经召唤了最多3只恼鬼!");
            return;
        }
        Location spawnLoc = player.getLocation().add(0.0, 2.0, 0.0);
        Vex vex = (Vex)player.getWorld().spawn(spawnLoc, Vex.class);
        if (vex instanceof Tameable) {
            Tameable tameable = (Tameable)vex;
            tameable.setOwner(player);
        }

        vex.setTarget((LivingEntity)null);
        vex.setCustomName("§b" + player.getName() + "的恼鬼");
        vex.setCustomNameVisible(true);
        vex.getPersistentDataContainer().set(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING, player.getUniqueId().toString());
        AbilityManager.addDemonVexUUID(player.getUniqueId(), vex.getUniqueId());
        AbilityManager.setDemonVexCooldown(player);

        if (vexCount == 0) {
            BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
                Set<UUID> vexIds = AbilityManager.getDemonVexUUIDs(player.getUniqueId());
                if (vexIds.isEmpty()) {
                    BukkitTask t = AbilityManager.getDemonVexFollowTask(player.getUniqueId());
                    if (t != null) {
                        t.cancel();
                        AbilityManager.removeDemonVexFollowTask(player.getUniqueId());
                    }
                    return;
                }
                for (UUID vexUuid : vexIds) {
                    Entity vexEntity = Bukkit.getEntity(vexUuid);
                    if (vexEntity == null || !vexEntity.isValid() || vexEntity.isDead()) {
                        AbilityManager.removeDemonVexUUID(player.getUniqueId(), vexUuid);
                        continue;
                    }
                    if (!vexEntity.getWorld().equals(player.getWorld())) {
                        vexEntity.teleport(player.getLocation().add(0.0, 2.0, 0.0));
                    } else if (vexEntity instanceof Mob mob) {
                        double distance = vexEntity.getLocation().distance(player.getLocation());
                        if (distance > 20.0) {
                            vexEntity.teleport(player.getLocation().add(0.0, 2.0, 0.0));
                        } else if (distance > 5.0) {
                            mob.getPathfinder().moveTo(player.getLocation(), 1.5);
                        }
                    }
                }
            }, 20L, 20L);
            AbilityManager.setDemonVexFollowTask(player.getUniqueId(), task);
        }

        player.sendMessage("§6[超能力] §a恼鬼已召唤! (" + (vexCount + 1) + "/3)");
    }

    @EventHandler
    public void onVexTarget(EntityTargetLivingEntityEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Vex vex) {
            if (vex.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING)) {
                String ownerId = (String)vex.getPersistentDataContainer().get(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING);
                Player owner = Bukkit.getPlayer(UUID.fromString(ownerId));
                if (owner != null && owner.isOnline()) {
                    if (event.getTarget() != null && !event.getTarget().equals(owner)) {
                        if (event.getTarget() instanceof Player targetPlayer) {
                            if (isSameBattleTeam(owner, targetPlayer)) {
                                event.setCancelled(true);
                                return;
                            }
                            if (AbilityManager.isCodeKillProtected(targetPlayer)) {
                                event.setCancelled(true);
                            }
                        }
                    }

                } else {
                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onVexDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player attacker) {
            if (AbilityManager.getAbility(attacker) == AbilityType.DEMON_SUMMONER) {
                Entity hitEntity = event.getEntity();
                if (!(hitEntity instanceof LivingEntity target)) return;
                Set<UUID> vexIds = AbilityManager.getDemonVexUUIDs(attacker.getUniqueId());
                for (UUID vexId : vexIds) {
                    Entity vex = Bukkit.getEntity(vexId);
                    if (vex instanceof Vex && vex.isValid()) {
                        ((Vex)vex).setTarget(target);
                    }
                }
            }
        }

        var3 = event.getDamager();
        if (var3 instanceof Vex vex) {
            if (!vex.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING)) {
                return;
            }

            String ownerId = (String)vex.getPersistentDataContainer().get(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING);
            Player owner = Bukkit.getPlayer(UUID.fromString(ownerId));
            if (owner == null || !owner.isOnline()) {
                return;
            }
        }

        Entity var11 = event.getEntity();
        if (var11 instanceof Vex vex) {
            var11 = event.getDamager();
            if (var11 instanceof LivingEntity attacker) {
                if (!vex.getPersistentDataContainer().has(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING)) {
                    return;
                }

                String ownerId = (String)vex.getPersistentDataContainer().get(new NamespacedKey(Main.getInstance(), "vex_owner"), PersistentDataType.STRING);
                Player owner = Bukkit.getPlayer(UUID.fromString(ownerId));
                if (owner != null && owner.isOnline() && !attacker.equals(owner)) {
                    vex.setTarget(attacker);
                }
            }
        }

    }

    private void handleGodLeftHand(Player player) {
        if (!AbilityManager.canUseGodsLeftHand(player)) {
            return;
        }
        Entity target = player.getTargetEntity(8);
        if (target instanceof Player victim) {
            if (victim.equals(player)) {
                player.sendMessage("§c你不能对自己使用神之左手!");
                return;
            }
            AbilityManager.setGodsLeftHandCooldown(player);
            AbilityManager.disablePlayerAbilities(victim);
            AbilityManager.scheduleGodsLeftHandRestore(victim);
            player.sendMessage("§c☠ §4你使用了神之左手! " + victim.getName() + " 的超能力已被封印10秒!");
            victim.sendMessage("§c☠ §4你的超能力已被神之左手封印!");
        } else {
            player.sendMessage("§c请对准一个玩家(8格内)!");
        }
    }

    private void handleCitizenJail(Player player) {
        if (!AbilityManager.canUseCitizen(player)) {
            player.sendMessage("§c技能冷却中!(50秒)");
        } else {
            long now = System.currentTimeMillis();
            List<String> names = new ArrayList();
            int count = 0;

            for (Player target : Bukkit.getOnlinePlayers()) {
                if (target.equals(player)) continue;
                if (!target.getWorld().equals(player.getWorld())) continue;
                if (target.getLocation().distanceSquared(player.getLocation()) > 400.0) continue;
                if (AbilityManager.isSameBattleTeam(player, target)) continue;

                List<CitizenCrime> crimes = (List)this.citizenCrimes.get(target.getUniqueId());
                if (crimes == null || crimes.isEmpty()) continue;

                crimes.removeIf((c) -> {
                    return now - c.time > 10000L;
                });
                if (crimes.isEmpty()) continue;

                int maxTime = 0;
                String msg = "§c法治社会你犯罪了,警察已抓你!";
                for (CitizenCrime c : crimes) {
                    if (c.jailSeconds > maxTime) {
                        maxTime = c.jailSeconds;
                        msg = getCitizenCrimeMessage(c.type);
                    }
                }

                this.sendToJail(target, maxTime, msg);
                this.confiscateValuables(target, player);
                if (count > 0) {
                    names.add(", ");
                }
                names.add(target.getName());
                ++count;
                crimes.clear();
            }

            if (count > 0) {
                AbilityManager.setCitizenCooldown(player);
                StringBuilder sb = new StringBuilder();
                for (String n : names) {
                    sb.append(n);
                }
                player.sendMessage("§6[超能力] §a已报警! " + sb.toString() + " 被送进监狱!");
            } else {
                player.sendMessage("§c附近20格内没有罪犯!");
            }
        }
    }

    private void sendToJail(Player prisoner, int seconds, String message) {
        UUID uuid = prisoner.getUniqueId();
        Location prisonLoc = prisoner.getLocation().clone();
        prisonLoc.setY(300.0);
        int baseX = prisonLoc.getBlockX();
        int baseZ = prisonLoc.getBlockZ();
        World world = prisonLoc.getWorld();
        this.releaseFromJail(uuid);
        AbilityManager.prisonOriginalLocation.put(uuid, prisoner.getLocation().clone());
        List<AbilityManager.PrisonBlock> blocks = new ArrayList();
        Material[] layers = new Material[]{Material.BEDROCK, Material.BEDROCK, Material.BEDROCK, Material.IRON_BARS, Material.BEDROCK, Material.BEDROCK};

        for(int layer = 0; layer < 6; ++layer) {
            Material mat = layers[layer];
            int y = 300 + layer;

            for(int dx = 0; dx < 3; ++dx) {
                for(int dz = 0; dz < 4; ++dz) {
                    int x = baseX + dx;
                    int z = baseZ + dz;
                    if (layer != 2 && layer != 3 || dx < 1 || dx > 1 || dz < 1 || dz > 2) {
                        world.getBlockAt(x, y, z).setType(mat);
                        blocks.add(new AbilityManager.PrisonBlock(world, x, y, z));
                    }
                }
            }
        }

        AbilityManager.prisonBlocksMap.put(uuid, blocks);
        Location jailLoc = new Location(world, (double)baseX + 1.5, 302.0, (double)baseZ + 1.5);
        jailLoc.setYaw(prisoner.getLocation().getYaw());
        jailLoc.setPitch(prisoner.getLocation().getPitch());
        prisoner.teleport(jailLoc);
        prisoner.addPotionEffect(new PotionEffect(PotionEffectType.POISON, Integer.MAX_VALUE, 0));
        prisoner.sendMessage(message);
        int taskId = Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
            this.releaseFromJail(uuid);
        }, (long)seconds * 20L).getTaskId();
        AbilityManager.prisonTasks.put(uuid, taskId);
    }

    private void releaseFromJail(UUID uuid) {
        Integer taskId = (Integer)AbilityManager.prisonTasks.remove(uuid);
        if (taskId != null) {
            Bukkit.getScheduler().cancelTask(taskId);
        }

        List<AbilityManager.PrisonBlock> blocks = (List)AbilityManager.prisonBlocksMap.remove(uuid);
        if (blocks != null) {
            Iterator var4 = blocks.iterator();

            while(var4.hasNext()) {
                AbilityManager.PrisonBlock pb = (AbilityManager.PrisonBlock)var4.next();
                World w = Bukkit.getWorld(pb.world.getUID());
                if (w != null) {
                    w.getBlockAt(pb.x, pb.y, pb.z).setType(Material.AIR);
                }
            }
        }

        Location original = (Location)AbilityManager.prisonOriginalLocation.remove(uuid);
        if (original != null) {
            Player prisoner = Bukkit.getPlayer(uuid);
            if (prisoner != null && prisoner.isOnline()) {
                prisoner.teleport(original);
                prisoner.removePotionEffect(PotionEffectType.POISON);
                prisoner.sendMessage("§6[超能力] §a你已出狱!");
            }
        }

    }

    private void confiscateValuables(Player criminal, Player citizen) {
        boolean anyConfiscated = false;
        ItemStack[] contents = criminal.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() == Material.AIR) continue;
            if (!isValuableMaterial(item.getType())) continue;
            criminal.getInventory().setItem(i, null);
            anyConfiscated = true;
            HashMap<Integer, ItemStack> overflow = citizen.getInventory().addItem(item.clone());
            if (!overflow.isEmpty()) {
                for (ItemStack leftover : overflow.values()) {
                    citizen.getWorld().dropItem(citizen.getLocation(), leftover);
                }
            }
        }
        if (anyConfiscated) {
            citizen.sendMessage("§6[超能力] §a已没收罪犯的贵重物品作为罚款!");
            criminal.sendMessage("§6[超能力] §c你的贵重物品已被没收!");
        }
    }

    private void confiscateToTeamOrRemove(Player criminal, Player citizen) {
        List<Player> teammates = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.equals(citizen)) continue;
            if (p.equals(criminal)) continue;
            if (p.isDead() || !p.isOnline()) continue;
            if (AbilityManager.isSameBattleTeam(citizen, p)) {
                teammates.add(p);
            }
        }

        boolean anyConfiscated = false;
        int teammateIndex = 0;
        ItemStack[] contents = criminal.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i];
            if (item == null || item.getType() == Material.AIR) continue;
            if (!isValuableMaterial(item.getType())) continue;
            criminal.getInventory().setItem(i, null);
            anyConfiscated = true;
            if (!teammates.isEmpty()) {
                Player teammate = teammates.get(teammateIndex % teammates.size());
                teammateIndex++;
                HashMap<Integer, ItemStack> overflow = teammate.getInventory().addItem(item.clone());
                if (!overflow.isEmpty()) {
                    for (ItemStack leftover : overflow.values()) {
                        teammate.getWorld().dropItem(teammate.getLocation(), leftover);
                    }
                }
            }
        }
        if (anyConfiscated) {
            if (!teammates.isEmpty()) {
                for (Player teammate : teammates) {
                    teammate.sendMessage("§6[超能力] §a队友 §e" + citizen.getName() + " §a抓获罪犯，你获得了赃物罚款!");
                }
            }
            criminal.sendMessage("§6[超能力] §c你的贵重物品已被没收!");
        }
    }

    private static boolean isValuableMaterial(Material type) {
        switch (type) {
            case IRON_INGOT: case IRON_NUGGET: case RAW_IRON: case RAW_IRON_BLOCK: case IRON_BLOCK:
            case GOLD_INGOT: case GOLD_NUGGET: case RAW_GOLD: case RAW_GOLD_BLOCK: case GOLD_BLOCK:
            case DIAMOND: case DIAMOND_BLOCK:
            case EMERALD: case EMERALD_BLOCK:
            case NETHERITE_SCRAP: case NETHERITE_INGOT: case NETHERITE_BLOCK: case ANCIENT_DEBRIS:
            case COPPER_INGOT: case RAW_COPPER: case RAW_COPPER_BLOCK: case COPPER_BLOCK:
            case IRON_SWORD: case IRON_PICKAXE: case IRON_AXE: case IRON_SHOVEL: case IRON_HOE:
            case GOLDEN_SWORD: case GOLDEN_PICKAXE: case GOLDEN_AXE: case GOLDEN_SHOVEL: case GOLDEN_HOE:
            case DIAMOND_SWORD: case DIAMOND_PICKAXE: case DIAMOND_AXE: case DIAMOND_SHOVEL: case DIAMOND_HOE:
            case NETHERITE_SWORD: case NETHERITE_PICKAXE: case NETHERITE_AXE: case NETHERITE_SHOVEL: case NETHERITE_HOE:
            case IRON_HELMET: case IRON_CHESTPLATE: case IRON_LEGGINGS: case IRON_BOOTS:
            case GOLDEN_HELMET: case GOLDEN_CHESTPLATE: case GOLDEN_LEGGINGS: case GOLDEN_BOOTS:
            case DIAMOND_HELMET: case DIAMOND_CHESTPLATE: case DIAMOND_LEGGINGS: case DIAMOND_BOOTS:
            case NETHERITE_HELMET: case NETHERITE_CHESTPLATE: case NETHERITE_LEGGINGS: case NETHERITE_BOOTS:
            case BUCKET: case WATER_BUCKET: case LAVA_BUCKET: case MILK_BUCKET:
            case COD_BUCKET: case SALMON_BUCKET: case PUFFERFISH_BUCKET: case TROPICAL_FISH_BUCKET:
            case SHEARS: case FLINT_AND_STEEL:
            case ANVIL: case CHIPPED_ANVIL: case DAMAGED_ANVIL:
            case MINECART: case CHEST_MINECART: case HOPPER_MINECART: case FURNACE_MINECART:
            case HOPPER: case CAULDRON: case COMPASS:
                return true;
            default:
                return false;
        }
    }

    private void handleSoulSummon(Player player) {
        Map<EntityType, Integer> souls = AbilityManager.getSouls(player.getUniqueId());
        if (souls.isEmpty()) {
            player.sendMessage("§6[超能力] §c你没有储存任何怪物灵魂!");
        } else {
            if (player.isSneaking()) {
                this.summonAllMonsters(player, souls);
            } else {
                EntityType type = (EntityType)souls.keySet().iterator().next();
                if (AbilityManager.removeSoul(player.getUniqueId(), type)) {
                    this.summonMonster(player, type);
                    String var10001 = this.getChineseMobName(type);
                    player.sendMessage("§6[超能力] §a你释放了 " + var10001 + " 的灵魂!");
                }
            }

        }
    }

    private void viewSouls(Player player) {
        Map<EntityType, Integer> souls = AbilityManager.getSouls(player.getUniqueId());
        int totalSouls = souls.values().stream().mapToInt(Integer::intValue).sum();
        if (totalSouls > 0) {
            player.sendMessage("§6[超能力] §e当前灵魂数量: §a" + totalSouls + " §e个");
            souls.forEach((type, count) -> {
                String var10001 = this.getChineseMobName(type);
                player.sendMessage("  §7- §f" + var10001 + " §7×" + count);
            });
        } else {
            player.sendMessage("§6[超能力] §c你没有储存任何怪物灵魂!");
        }

    }

    private void summonAllMonsters(Player player, Map<EntityType, Integer> souls) {
        List<EntityType> toSummon = new ArrayList();
        Iterator var4 = souls.entrySet().iterator();

        while(var4.hasNext()) {
            Map.Entry<EntityType, Integer> entry = (Map.Entry)var4.next();

            for(int i = 0; i < (Integer)entry.getValue(); ++i) {
                toSummon.add((EntityType)entry.getKey());
            }
        }

        var4 = toSummon.iterator();

        EntityType type;
        while(var4.hasNext()) {
            type = (EntityType)var4.next();
            AbilityManager.removeSoul(player.getUniqueId(), type);
        }

        var4 = toSummon.iterator();

        while(var4.hasNext()) {
            type = (EntityType)var4.next();
            this.summonMonster(player, type);
        }

        player.sendMessage("§6[超能力] §e你释放了全部灵魂，共 " + toSummon.size() + " 只怪物!");
    }

    private void summonMonster(Player player, EntityType type) {
        LivingEntity entity = (LivingEntity)player.getWorld().spawnEntity(player.getLocation().add(0.0, 1.0, 0.0), type);
        entity.getPersistentDataContainer().set(AbilityManager.getSummonedKey(), PersistentDataType.STRING, player.getUniqueId().toString());
        entity.setGlowing(true);
        entity.setRemoveWhenFarAway(false);
        if (entity instanceof Tameable tameable) {
            tameable.setOwner(player);
        }

    }

    @EventHandler
    public void onSoulTarget(EntityTargetEvent event) {
        Entity entity = event.getEntity();
        if (this.isSummonedMonster(entity)) {
            Entity var4 = event.getTarget();
            if (var4 instanceof Player) {
                Player player = (Player)var4;
                UUID ownerId = this.getOwnerId(entity);
                if (ownerId != null && (player.getUniqueId().equals(ownerId) || (Bukkit.getPlayer(ownerId) != null && AbilityManager.isSameBattleTeam(Bukkit.getPlayer(ownerId), player)))) {
                    event.setCancelled(true);
                    if (entity instanceof Mob) {
                        Mob mob = (Mob)entity;
                        this.redirectToHostileTarget(mob);
                    }
                }
            }

        }
    }

    @EventHandler
    public void onSoulDamageByEntity(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player player) {
            Entity var4 = event.getEntity();
            if (var4 instanceof LivingEntity target) {
                if (!target.isDead()) {
                    if (!this.isSummonedMonster(target)) {
                        AbilityType ability = AbilityManager.getAbility(player);
                        if (ability == AbilityType.SOUL_SUMMONER) {
                            double radius = 32.0;
                            Iterator var7 = target.getNearbyEntities(radius, radius, radius).iterator();

                            while(var7.hasNext()) {
                                Entity nearby = (Entity)var7.next();
                                if (nearby instanceof Mob) {
                                    Mob mob = (Mob)nearby;
                                    if (this.isSummonedMonster(mob)) {
                                        UUID ownerId = this.getOwnerId(mob);
                                        if (ownerId != null && ownerId.equals(player.getUniqueId())) {
                                            mob.setTarget(target);
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }

    private boolean isSummonedMonster(Entity entity) {
        if (AbilityManager.getSummonedKey() == null) {
            return false;
        } else {
            return !(entity instanceof LivingEntity) ? false : entity.getPersistentDataContainer().has(AbilityManager.getSummonedKey(), PersistentDataType.STRING);
        }
    }

    private UUID getOwnerId(Entity entity) {
        if (AbilityManager.getSummonedKey() == null) {
            return null;
        } else if (!(entity instanceof LivingEntity)) {
            return null;
        } else {
            String id = (String)entity.getPersistentDataContainer().get(AbilityManager.getSummonedKey(), PersistentDataType.STRING);
            return id != null ? UUID.fromString(id) : null;
        }
    }

    private void redirectToHostileTarget(Mob monster) {
        UUID ownerId = this.getOwnerId(monster);
        if (ownerId != null) {
            LivingEntity target = null;
            double closest = Double.MAX_VALUE;
            Iterator var6 = monster.getNearbyEntities(16.0, 16.0, 16.0).iterator();

            while(var6.hasNext()) {
                Entity nearby = (Entity)var6.next();
                if (nearby instanceof LivingEntity) {
                    LivingEntity lt = (LivingEntity)nearby;
                    if (this.isHostileMob(lt.getType()) && !lt.isDead() && !this.isSummonedMonster(lt)) {
                        double dist = monster.getLocation().distanceSquared(nearby.getLocation());
                        if (dist < closest) {
                            closest = dist;
                            target = lt;
                        }
                    }
                }
            }

            if (target != null) {
                monster.setTarget(target);
            }

        }
    }

    private boolean isHostileMob(EntityType type) {
        boolean var10000;
        switch (type) {
            case CREEPER:
            case SKELETON:
            case SPIDER:
            case GIANT:
            case ZOMBIE:
            case SLIME:
            case GHAST:
            case ENDERMAN:
            case CAVE_SPIDER:
            case SILVERFISH:
            case BLAZE:
            case MAGMA_CUBE:
            case ENDERMITE:
            case GUARDIAN:
            case ELDER_GUARDIAN:
            case WITHER_SKELETON:
            case STRAY:
            case HUSK:
            case WITCH:
            case SHULKER:
            case PHANTOM:
            case DROWNED:
            case EVOKER:
            case VEX:
            case VINDICATOR:
            case ILLUSIONER:
            case RAVAGER:
            case PIGLIN:
            case ZOMBIFIED_PIGLIN:
            case HOGLIN:
            case PIGLIN_BRUTE:
            case ZOMBIE_VILLAGER:
            case ZOGLIN:
                var10000 = true;
                break;
            default:
                var10000 = false;
        }

        return var10000;
    }

    @EventHandler
    public void onFoodEat(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();
        AbilityType ability = AbilityManager.getAbility(player);
        if (ability != null) {
            ItemStack item = event.getItem();
            if (item != null && item.getType().isEdible()) {
                if (ability == AbilityType.FOOD_BUFF) {
                    Material original = item.getType();
                    Material upgraded = (Material)FOOD_UPGRADES.getOrDefault(original, (Material)null);
                    if (upgraded != null && upgraded != original) {
                        ItemStack newFood = new ItemStack(upgraded, 1);
                        player.getInventory().addItem(new ItemStack[]{newFood});
                        String var10001 = this.getFoodName(original);
                        player.sendMessage("§6⬆ 你的 " + var10001 + " 已升级为 " + this.getFoodName(upgraded));
                    }

                    if (AbilityManager.canEatFood(player)) {
                        AbilityManager.setFoodCooldown(player);
                        this.applyFoodBuffs(player);
                        player.sendMessage("§6[超能力] §a你获得了美食buff!(下次有效需等2分钟)");
                    } else {
                        player.sendMessage("§7美食buff冷却中! 食物已升级但无法获得buff(需2分钟)");
                    }
                }

            }
        }
    }

    private void consumeMainHand(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getAmount() > 1) {
            hand.setAmount(hand.getAmount() - 1);
        } else {
            player.getInventory().setItemInMainHand((ItemStack)null);
        }

    }

    private void applyFoodBuffs(Player player) {
        int buffCount = 1 + this.random.nextInt(3);
        List<PotionEffectType> available = new ArrayList(FOOD_BUFF_EFFECTS);
        List<String> buffNames = new ArrayList();

        for(int i = 0; i < buffCount && !available.isEmpty(); ++i) {
            PotionEffectType effect = (PotionEffectType)available.remove(this.random.nextInt(available.size()));
            int amplifier = this.random.nextInt(5);
            player.addPotionEffect(new PotionEffect(effect, 1200, amplifier, false, true, true));
            String var10001 = this.getBuffEffectName(effect);
            buffNames.add(var10001 + " " + this.toRoman(amplifier + 1));
        }

        player.sendMessage("§d✨ 你获得了1分钟的随机增益效果:");
        Iterator var8 = buffNames.iterator();

        while(var8.hasNext()) {
            String name = (String)var8.next();
            player.sendMessage("  §7- §a" + name);
        }

    }

    @EventHandler
    public void onTame(EntityTameEvent event) {
        if (!event.isCancelled()) {
            AnimalTamer var3 = event.getOwner();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                AbilityType var4 = AbilityManager.getAbility(player);
                if (var4 == AbilityType.TAME_MASTER) {
                    AbilityManager.addTameCount(player);
                }
            }
        }
    }

    @EventHandler
    public void onKillerDamage(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player player) {
            AbilityType var9 = AbilityManager.getAbility(player);
            if (var9 == AbilityType.KILLER) {
                double originalDamage = event.getDamage();
                int kills = AbilityManager.getKillCount(player.getUniqueId());
                if (kills < AbilityManager.getReductionThreshold()) {
                    event.setDamage(originalDamage / 4.0);
                } else {
                    double damage = originalDamage;
                    if (kills >= AbilityManager.getKillThreshold()) {
                        damage = originalDamage + AbilityManager.getKillDamageBonus(player.getUniqueId());
                    }

                    event.setDamage(damage);
                }

            }
        }
    }

    @EventHandler
    public void onDamageEffect(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType var10 = AbilityManager.getAbility(player);
            if (var10 == AbilityType.DAMAGE_EFFECT) {
                boolean positive = this.random.nextBoolean();
                if (positive) {
                    List<ItemStack> items = new ArrayList();
                    ItemStack[] var6 = player.getInventory().getContents();
                    int amount = var6.length;

                    for(int var8 = 0; var8 < amount; ++var8) {
                        ItemStack item = var6[var8];
                        if (item != null && item.getType() != Material.AIR) {
                            items.add(item);
                        }
                    }

                    if (!items.isEmpty()) {
                        ItemStack target = (ItemStack)items.get(this.random.nextInt(items.size()));
                        amount = target.getAmount();
                        target.setAmount(Math.min(amount * 2, target.getMaxStackSize()));
                        player.sendMessage("§a✨ 受伤触发效果! 背包中的物品数量翻倍!");
                    }
                } else {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 600, 1, false, true, true));
                    player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 600, 0, false, true, true));
                    player.sendMessage("§a✨ 受伤触发效果! 获得速度和生命恢复!");
                }

            }
        }
    }

    @EventHandler
    public void onTameMasterJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        AbilityType ability = AbilityManager.getAbility(player);
        if (ability == AbilityType.TAME_MASTER) {
            AbilityManager.applyTameStrengthEffect(player);
        }

    }

    @EventHandler
    public void onTameMasterRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == AbilityType.TAME_MASTER) {
                AbilityManager.applyTameStrengthEffect(player);
            }

        }, 5L);
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        Entity var3 = event.getDamager();
        if (var3 instanceof Player attacker) {
            if (this.isControlledPlayer(attacker)) {
                event.setCancelled(true);
                return;
            }
        }

        var3 = event.getDamager();
        Player victim;
        if (var3 instanceof Player attacker) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null && mm.isControlling(attacker.getUniqueId())) {
                victim = mm.getTarget(attacker);
                if (victim != null && victim.isOnline()) {
                    victim.damage(event.getFinalDamage());
                }

                event.setCancelled(true);
                return;
            }
        }

        Entity shooter = event.getDamager();
        if (shooter instanceof EvokerFangs fang) {
            shooter = event.getEntity();
            if (shooter instanceof Player attacker) {
                String casterId = (String)fang.getPersistentDataContainer().get(new NamespacedKey(Main.getInstance(), "fang_caster"), PersistentDataType.STRING);
                if (casterId != null && attacker.getUniqueId().toString().equals(casterId)) {
                    event.setCancelled(true);
                    return;
                }
            }
        }

        shooter = event.getDamager();
        if (shooter instanceof IronGolem golem) {
            shooter = event.getEntity();
            if (shooter instanceof LivingEntity target) {
                Iterator var19 = AbilityManager.getPlayerGolemsMap().entrySet().iterator();

                while(var19.hasNext()) {
                    Map.Entry<UUID, List<UUID>> entry = (Map.Entry)var19.next();
                    UUID ownerId = (UUID)entry.getKey();
                    List<UUID> golemIds = (List)entry.getValue();
                    if (golemIds.contains(golem.getUniqueId())) {
                        if (target instanceof Player) {
                            Player targetPlayer = (Player)target;
                            if (targetPlayer.getUniqueId().equals(ownerId)) {
                                event.setCancelled(true);
                                return;
                            }
                        }

                        if (golemIds.contains(target.getUniqueId())) {
                            event.setCancelled(true);
                            return;
                        }
                        break;
                    }
                }
            }
        }

        var3 = event.getDamager();
        AbilityType attAbility;
        Entity var18;
        LivingEntity damager;
        if (var3 instanceof Player attacker) {
            attAbility = AbilityManager.getAbility(attacker);
            if (attAbility == AbilityType.NECROMANCER) {
                var18 = event.getEntity();
                if (var18 instanceof LivingEntity) {
                    damager = (LivingEntity)var18;
                    Iterator var20 = damager.getLocation().getNearbyEntities(10.0, 10.0, 10.0).iterator();

                    while(var20.hasNext()) {
                        Entity entity = (Entity)var20.next();
                        if (this.isUndead(entity) && entity instanceof Mob) {
                            Mob mob = (Mob)entity;
                            mob.setTarget(damager);
                        }
                    }
                }
            }
        }

        var3 = event.getDamager();
        Entity entity;
        IronGolem golem;
        List ownGolems;
        List golemIds;
        Iterator var28;
        UUID golemId;
        if (var3 instanceof Player attacker) {
            attAbility = AbilityManager.getAbility(attacker);
            if (attAbility == AbilityType.RICH_MAN) {
                var18 = event.getEntity();
                if (var18 instanceof LivingEntity) {
                    damager = (LivingEntity)var18;
                    ownGolems = AbilityManager.getPlayerGolems(attacker.getUniqueId());
                    if (ownGolems != null && ownGolems.contains(damager.getUniqueId())) {
                        return;
                    }

                    AbilityManager.addRichManTarget(attacker.getUniqueId(), damager.getUniqueId());
                    golemIds = AbilityManager.getPlayerGolems(attacker.getUniqueId());
                    if (golemIds != null) {
                        var28 = golemIds.iterator();

                        while(var28.hasNext()) {
                            golemId = (UUID)var28.next();
                            entity = Bukkit.getEntity(golemId);
                            if (entity instanceof IronGolem) {
                                golem = (IronGolem)entity;
                                if (entity.isValid()) {
                                    golem.setTarget(damager);
                                }
                            }
                        }
                    }
                }
            }
        }

        var3 = event.getEntity();
        if (var3 instanceof Player attacker) {
            if (AbilityManager.isReflectorActive(attacker.getUniqueId())) {
                shooter = event.getDamager();
                if (shooter instanceof Projectile) {
                    Projectile projectile = (Projectile)shooter;
                    event.setCancelled(true);
                    shooter = (Entity)projectile.getShooter();
                    if (shooter != null) {
                        Vector reverse = projectile.getVelocity().normalize().multiply(-2);
                        projectile.setVelocity(reverse);
                        projectile.setShooter(attacker);
                    }

                    return;
                }

                shooter = event.getDamager();
                if (shooter instanceof Player) {
                    attacker = (Player)shooter;
                    if (!attacker.equals(attacker)) {
                        double reflectDamage = event.getFinalDamage() * 0.5;
                        attacker.damage(reflectDamage, attacker);
                    }
                }
            }
        }

        var3 = event.getEntity();
        if (var3 instanceof Player attacker) {
            attAbility = AbilityManager.getAbility(attacker);
            if (attAbility != null) {
                Set<EntityType> friendly = (Set)FRIENDLY_MOBS.get(attAbility);
                if (friendly != null && friendly.contains(event.getDamager().getType())) {
                    event.setCancelled(true);
                    return;
                }
            }

            if (attAbility == AbilityType.BARBARIAN) {
                AbilityManager.applyBarbarianEffects(attacker);
            }

            if (attAbility == AbilityType.RICH_MAN) {
                var18 = event.getDamager();
                if (var18 instanceof LivingEntity) {
                    damager = (LivingEntity)var18;
                    ownGolems = AbilityManager.getPlayerGolems(attacker.getUniqueId());
                    if (ownGolems != null && ownGolems.contains(damager.getUniqueId())) {
                        return;
                    }

                    AbilityManager.addRichManTarget(attacker.getUniqueId(), damager.getUniqueId());
                    golemIds = AbilityManager.getPlayerGolems(attacker.getUniqueId());
                    if (golemIds != null) {
                        var28 = golemIds.iterator();

                        while(var28.hasNext()) {
                            golemId = (UUID)var28.next();
                            entity = Bukkit.getEntity(golemId);
                            if (entity instanceof IronGolem) {
                                golem = (IronGolem)entity;
                                if (entity.isValid()) {
                                    golem.setTarget(damager);
                                }
                            }
                        }
                    }
                }
            }
        }

    }

    @EventHandler
    public void onEntityTarget(EntityTargetEvent event) {
        Entity var3 = event.getTarget();
        if (var3 instanceof Player player) {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability != null) {
                Set<EntityType> friendly = (Set)FRIENDLY_MOBS.get(ability);
                if (friendly != null && friendly.contains(event.getEntity().getType())) {
                    event.setCancelled(true);
                    return;
                }
            }
        }

        Entity var11 = event.getEntity();
        if (var11 instanceof IronGolem golem) {
            var11 = event.getTarget();
            if (var11 instanceof LivingEntity target) {
                Iterator var12 = AbilityManager.getPlayerGolemsMap().entrySet().iterator();

                while(var12.hasNext()) {
                    Map.Entry<UUID, List<UUID>> entry = (Map.Entry)var12.next();
                    UUID ownerId = (UUID)entry.getKey();
                    List<UUID> golemIds = (List)entry.getValue();
                    if (golemIds != null && golemIds.contains(golem.getUniqueId())) {
                        if (!AbilityManager.isRichManTarget(ownerId, target.getUniqueId())) {
                            event.setCancelled(true);
                        }
                        break;
                    }
                }
            }
        }

    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity var3 = event.getEntity();
        if (var3 instanceof LivingEntity) {
            LivingEntity deadEntity = var3;
            if (var3 instanceof Player) {
                return;
            }

            Player killer = var3.getKiller();
            if (killer == null) {
                return;
            }

            if (deadEntity instanceof Animals) {
                this.trackCitizenCrime(killer.getUniqueId(), "hunt", 5);
            }

            AbilityType ability = AbilityManager.getAbility(killer);
            if (ability == null) {
                return;
            }

            if (ability == AbilityType.LUCKY) {
                AbilityManager.processEntityDrops(killer, deadEntity.getLocation(), event.getDrops());
            }

            if (ability == AbilityType.SOUL_SUMMONER) {
                AbilityManager.addSoul(killer.getUniqueId(), deadEntity.getType());
                String var10001 = this.getChineseMobName(deadEntity.getType());
                killer.sendMessage("§6[超能力] §a你获得了 " + var10001 + " 的灵魂!");
            }

            if (ability == AbilityType.KILLER) {
                AbilityManager.addKillCount(killer);
            }
        }

    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onFieldWeaverDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player victim) {
            if (AbilityManager.getFieldWeaverAffectedPlayers().contains(victim.getUniqueId())) {
                if (event.isCancelled()) return;
                AbilityType victimAbility = AbilityManager.getAbility(victim);
                double multiplier = 1.5;
                if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                    multiplier = 2.0;
                }
                if (victimAbility == AbilityType.SUPERMAN || victimAbility == AbilityType.FAIRY) {
                    multiplier = Math.max(multiplier, 2.0);
                }
                if (event instanceof EntityDamageByEntityEvent entityEvent) {
                    Entity damager = entityEvent.getDamager();
                    if (damager instanceof Player attacker) {
                        if (AbilityManager.isSameBattleTeam(attacker, victim)) {
                            return;
                        }
                    }
                }
                event.setDamage(event.getDamage() * multiplier);
            }
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null && mm.isControlling(player.getUniqueId())) {
                Player target = mm.getTarget(player);
                if (target != null && target.isOnline()) {
                    target.damage(event.getFinalDamage());
                }

                event.setCancelled(true);
                return;
            }

            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == null) {
                return;
            }

            Set<EntityType> friendly = (Set)FRIENDLY_MOBS.get(ability);
            EntityDamageByEntityEvent dmgEvent;
            Entity damager;
            if (friendly != null) {
                if (friendly.contains(EntityType.WITCH) && event.getCause() == DamageCause.MAGIC) {
                    event.setCancelled(true);
                    return;
                }

                if (event instanceof EntityDamageByEntityEvent) {
                    dmgEvent = (EntityDamageByEntityEvent)event;
                    damager = dmgEvent.getDamager();
                    EntityType damagerType = damager.getType();
                    if (friendly.contains(damagerType)) {
                        event.setCancelled(true);
                        return;
                    }

                    if (damager instanceof Projectile) {
                        Projectile projectile = (Projectile)damager;
                        ProjectileSource var11 = projectile.getShooter();
                        if (var11 instanceof Entity) {
                            Entity shooter = (Entity)var11;
                            if (friendly.contains(shooter.getType())) {
                                event.setCancelled(true);
                                return;
                            }
                        }
                    }
                }
            }

            Player p = null;
            if (event instanceof EntityDamageByEntityEvent) {
                damager = ((EntityDamageByEntityEvent)event).getDamager();
                if (damager instanceof Player) {
                    p = (Player)damager;
                } else if (damager instanceof Projectile projectile) {
                    ProjectileSource var12 = projectile.getShooter();
                    if (var12 instanceof Player) {
                        p = (Player)var12;
                    }
                }

                if (p != null && !p.getUniqueId().equals(player.getUniqueId())) {
                    this.trackCitizenCrime(p.getUniqueId(), "hit", 5);
                }
            }

            if (AbilityManager.isGuardianShieldActive(player.getUniqueId())) {
                event.setCancelled(true);
                AbilityManager.consumeGuardianShield(player.getUniqueId());
                return;
            }

            boolean legionProtected = AbilityManager.isLegionFormationActive(player.getUniqueId());
            if (!legionProtected) {
                Iterator var21 = player.getLocation().getNearbyPlayers(3.0).iterator();

                while(var21.hasNext()) {
                    p = (Player)var21.next();
                    if (AbilityManager.isLegionFormationActive(p.getUniqueId())) {
                        legionProtected = true;
                        break;
                    }
                }
            }

            if (legionProtected && this.isDamageFromSideOrBack(player, event)) {
                event.setCancelled(true);
                return;
            }

            if (ability == AbilityType.BARBARIAN) {
                Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                    AbilityManager.applyBarbarianEffects(player);
                }, 1L);
            }

            if (ability == AbilityType.HYDROPHOBIC && (event.getCause() == DamageCause.DROWNING || event.getCause() == DamageCause.SUFFOCATION)) {
                event.setCancelled(true);
                player.setHealth(0.0);
            }

            if (ability == AbilityType.LIGHTNING_KING && event.getCause() == DamageCause.LIGHTNING) {
                event.setCancelled(true);
                return;
            }

            if (ability == AbilityType.LUCKY && Math.random() < 0.15) {
                event.setCancelled(true);
                player.sendMessage("§6[超能力] §a幸运之神眷顾了你! 伤害已免除");
                return;
            }

            double finalDamage;
            if (ability == AbilityType.SOUL_SUMMONER) {
                if (player.getHealth() <= 0.0) {
                    return;
                }

                event.setCancelled(true);
                finalDamage = event.getFinalDamage();
                double totalDamage = finalDamage * 3.0;
                List<LivingEntity> summons = new ArrayList();
                Iterator var33 = Bukkit.getWorlds().iterator();

                while(true) {
                    Iterator var14;
                    if (!var33.hasNext()) {
                        double remainingDamage = totalDamage;
                        var14 = summons.iterator();

                        while(var14.hasNext()) {
                            LivingEntity summon = (LivingEntity)var14.next();
                            if (remainingDamage <= 0.0) {
                                break;
                            }

                            double summonHealth = summon.getHealth();
                            if (remainingDamage < summonHealth) {
                                summon.damage(remainingDamage);
                                remainingDamage = 0.0;
                            } else {
                                summon.damage(summonHealth);
                                remainingDamage -= summonHealth;
                            }
                        }

                        if (remainingDamage > 0.0) {
                            player.setHealth(Math.max(0.0, player.getHealth() - remainingDamage));
                            if (!summons.isEmpty()) {
                                Object[] var10002 = new Object[]{remainingDamage};
                                player.sendMessage("§6[超能力] §c召唤生物已全部阵亡, 你承受了 §e" + String.format("%.1f", var10002) + " §c点溢出伤害!");
                            }
                        }
                        break;
                    }

                    World world = (World)var33.next();
                    var14 = world.getEntities().iterator();

                    while(var14.hasNext()) {
                        Entity entity = (Entity)var14.next();
                        if (entity instanceof LivingEntity) {
                            LivingEntity living = (LivingEntity)entity;
                            if (this.isSummonedMonster(entity)) {
                                UUID ownerId = this.getOwnerId(entity);
                                if (ownerId != null && ownerId.equals(player.getUniqueId()) && !living.isDead()) {
                                    summons.add(living);
                                }
                            }
                        }
                    }
                }
            }

            if (ability == AbilityType.HEX_MASTER && AbilityManager.hasHexProtection(player)) {
                finalDamage = event.getFinalDamage();
                if (player.getHealth() - finalDamage <= 0.0) {
                    event.setCancelled(true);
                    AbilityManager.setHexProtection(player, false);
                    player.setHealth(player.getMaxHealth());
                    List<Player> others = new ArrayList();
                    Iterator var29 = Bukkit.getOnlinePlayers().iterator();

                    while(var29.hasNext()) {
                        p = (Player)var29.next();
                        if (!p.equals(player) && !AbilityManager.isCodeKillProtected(p) && p.getGameMode() != GameMode.SPECTATOR && !isSameBattleTeam(player, p)) {
                            others.add(p);
                        }
                    }

                    if (!others.isEmpty()) {
                        Player sacrifice = (Player)others.get((new Random()).nextInt(others.size()));
                        AbilityManager.setForcedKiller(sacrifice.getUniqueId(), player.getUniqueId());
                        sacrifice.setHealth(0.0);
                        player.sendMessage("§6[超能力] §c蛊术保护触发! " + sacrifice.getName() + " 替你承受了死亡!");
                        sacrifice.sendMessage("§6[超能力] §c你被" + player.getName() + "的蛊术诅咒，代其而死!");
                    } else {
                        player.sendMessage("§6[超能力] §c蛊术保护触发，但没有可献祭的目标!");
                    }
                }
            }

            if (ability == AbilityType.RECALL) {
                double dmg = event.getFinalDamage();
                if (player.getHealth() - dmg <= 0.0) {
                    Location recorded = (Location)this.recallLocations.get(player.getUniqueId());
                    if (recorded != null && !AbilityManager.isRecallPassiveUsed(player.getUniqueId())) {
                        event.setCancelled(true);
                        player.teleport(recorded);
                        AbilityManager.setRecallPassiveUsed(player.getUniqueId());
                        player.sendMessage("§6[回溯者] §b替死回溯触发! 你已回到记录点");
                        player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                        player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0.0, 1.0, 0.0), 50, 0.5, 0.5, 0.5, 1.0);
                        player.setHealth(player.getMaxHealth());
                    }
                }
            }
        }

    }

    @EventHandler
    public void onEntityRegainHealth(EntityRegainHealthEvent event) {
        Entity var3 = event.getEntity();
        if (var3 instanceof Player player) {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == AbilityType.BARBARIAN) {
                Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                    AbilityManager.applyBarbarianEffects(player);
                }, 1L);
            }
        }

    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        } else {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == AbilityType.LUCKY) {
                AbilityManager.processBlockBreak(player, event.getBlock(), event.getBlock().getDrops(player.getInventory().getItemInMainHand()));
            }

            if (ability == AbilityType.DIGGER) {
                AbilityManager.processDiggerDrop(player);
            }

            Material type = event.getBlock().getType();
            String name = type.name();
            if (name.endsWith("_LOG") || name.endsWith("_WOOD") || name.endsWith("_STEM") || name.equals("MUSHROOM_STEM")) {
                this.trackCitizenCrime(player.getUniqueId(), "chop_tree", 5);
            } else if (name.endsWith("_ORE") || NATURAL_BLOCKS.contains(type)) {
                this.trackCitizenCrime(player.getUniqueId(), "mine", 5);
            }

        }
    }

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (!this.isControlledPlayer(player)) {
            this.trackCitizenCrime(player.getUniqueId(), "build", 5);
        }
    }

    @EventHandler
    public void onBlockIgnite(BlockIgniteEvent event) {
        if (event.getPlayer() != null) {
            this.trackCitizenCrime(event.getPlayer().getUniqueId(), "arson", 5);
        }
    }

    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        HumanEntity var3 = event.getView().getPlayer();
        if (var3 instanceof Player player) {
            AbilityType ability = AbilityManager.getAbility(player);
            if (ability == AbilityType.BLACKSMITH) {
                ItemStack result = event.getInventory().getResult();
                if (result != null && this.isWeaponOrArmor(result.getType())) {
                    ItemStack enchantedResult = result.clone();
                    this.applyRelevantEnchantments(enchantedResult);
                    event.getInventory().setResult(enchantedResult);
                }
            }
        }

    }

    public static void followTask() {
        if (AbilityManager.getSummonedKey() != null) {
            Iterator var0 = Bukkit.getWorlds().iterator();

            while(var0.hasNext()) {
                World world = (World)var0.next();
                Iterator var2 = world.getEntities().iterator();

                while(var2.hasNext()) {
                    Entity entity = (Entity)var2.next();
                    if (entity instanceof Mob) {
                        Mob mob = (Mob)entity;
                        if (mob.getPersistentDataContainer().has(AbilityManager.getSummonedKey(), PersistentDataType.STRING)) {
                            String id = (String)mob.getPersistentDataContainer().get(AbilityManager.getSummonedKey(), PersistentDataType.STRING);
                            if (id != null) {
                                UUID ownerId = UUID.fromString(id);
                                Player owner = Bukkit.getPlayer(ownerId);
                                if (owner != null && owner.isOnline() && owner.getWorld().equals(mob.getWorld()) && mob.getTarget() == null) {
                                    double distance = mob.getLocation().distanceSquared(owner.getLocation());
                                    if (distance > 900.0) {
                                        mob.teleport(owner.getLocation().add(0.0, 1.0, 0.0));
                                    } else if (distance > 16.0) {
                                        mob.getPathfinder().moveTo(owner.getLocation(), 1.0);
                                    }
                                }
                            }
                        }
                    }
                }
            }

        }
    }

    private void removeSummonedMonsters(Player player) {
        if (AbilityManager.getSummonedKey() != null) {
            UUID playerId = player.getUniqueId();
            Iterator var3 = Bukkit.getWorlds().iterator();

            while(var3.hasNext()) {
                World world = (World)var3.next();
                Iterator var5 = world.getEntities().iterator();

                while(var5.hasNext()) {
                    Entity entity = (Entity)var5.next();
                    if (entity.getPersistentDataContainer().has(AbilityManager.getSummonedKey(), PersistentDataType.STRING)) {
                        String ownerId = (String)entity.getPersistentDataContainer().get(AbilityManager.getSummonedKey(), PersistentDataType.STRING);
                        if (ownerId != null && ownerId.equals(playerId.toString())) {
                            entity.remove();
                        }
                    }
                }
            }

        }
    }

    private void applyKillerDamageModifier(Player player) {
        AbilityType ability = AbilityManager.getAbility(player);
        if (ability == AbilityType.KILLER) {
            AttributeInstance attr = player.getAttribute(Attribute.ATTACK_DAMAGE);
            if (attr != null) {
                killDamageModifier(player, attr);
            }
        }
    }

    public static void killDamageModifier(Player player, AttributeInstance attr) {
        int kills = AbilityManager.getKillCount(player.getUniqueId());
        if (kills >= AbilityManager.getKillThreshold()) {
            double bonus = AbilityManager.getKillDamageBonus(player.getUniqueId());
            double currentBonus = Math.min(bonus, AbilityManager.getMaxKillDamage());
            NamespacedKey key = new NamespacedKey(Main.getInstance(), "kill_damage_modifier");
            attr.removeModifier(key);
            AttributeModifier modifier = new AttributeModifier(key, currentBonus, Operation.ADD_NUMBER);
            attr.addTransientModifier(modifier);
        }

    }

    private void handleTimeStopTrigger(Player player) {
        if (AbilityManager.canUseTimeStop(player)) {
            AbilityManager.setTimeStopCooldown(player);
            AbilityManager.startTimeStop(player);
        }
    }

    private void handleRecallRecord(Player player) {
        UUID uuid = player.getUniqueId();
        Long lastRecord = (Long)this.recordCooldowns.get(uuid);
        if (lastRecord != null && System.currentTimeMillis() - lastRecord < 1000L) {
            player.sendMessage("§c记录冷却中! 请稍后");
        } else {
            Location loc = player.getLocation().clone();
            this.recallLocations.put(uuid, loc);
            this.recordCooldowns.put(uuid, System.currentTimeMillis());
            player.sendMessage("§6[回溯者] §a已记录当前位置! 空手按技能键可回溯至此");
            player.getWorld().playSound(player.getLocation(), Sound.BLOCK_ENDER_CHEST_OPEN, 1.0F, 1.0F);
            player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0.0, 1.0, 0.0), 30, 0.5, 0.5, 0.5, 0.5);
        }
    }

    private void handleRecallTeleport(Player player) {
        UUID uuid = player.getUniqueId();
        Location recorded = (Location)this.recallLocations.get(uuid);
        if (recorded == null) {
            player.sendMessage("§6[回溯者] §c尚未记录位置! 技能键2记录当前位置");
        } else {
            Long cooldownEnd = (Long)this.recallCooldowns.get(uuid);
            if (cooldownEnd != null) {
                long remaining = (cooldownEnd + 10000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c回溯冷却中! 剩余 §e" + remaining + " §c秒");
                    return;
                }

                this.recallCooldowns.remove(uuid);
            }

            player.teleport(recorded);
            this.recallCooldowns.put(uuid, System.currentTimeMillis());
            player.sendMessage("§6[回溯者] §a已回到记录位置! (10秒冷却)");
            player.getWorld().playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
            player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation().add(0.0, 1.0, 0.0), 50, 0.5, 0.5, 0.5, 1.0);
        }
    }

    private void handleFieldWeaverActivate(Player player) {
        if (AbilityManager.canUseFieldWeaver(player)) {
            AbilityManager.setFieldWeaverCooldown(player);
            AbilityManager.startFieldWeaver(player);
        }
    }

    private void handleMindControl(Player player) {
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlling(player.getUniqueId())) {
                if (player.isSneaking()) {
                    mm.openTargetInventory(player);
                } else {
                    player.sendMessage("§c你已经在控制其他玩家了!");
                }

            } else if (AbilityManager.canMindControl(player)) {
                RayTraceResult rayTraceResult = player.rayTraceEntities(10, true);
                if (rayTraceResult == null) {
                    player.sendMessage("§c请对准一名玩家!");
                } else {
                    Entity target = rayTraceResult.getHitEntity();
                    if (target instanceof Player) {
                        Player targetPlayer = (Player)target;
                        if (targetPlayer.getGameMode() == GameMode.SPECTATOR) {
                            player.sendMessage("§c无法控制旁观模式的玩家!");
                        } else {
                            MindControlManager.ControlState state = mm.startControl(player, targetPlayer);
                            if (state == ControlState.SUCCESS) {
                                AbilityManager.setMindControlCooldown(player);
                            } else {
                                switch (state) {
                                    case OFFLINE:
                                        player.sendMessage("§c目标已离线!");
                                        break;
                                    case ALREADY_CONTROLLING:
                                        player.sendMessage("§c你已经在控制其他玩家了!");
                                        break;
                                    case ALREADY_CONTROLLED:
                                        player.sendMessage("§c该玩家正在被其他人控制!");
                                        break;
                                    case INVALID_TARGET:
                                        player.sendMessage("§c不能控制自己!");
                                        break;
                                    default:
                                        player.sendMessage("§c控制失败!");
                                }
                            }

                        }
                    } else {
                        player.sendMessage("§c请对准一名玩家!");
                    }
                }
            }
        }
    }

    private boolean isControlledPlayer(Player player) {
        MindControlManager mm = MindControlManager.getInstance();
        return mm != null && mm.isControlled(player.getUniqueId());
    }

    private boolean isControllingPlayer(Player player) {
        MindControlManager mm = MindControlManager.getInstance();
        return mm != null && mm.isControlling(player.getUniqueId());
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerMove(PlayerMoveEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerInteract(PlayerInteractEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerInteractEntity(PlayerInteractEntityEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerDropItem(PlayerDropItemEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerPickupItem(PlayerAttemptPickupItemEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerBucketFill(PlayerBucketFillEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerFish(PlayerFishEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopBlockBreak(BlockBreakEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopBlockPlace(BlockPlaceEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopInventoryClick(InventoryClickEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getWhoClicked();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }

            }
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopInventoryDrag(InventoryDragEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getWhoClicked();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }

            }
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityDamage(EntityDamageEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
            AbilityManager.accumulateDamage(event.getEntity().getUniqueId(), event.getFinalDamage(), (Entity)null);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
            AbilityManager.accumulateDamage(event.getEntity().getUniqueId(), event.getFinalDamage(), event.getDamager());
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopEntityShootBow(EntityShootBowEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            LivingEntity var3 = event.getEntity();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                    return;
                }
            }

            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopProjectileLaunch(ProjectileLaunchEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            ProjectileSource var3 = event.getEntity().getShooter();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                    return;
                }

                if (AbilityManager.isTimeStopTriggerPlayer(player)) {
                    player.sendMessage("§c时停期间无法发射弹射物！");
                }
            }

            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopCreatureSpawn(CreatureSpawnEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            event.setCancelled(true);
        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopFoodLevelChange(FoodLevelChangeEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            HumanEntity var3 = event.getEntity();
            if (var3 instanceof Player) {
                Player player = (Player)var3;
                if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                    event.setCancelled(true);
                }
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerItemDamage(PlayerItemDamageEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerItemConsume(PlayerItemConsumeEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
                player.sendMessage("§c时停期间无法使用命令！");
            }

        }
    }

    @EventHandler(
            priority = EventPriority.LOWEST
    )
    public void onTimeStopAsyncPlayerChat(AsyncPlayerChatEvent event) {
        if (AbilityManager.isTimeStopActive()) {
            Player player = event.getPlayer();
            if (AbilityManager.isFrozenPlayer(player.getUniqueId())) {
                event.setCancelled(true);
                player.sendMessage("§c时停期间无法聊天！");
            }

        }
    }

    @EventHandler
    public void onMindControlPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlling(player.getUniqueId())) {
                mm.releaseControl(player);
            } else if (mm.isControlled(player.getUniqueId())) {
                mm.releaseControlByTarget(player);
            }

            if (AbilityManager.isGuardianShieldActive(uuid)) {
                UUID giverUuid = AbilityManager.getGuardianGiver(uuid);
                if (giverUuid != null) {
                    AbilityManager.setGuardianCooldown(giverUuid);
                    Player giver = Bukkit.getPlayer(giverUuid);
                    if (giver != null) {
                        giver.sendMessage("§6[超能力] §c你的守护目标已离线,护盾消失!");
                    }
                }

                AbilityManager.clearGuardianShieldData(uuid);
            }

        }
    }

    @EventHandler
    public void onMindControlPlayerChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlled(player.getUniqueId())) {
                mm.releaseControlByTarget(player);
            }

        }
    }

    @EventHandler
    public void onMindControlBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlBucketFill(PlayerBucketFillEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlPlayerFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlInventoryClick(InventoryClickEvent event) {
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    int slot = event.getRawSlot();
                    if (slot >= 5 && slot <= 8) {
                        event.setCancelled(true);
                    } else {
                        if (slot < 0 || slot >= 45) {
                            event.setCancelled(true);
                        }

                    }
                }
            }
        }
    }

    @EventHandler
    public void onMindControlInventoryDrag(InventoryDragEvent event) {
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    Iterator var4 = event.getRawSlots().iterator();

                    int slot;
                    do {
                        if (!var4.hasNext()) {
                            return;
                        }

                        slot = (Integer)var4.next();
                        if (slot >= 5 && slot <= 8) {
                            event.setCancelled(true);
                            return;
                        }
                    } while(slot >= 0 && slot < 45);

                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onMindControlInventoryClose(InventoryCloseEvent event) {
        HumanEntity var3 = event.getPlayer();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    mm.setInventoryClosed(player.getUniqueId());
                    Player target = mm.getTarget(player);
                    if (target != null && target.isOnline()) {
                        mm.syncInventoryToTarget(event.getInventory(), target);
                    }

                }
            }
        }
    }

    private boolean isUndead(Entity entity) {
        return UNDEAD_TYPES.contains(entity.getType());
    }

    private boolean isInWater(Player player) {
        if (player.getVehicle() instanceof org.bukkit.entity.Boat) return false;
        return this.isWaterBlock(player.getLocation().getBlock()) || this.isWaterBlock(player.getLocation().add(0.0, 1.0, 0.0).getBlock());
    }

    private boolean isWaterBlock(Block block) {
        return block.getType() == Material.WATER || block.getType() == Material.WATER_CAULDRON;
    }

    private boolean isDamageFromSideOrBack(Player player, EntityDamageEvent event) {
        if (event instanceof EntityDamageByEntityEvent entityEvent) {
            Location playerLoc = player.getLocation();
            Vector forward = playerLoc.getDirection().normalize();
            Vector toDamager = entityEvent.getDamager().getLocation().toVector().subtract(playerLoc.toVector()).normalize();
            double var7 = forward.dot(toDamager);
            return var7 < 0.5;
        } else {
            return false;
        }
    }

    private double getMaxHealth(LivingEntity entity) {
        AttributeInstance attr = entity.getAttribute(Attribute.MAX_HEALTH);
        return attr == null ? 20.0 : attr.getValue();
    }

    private boolean isWeaponOrArmor(Material material) {
        String name = material.name();
        return name.contains("SWORD") || name.contains("AXE") || name.contains("PICKAXE") || name.contains("SHOVEL") || name.contains("HOE") || name.contains("HELMET") || name.contains("CHESTPLATE") || name.contains("LEGGINGS") || name.contains("BOOTS") || name.contains("SHIELD") || name.contains("BOW") || name.contains("CROSSBOW") || name.contains("TRIDENT") || name.contains("ELYTRA") || name.contains("MACE") || name.contains("SPEAR");
    }

    private void applyRelevantEnchantments(ItemStack item) {
        Material type = item.getType();
        String name = type.name();
        List<List<Enchantment>> enchantmentGroups = new ArrayList();
        if (name.contains("SWORD")) {
            enchantmentGroups.add(Arrays.asList(Enchantment.SHARPNESS, Enchantment.SMITE, Enchantment.BANE_OF_ARTHROPODS));
            enchantmentGroups.add(Arrays.asList(Enchantment.LOOTING));
            enchantmentGroups.add(Arrays.asList(Enchantment.FIRE_ASPECT));
            enchantmentGroups.add(Arrays.asList(Enchantment.KNOCKBACK));
            enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
            enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
        } else if (!name.contains("PICKAXE") && !name.contains("SHOVEL") && !name.contains("HOE")) {
            if (name.contains("AXE")) {
                enchantmentGroups.add(Arrays.asList(Enchantment.EFFICIENCY));
                enchantmentGroups.add(Arrays.asList(Enchantment.FORTUNE, Enchantment.SILK_TOUCH));
                enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                enchantmentGroups.add(Arrays.asList(Enchantment.SHARPNESS, Enchantment.SMITE, Enchantment.BANE_OF_ARTHROPODS));
            } else if (name.contains("HELMET")) {
                enchantmentGroups.add(Arrays.asList(Enchantment.PROTECTION, Enchantment.FIRE_PROTECTION, Enchantment.BLAST_PROTECTION, Enchantment.PROJECTILE_PROTECTION));
                enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                enchantmentGroups.add(Arrays.asList(Enchantment.RESPIRATION));
                enchantmentGroups.add(Arrays.asList(Enchantment.AQUA_AFFINITY));
                enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
            } else if (!name.contains("CHESTPLATE") && !name.contains("LEGGINGS")) {
                if (name.contains("BOOTS")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.PROTECTION, Enchantment.FIRE_PROTECTION, Enchantment.BLAST_PROTECTION, Enchantment.PROJECTILE_PROTECTION));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.FEATHER_FALLING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.DEPTH_STRIDER, Enchantment.FROST_WALKER));
                    enchantmentGroups.add(Arrays.asList(Enchantment.SOUL_SPEED));
                    enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
                } else if (name.contains("BOW")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.POWER));
                    enchantmentGroups.add(Arrays.asList(Enchantment.FLAME));
                    enchantmentGroups.add(Arrays.asList(Enchantment.PUNCH));
                    enchantmentGroups.add(Arrays.asList(Enchantment.INFINITY));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
                } else if (name.contains("CROSSBOW")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.PIERCING, Enchantment.MULTISHOT));
                    enchantmentGroups.add(Arrays.asList(Enchantment.QUICK_CHARGE));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
                } else if (name.contains("TRIDENT")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.IMPALING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.LOYALTY, Enchantment.RIPTIDE));
                    enchantmentGroups.add(Arrays.asList(Enchantment.CHANNELING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
                } else if (name.contains("MACE")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.FIRE_ASPECT));
                    enchantmentGroups.add(Arrays.asList(Enchantment.DENSITY, Enchantment.BREACH, Enchantment.SMITE, Enchantment.BANE_OF_ARTHROPODS));
                    enchantmentGroups.add(Arrays.asList(Enchantment.WIND_BURST));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                } else if (name.contains("SPEAR")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.SHARPNESS, Enchantment.SMITE, Enchantment.BANE_OF_ARTHROPODS));
                    enchantmentGroups.add(Arrays.asList(Enchantment.FIRE_ASPECT));
                    enchantmentGroups.add(Arrays.asList(Enchantment.KNOCKBACK));
                    enchantmentGroups.add(Arrays.asList(Enchantment.LOOTING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.LUNGE, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING));
                } else if (name.contains("SHIELD") || name.contains("ELYTRA")) {
                    enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                    enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
                }
            } else {
                enchantmentGroups.add(Arrays.asList(Enchantment.PROTECTION, Enchantment.FIRE_PROTECTION, Enchantment.BLAST_PROTECTION, Enchantment.PROJECTILE_PROTECTION));
                enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
                enchantmentGroups.add(Arrays.asList(Enchantment.THORNS));
                enchantmentGroups.add(Arrays.asList(Enchantment.VANISHING_CURSE));
            }
        } else {
            enchantmentGroups.add(Arrays.asList(Enchantment.EFFICIENCY));
            enchantmentGroups.add(Arrays.asList(Enchantment.FORTUNE, Enchantment.SILK_TOUCH));
            enchantmentGroups.add(Arrays.asList(Enchantment.UNBREAKING, Enchantment.MENDING));
        }

        if (!enchantmentGroups.isEmpty()) {
            Iterator var5 = enchantmentGroups.iterator();

            while(var5.hasNext()) {
                List<Enchantment> group = (List)var5.next();
                if (this.random.nextDouble() < 0.7) {
                    Enchantment chosen = (Enchantment)group.get(this.random.nextInt(group.size()));
                    int level = this.random.nextInt(chosen.getMaxLevel()) + 1;
                    item.addUnsafeEnchantment(chosen, level);
                }
            }

        }
    }

    private String getMaterialName(Material material) {
        String var10000;
        switch (material) {
            case DIAMOND_SWORD:
                var10000 = "钻石剑";
                break;
            case DIAMOND_AXE:
                var10000 = "钻石斧";
                break;
            case DIAMOND_PICKAXE:
                var10000 = "钻石镐";
                break;
            case DIAMOND_SHOVEL:
                var10000 = "钻石锹";
                break;
            case DIAMOND_HOE:
                var10000 = "钻石锄";
                break;
            case DIAMOND_HELMET:
                var10000 = "钻石头盔";
                break;
            case DIAMOND_CHESTPLATE:
                var10000 = "钻石胸甲";
                break;
            case DIAMOND_LEGGINGS:
                var10000 = "钻石护腿";
                break;
            case DIAMOND_BOOTS:
                var10000 = "钻石靴子";
                break;
            case NETHERITE_SWORD:
                var10000 = "下界合金剑";
                break;
            case NETHERITE_AXE:
                var10000 = "下界合金斧";
                break;
            case NETHERITE_PICKAXE:
                var10000 = "下界合金镐";
                break;
            case NETHERITE_SHOVEL:
                var10000 = "下界合金锹";
                break;
            case NETHERITE_HOE:
                var10000 = "下界合金锄";
                break;
            case NETHERITE_HELMET:
                var10000 = "下界合金头盔";
                break;
            case NETHERITE_CHESTPLATE:
                var10000 = "下界合金胸甲";
                break;
            case NETHERITE_LEGGINGS:
                var10000 = "下界合金护腿";
                break;
            case NETHERITE_BOOTS:
                var10000 = "下界合金靴子";
                break;
            default:
                var10000 = material.getKey().getKey();
        }

        return var10000;
    }

    private String getOreName(Material material) {
        PotionEffectType effect = (PotionEffectType)ORE_EFFECTS.get(material);
        if (effect == null) {
            return material.getKey().getKey();
        } else if (effect.equals(PotionEffectType.DOLPHINS_GRACE)) {
            return "§f煤";
        } else if (effect.equals(PotionEffectType.SPEED)) {
            return "§6铜";
        } else if (effect.equals(PotionEffectType.STRENGTH)) {
            return "§7铁";
        } else if (effect.equals(PotionEffectType.REGENERATION)) {
            return "§6金";
        } else if (effect.equals(PotionEffectType.HASTE)) {
            return "§c红石";
        } else if (effect.equals(PotionEffectType.WATER_BREATHING)) {
            return "§9青金石";
        } else if (effect.equals(PotionEffectType.RESISTANCE)) {
            return "§b钻石";
        } else if (effect.equals(PotionEffectType.FIRE_RESISTANCE)) {
            return "§f石英";
        } else {
            return effect.equals(PotionEffectType.HERO_OF_THE_VILLAGE) ? "§a绿宝石" : material.getKey().getKey();
        }
    }

    private static String getOreKey(Material material) {
        String var10000;
        switch (material) {
            case COAL:
            case COAL_BLOCK:
                var10000 = "coal";
                break;
            case COPPER_INGOT:
            case COPPER_BLOCK:
                var10000 = "copper";
                break;
            case IRON_INGOT:
            case IRON_BLOCK:
                var10000 = "iron";
                break;
            case GOLD_INGOT:
            case GOLD_BLOCK:
                var10000 = "gold";
                break;
            case REDSTONE:
            case REDSTONE_BLOCK:
                var10000 = "redstone";
                break;
            case LAPIS_LAZULI:
            case LAPIS_BLOCK:
                var10000 = "lapis";
                break;
            case DIAMOND:
            case DIAMOND_BLOCK:
                var10000 = "diamond";
                break;
            case QUARTZ:
            case QUARTZ_BLOCK:
                var10000 = "quartz";
                break;
            case EMERALD:
            case EMERALD_BLOCK:
                var10000 = "emerald";
                break;
            default:
                var10000 = "unknown";
        }

        return var10000;
    }

    private String getOreDisplayName(String oreKey) {
        String var10000;
        switch (oreKey) {
            case "coal":
                var10000 = "煤";
                break;
            case "copper":
                var10000 = "铜";
                break;
            case "iron":
                var10000 = "铁";
                break;
            case "gold":
                var10000 = "金";
                break;
            case "redstone":
                var10000 = "红石";
                break;
            case "lapis":
                var10000 = "青金石";
                break;
            case "diamond":
                var10000 = "钻石";
                break;
            case "quartz":
                var10000 = "石英";
                break;
            case "emerald":
                var10000 = "绿宝石";
                break;
            case "netherite":
                var10000 = "下界合金";
                break;
            default:
                var10000 = oreKey;
        }

        return var10000;
    }

    private String getFoodName(Material material) {
        String var10000;
        switch (material) {
            case APPLE:
                var10000 = "苹果";
                break;
            case GOLDEN_APPLE:
                var10000 = "金苹果";
                break;
            case ENCHANTED_GOLDEN_APPLE:
                var10000 = "附魔金苹果";
                break;
            case BEEF:
                var10000 = "生牛肉";
                break;
            case COOKED_BEEF:
                var10000 = "牛排";
                break;
            case PORKCHOP:
                var10000 = "生猪排";
                break;
            case COOKED_PORKCHOP:
                var10000 = "熟猪排";
                break;
            case CHICKEN:
                var10000 = "生鸡肉";
                break;
            case COOKED_CHICKEN:
                var10000 = "熟鸡肉";
                break;
            case COD:
                var10000 = "生鳕鱼";
                break;
            case COOKED_COD:
                var10000 = "熟鳕鱼";
                break;
            case SALMON:
                var10000 = "生鲑鱼";
                break;
            case COOKED_SALMON:
                var10000 = "熟鲑鱼";
                break;
            case MUTTON:
                var10000 = "生羊肉";
                break;
            case COOKED_MUTTON:
                var10000 = "熟羊肉";
                break;
            case RABBIT:
                var10000 = "生兔肉";
                break;
            case COOKED_RABBIT:
                var10000 = "熟兔肉";
                break;
            case POTATO:
                var10000 = "土豆";
                break;
            case BAKED_POTATO:
                var10000 = "烤土豆";
                break;
            case KELP:
                var10000 = "海带";
                break;
            case DRIED_KELP:
                var10000 = "干海带";
                break;
            default:
                var10000 = material.getKey().getKey();
        }

        return var10000;
    }

    private ItemStack[] generateMobDrops(EntityType type) {
        ItemStack[] var10000;
        switch (type) {
            case CREEPER:
                var10000 = new ItemStack[]{new ItemStack(Material.GUNPOWDER, 1 + this.random.nextInt(3))};
                break;
            case SKELETON:
                var10000 = new ItemStack[]{new ItemStack(Material.BONE, 1 + this.random.nextInt(3)), this.random.nextDouble() < 0.1 ? new ItemStack(Material.ARROW, 1 + this.random.nextInt(2)) : null};
                break;
            case SPIDER:
                var10000 = new ItemStack[]{new ItemStack(Material.STRING, 1 + this.random.nextInt(3)), this.random.nextDouble() < 0.33 ? new ItemStack(Material.SPIDER_EYE, 1) : null};
                break;
            case GIANT:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(5))};
                break;
            case ZOMBIE:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3)), this.random.nextDouble() < 0.1 ? new ItemStack(Material.IRON_INGOT, 1) : null, this.random.nextDouble() < 0.05 ? new ItemStack(Material.CARROT, 1) : null, this.random.nextDouble() < 0.05 ? new ItemStack(Material.POTATO, 1) : null};
                break;
            case SLIME:
                var10000 = new ItemStack[]{new ItemStack(Material.SLIME_BALL, 1 + this.random.nextInt(3))};
                break;
            case GHAST:
                var10000 = new ItemStack[]{new ItemStack(Material.GHAST_TEAR, 1), new ItemStack(Material.GUNPOWDER, 1 + this.random.nextInt(2))};
                break;
            case ENDERMAN:
                var10000 = new ItemStack[]{new ItemStack(Material.ENDER_PEARL, 1 + this.random.nextInt(2))};
                break;
            case CAVE_SPIDER:
                var10000 = new ItemStack[]{new ItemStack(Material.STRING, 1 + this.random.nextInt(3)), this.random.nextDouble() < 0.33 ? new ItemStack(Material.SPIDER_EYE, 1) : null};
                break;
            case SILVERFISH:
                var10000 = new ItemStack[]{new ItemStack(Material.AIR, 1)};
                break;
            case BLAZE:
                var10000 = new ItemStack[]{new ItemStack(Material.BLAZE_ROD, 1 + this.random.nextInt(2))};
                break;
            case MAGMA_CUBE:
                var10000 = new ItemStack[]{new ItemStack(Material.MAGMA_CREAM, 1 + this.random.nextInt(2))};
                break;
            case ENDERMITE:
                var10000 = new ItemStack[]{new ItemStack(Material.AIR, 1)};
                break;
            case GUARDIAN:
                var10000 = new ItemStack[]{new ItemStack(Material.PRISMARINE_SHARD, 1 + this.random.nextInt(3)), new ItemStack(Material.PRISMARINE_CRYSTALS, 1 + this.random.nextInt(2))};
                break;
            case ELDER_GUARDIAN:
                var10000 = new ItemStack[]{new ItemStack(Material.PRISMARINE_SHARD, 1 + this.random.nextInt(3)), new ItemStack(Material.PRISMARINE_CRYSTALS, 1 + this.random.nextInt(2)), new ItemStack(Material.WET_SPONGE, 1)};
                break;
            case WITHER_SKELETON:
                var10000 = new ItemStack[]{new ItemStack(Material.COAL, 1 + this.random.nextInt(2)), this.random.nextDouble() < 0.05 ? new ItemStack(Material.WITHER_SKELETON_SKULL, 1) : null};
                break;
            case STRAY:
                var10000 = new ItemStack[]{new ItemStack(Material.BONE, 1 + this.random.nextInt(3)), new ItemStack(Material.ARROW, 1 + this.random.nextInt(2))};
                break;
            case HUSK:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3))};
                break;
            case WITCH:
                var10000 = new ItemStack[]{new ItemStack(Material.GLOWSTONE_DUST, 1 + this.random.nextInt(2)), new ItemStack(Material.REDSTONE, 1 + this.random.nextInt(2)), new ItemStack(Material.STICK, 1 + this.random.nextInt(2))};
                break;
            case SHULKER:
                var10000 = new ItemStack[]{new ItemStack(Material.SHULKER_SHELL, this.random.nextDouble() < 0.5 ? 1 : 0)};
                break;
            case PHANTOM:
                var10000 = new ItemStack[]{new ItemStack(Material.PHANTOM_MEMBRANE, 1 + this.random.nextInt(2))};
                break;
            case DROWNED:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3)), this.random.nextDouble() < 0.1 ? new ItemStack(Material.COPPER_INGOT, 1) : null};
                break;
            case EVOKER:
                var10000 = new ItemStack[]{new ItemStack(Material.EMERALD, 1 + this.random.nextInt(2)), new ItemStack(Material.TOTEM_OF_UNDYING, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case VEX:
                var10000 = new ItemStack[]{new ItemStack(Material.IRON_SWORD, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case VINDICATOR:
                var10000 = new ItemStack[]{new ItemStack(Material.IRON_AXE, this.random.nextDouble() < 0.1 ? 1 : 0), new ItemStack(Material.EMERALD, this.random.nextDouble() < 0.2 ? 1 : 0)};
                break;
            case ILLUSIONER:
                var10000 = new ItemStack[]{new ItemStack(Material.BOW, 1)};
                break;
            case RAVAGER:
                var10000 = new ItemStack[]{new ItemStack(Material.SADDLE, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case PIGLIN:
                var10000 = new ItemStack[]{new ItemStack(Material.GOLD_NUGGET, 1 + this.random.nextInt(5)), this.random.nextDouble() < 0.1 ? new ItemStack(Material.GOLD_INGOT, 1) : null};
                break;
            case ZOMBIFIED_PIGLIN:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3)), new ItemStack(Material.GOLD_NUGGET, 1 + this.random.nextInt(5))};
                break;
            case HOGLIN:
                var10000 = new ItemStack[]{new ItemStack(Material.PORKCHOP, 1 + this.random.nextInt(4)), new ItemStack(Material.LEATHER, 1 + this.random.nextInt(3))};
                break;
            case PIGLIN_BRUTE:
                var10000 = new ItemStack[]{new ItemStack(Material.GOLD_NUGGET, 1 + this.random.nextInt(5)), new ItemStack(Material.GOLDEN_AXE, this.random.nextDouble() < 0.05 ? 1 : 0)};
                break;
            case ZOMBIE_VILLAGER:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3))};
                break;
            case ZOGLIN:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(4))};
                break;
            case CHICKEN:
                var10000 = new ItemStack[]{new ItemStack(Material.CHICKEN, 1 + this.random.nextInt(2)), new ItemStack(Material.FEATHER, 1 + this.random.nextInt(2))};
                break;
            case COW:
                var10000 = new ItemStack[]{new ItemStack(Material.BEEF, 1 + this.random.nextInt(3)), new ItemStack(Material.LEATHER, 1 + this.random.nextInt(2))};
                break;
            case PIG:
                var10000 = new ItemStack[]{new ItemStack(Material.PORKCHOP, 1 + this.random.nextInt(3))};
                break;
            case SHEEP:
                var10000 = new ItemStack[]{new ItemStack(Material.MUTTON, 1 + this.random.nextInt(2)), new ItemStack(Material.WHITE_WOOL, 1 + this.random.nextInt(2))};
                break;
            case RABBIT:
                var10000 = new ItemStack[]{new ItemStack(Material.RABBIT, 1), new ItemStack(Material.RABBIT_HIDE, 1), new ItemStack(Material.RABBIT_FOOT, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case MOOSHROOM:
                var10000 = new ItemStack[]{new ItemStack(Material.BEEF, 1 + this.random.nextInt(3)), new ItemStack(Material.LEATHER, 1 + this.random.nextInt(2)), new ItemStack(Material.RED_MUSHROOM, 1 + this.random.nextInt(2))};
                break;
            case GOAT:
                var10000 = new ItemStack[]{new ItemStack(Material.MUTTON, 1 + this.random.nextInt(2))};
                break;
            case POLAR_BEAR:
                var10000 = new ItemStack[]{new ItemStack(Material.COD, 1 + this.random.nextInt(3)), new ItemStack(Material.SALMON, 1 + this.random.nextInt(2))};
                break;
            case WOLF:
                var10000 = new ItemStack[]{new ItemStack(Material.BONE, 1 + this.random.nextInt(2))};
                break;
            case FOX:
                var10000 = new ItemStack[]{new ItemStack(Material.SWEET_BERRIES, 1 + this.random.nextInt(3)), new ItemStack(Material.FEATHER, 1)};
                break;
            case BEE:
                var10000 = new ItemStack[]{new ItemStack(Material.HONEYCOMB, 1 + this.random.nextInt(2))};
                break;
            case PANDA:
                var10000 = new ItemStack[]{new ItemStack(Material.BAMBOO, 1 + this.random.nextInt(3))};
                break;
            case TURTLE:
                var10000 = new ItemStack[]{new ItemStack(Material.SEAGRASS, 1 + this.random.nextInt(2)), new ItemStack(Material.TURTLE_SCUTE, this.random.nextDouble() < 0.2 ? 1 : 0)};
                break;
            case DOLPHIN:
                var10000 = new ItemStack[]{new ItemStack(Material.COD, 1 + this.random.nextInt(3))};
                break;
            case SQUID:
            case GLOW_SQUID:
                var10000 = new ItemStack[]{new ItemStack(Material.INK_SAC, 1 + this.random.nextInt(3))};
                break;
            case STRIDER:
                var10000 = new ItemStack[]{new ItemStack(Material.STRING, 1 + this.random.nextInt(2))};
                break;
            case LLAMA:
            case TRADER_LLAMA:
                var10000 = new ItemStack[]{new ItemStack(Material.LEATHER, 1 + this.random.nextInt(2))};
                break;
            case HORSE:
            case DONKEY:
            case MULE:
                var10000 = new ItemStack[]{new ItemStack(Material.LEATHER, 1 + this.random.nextInt(3))};
                break;
            case CAT:
                var10000 = new ItemStack[]{new ItemStack(Material.STRING, 1 + this.random.nextInt(2))};
                break;
            case PARROT:
                var10000 = new ItemStack[]{new ItemStack(Material.FEATHER, 1 + this.random.nextInt(2))};
                break;
            case OCELOT:
                var10000 = new ItemStack[]{new ItemStack(Material.COCOA_BEANS, 1 + this.random.nextInt(2))};
                break;
            case ALLAY:
                var10000 = new ItemStack[]{new ItemStack(Material.AMETHYST_SHARD, 1 + this.random.nextInt(2))};
                break;
            case ARMADILLO:
                var10000 = new ItemStack[]{new ItemStack(Material.ARMADILLO_SCUTE, 1 + this.random.nextInt(2))};
                break;
            case AXOLOTL:
                var10000 = new ItemStack[]{new ItemStack(Material.TROPICAL_FISH, 1 + this.random.nextInt(2))};
                break;
            case BAT:
                var10000 = new ItemStack[]{new ItemStack(Material.AIR, 1)};
                break;
            case BOGGED:
                var10000 = new ItemStack[]{new ItemStack(Material.BONE, 1 + this.random.nextInt(3)), new ItemStack(Material.ARROW, 1 + this.random.nextInt(2)), new ItemStack(Material.TIPPED_ARROW, this.random.nextDouble() < 0.3 ? 1 : 0)};
                break;
            case BREEZE:
                var10000 = new ItemStack[]{new ItemStack(Material.BREEZE_ROD, 1 + this.random.nextInt(2))};
                break;
            case CAMEL:
                var10000 = new ItemStack[]{new ItemStack(Material.SADDLE, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case COD:
                var10000 = new ItemStack[]{new ItemStack(Material.COD, 1 + this.random.nextInt(3))};
                break;
            case FROG:
                var10000 = new ItemStack[]{new ItemStack(Material.SLIME_BALL, 1 + this.random.nextInt(2))};
                break;
            case IRON_GOLEM:
                var10000 = new ItemStack[]{new ItemStack(Material.IRON_INGOT, 1 + this.random.nextInt(5)), new ItemStack(Material.POPPY, this.random.nextDouble() < 0.5 ? 1 : 0)};
                break;
            case PILLAGER:
                var10000 = new ItemStack[]{new ItemStack(Material.CROSSBOW, this.random.nextDouble() < 0.1 ? 1 : 0), new ItemStack(Material.EMERALD, this.random.nextDouble() < 0.2 ? 1 : 0)};
                break;
            case PUFFERFISH:
                var10000 = new ItemStack[]{new ItemStack(Material.PUFFERFISH, 1 + this.random.nextInt(2))};
                break;
            case SALMON:
                var10000 = new ItemStack[]{new ItemStack(Material.SALMON, 1 + this.random.nextInt(3))};
                break;
            case SKELETON_HORSE:
                var10000 = new ItemStack[]{new ItemStack(Material.BONE, 1 + this.random.nextInt(3))};
                break;
            case SNIFFER:
                var10000 = new ItemStack[]{new ItemStack(Material.SNIFFER_EGG, this.random.nextDouble() < 0.1 ? 1 : 0)};
                break;
            case SNOW_GOLEM:
                var10000 = new ItemStack[]{new ItemStack(Material.SNOWBALL, 1 + this.random.nextInt(8))};
                break;
            case TADPOLE:
                var10000 = new ItemStack[]{new ItemStack(Material.AIR, 1)};
                break;
            case TROPICAL_FISH:
                var10000 = new ItemStack[]{new ItemStack(Material.TROPICAL_FISH, 1 + this.random.nextInt(2))};
                break;
            case VILLAGER:
                var10000 = new ItemStack[]{new ItemStack(Material.EMERALD, 1 + this.random.nextInt(3))};
                break;
            case WANDERING_TRADER:
                var10000 = new ItemStack[]{new ItemStack(Material.EMERALD, 1 + this.random.nextInt(2))};
                break;
            case WARDEN:
                var10000 = new ItemStack[]{new ItemStack(Material.SCULK_CATALYST, 1)};
                break;
            case WITHER:
                var10000 = new ItemStack[]{new ItemStack(Material.NETHER_STAR, this.random.nextDouble() < 0.5 ? 1 : 0)};
                break;
            case ZOMBIE_HORSE:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1 + this.random.nextInt(3))};
                break;
            default:
                var10000 = new ItemStack[]{new ItemStack(Material.ROTTEN_FLESH, 1)};
        }

        return var10000;
    }

    private String getChineseMobName(EntityType type) {
        String var10000;
        switch (type) {
            case CREEPER:
                var10000 = "爬行者";
                break;
            case SKELETON:
                var10000 = "骷髅";
                break;
            case SPIDER:
                var10000 = "蜘蛛";
                break;
            case GIANT:
            case ILLUSIONER:
            default:
                var10000 = type.name();
                break;
            case ZOMBIE:
                var10000 = "僵尸";
                break;
            case SLIME:
                var10000 = "史莱姆";
                break;
            case GHAST:
                var10000 = "恶魂";
                break;
            case ENDERMAN:
                var10000 = "末影人";
                break;
            case CAVE_SPIDER:
                var10000 = "洞穴蜘蛛";
                break;
            case SILVERFISH:
                var10000 = "蠹虫";
                break;
            case BLAZE:
                var10000 = "烈焰人";
                break;
            case MAGMA_CUBE:
                var10000 = "岩浆怪";
                break;
            case ENDERMITE:
                var10000 = "末影螨";
                break;
            case GUARDIAN:
                var10000 = "守卫者";
                break;
            case ELDER_GUARDIAN:
                var10000 = "远古守卫者";
                break;
            case WITHER_SKELETON:
                var10000 = "凋零骷髅";
                break;
            case STRAY:
                var10000 = "流浪者";
                break;
            case HUSK:
                var10000 = "尸壳";
                break;
            case WITCH:
                var10000 = "女巫";
                break;
            case SHULKER:
                var10000 = "潜影贝";
                break;
            case PHANTOM:
                var10000 = "幻翼";
                break;
            case DROWNED:
                var10000 = "溺尸";
                break;
            case EVOKER:
                var10000 = "唤魔者";
                break;
            case VEX:
                var10000 = "恼鬼";
                break;
            case VINDICATOR:
                var10000 = "卫道士";
                break;
            case RAVAGER:
                var10000 = "劫掠兽";
                break;
            case PIGLIN:
                var10000 = "猪灵";
                break;
            case ZOMBIFIED_PIGLIN:
                var10000 = "僵尸猪灵";
                break;
            case HOGLIN:
                var10000 = "疣猪兽";
                break;
            case PIGLIN_BRUTE:
                var10000 = "猪灵蛮兵";
                break;
            case ZOMBIE_VILLAGER:
                var10000 = "僵尸村民";
                break;
            case ZOGLIN:
                var10000 = "僵尸疣猪兽";
        }

        return var10000;
    }

    private String getChineseEnchantName(Enchantment enchantment) {
        String var10000;
        switch (enchantment.getKey().getKey()) {
            case "protection":
                var10000 = "保护";
                break;
            case "fire_protection":
                var10000 = "火焰保护";
                break;
            case "feather_falling":
                var10000 = "摔落保护";
                break;
            case "blast_protection":
                var10000 = "爆炸保护";
                break;
            case "projectile_protection":
                var10000 = "弹射物保护";
                break;
            case "respiration":
                var10000 = "水下呼吸";
                break;
            case "aqua_affinity":
                var10000 = "水下速掘";
                break;
            case "thorns":
                var10000 = "荆棘";
                break;
            case "depth_strider":
                var10000 = "深海探索者";
                break;
            case "frost_walker":
                var10000 = "冰霜行者";
                break;
            case "binding_curse":
                var10000 = "绑定诅咒";
                break;
            case "sharpness":
                var10000 = "锋利";
                break;
            case "smite":
                var10000 = "亡灵杀手";
                break;
            case "bane_of_arthropods":
                var10000 = "节肢杀手";
                break;
            case "knockback":
                var10000 = "击退";
                break;
            case "fire_aspect":
                var10000 = "火焰附加";
                break;
            case "looting":
                var10000 = "抢夺";
                break;
            case "sweeping_edge":
                var10000 = "横扫之刃";
                break;
            case "efficiency":
                var10000 = "效率";
                break;
            case "silk_touch":
                var10000 = "精准采集";
                break;
            case "unbreaking":
                var10000 = "耐久";
                break;
            case "fortune":
                var10000 = "时运";
                break;
            case "power":
                var10000 = "力量";
                break;
            case "punch":
                var10000 = "冲击";
                break;
            case "flame":
                var10000 = "火焰";
                break;
            case "infinity":
                var10000 = "无限";
                break;
            case "luck_of_the_sea":
                var10000 = "海之眷顾";
                break;
            case "lure":
                var10000 = "饵钓";
                break;
            case "loyalty":
                var10000 = "忠诚";
                break;
            case "impaling":
                var10000 = "穿刺";
                break;
            case "riptide":
                var10000 = "激流";
                break;
            case "channeling":
                var10000 = "引雷";
                break;
            case "mending":
                var10000 = "经验修补";
                break;
            case "vanishing_curse":
                var10000 = "消失诅咒";
                break;
            case "multishot":
                var10000 = "多重射击";
                break;
            case "quick_charge":
                var10000 = "快速装填";
                break;
            case "piercing":
                var10000 = "穿透";
                break;
            case "density":
                var10000 = "致密";
                break;
            case "breach":
                var10000 = "破甲";
                break;
            case "wind_burst":
                var10000 = "风爆";
                break;
            default:
                var10000 = enchantment.getKey().getKey();
        }

        return var10000;
    }

    private String getBuffEffectName(PotionEffectType effect) {
        if (effect.equals(PotionEffectType.SPEED)) {
            return "速度";
        } else if (effect.equals(PotionEffectType.HASTE)) {
            return "急迫";
        } else if (effect.equals(PotionEffectType.STRENGTH)) {
            return "力量";
        } else if (effect.equals(PotionEffectType.JUMP_BOOST)) {
            return "跳跃提升";
        } else if (effect.equals(PotionEffectType.REGENERATION)) {
            return "生命恢复";
        } else if (effect.equals(PotionEffectType.RESISTANCE)) {
            return "抗性";
        } else if (effect.equals(PotionEffectType.FIRE_RESISTANCE)) {
            return "抗火";
        } else if (effect.equals(PotionEffectType.WATER_BREATHING)) {
            return "水下呼吸";
        } else if (effect.equals(PotionEffectType.INVISIBILITY)) {
            return "隐身";
        } else if (effect.equals(PotionEffectType.NIGHT_VISION)) {
            return "夜视";
        } else if (effect.equals(PotionEffectType.ABSORPTION)) {
            return "伤害吸收";
        } else if (effect.equals(PotionEffectType.HEALTH_BOOST)) {
            return "生命提升";
        } else if (effect.equals(PotionEffectType.SATURATION)) {
            return "饱和";
        } else if (effect.equals(PotionEffectType.CONDUIT_POWER)) {
            return "潮涌能量";
        } else if (effect.equals(PotionEffectType.DOLPHINS_GRACE)) {
            return "海豚的恩惠";
        } else {
            return effect.equals(PotionEffectType.LUCK) ? "幸运" : effect.getKey().getKey();
        }
    }

    private String toRoman(int n) {
        String var10000;
        switch (n) {
            case 1:
                var10000 = "I";
                break;
            case 2:
                var10000 = "II";
                break;
            case 3:
                var10000 = "III";
                break;
            case 4:
                var10000 = "IV";
                break;
            case 5:
                var10000 = "V";
                break;
            case 6:
                var10000 = "VI";
                break;
            case 7:
                var10000 = "VII";
                break;
            case 8:
                var10000 = "VIII";
                break;
            case 9:
                var10000 = "IX";
                break;
            case 10:
                var10000 = "X";
                break;
            default:
                var10000 = String.valueOf(n);
        }

        return var10000;
    }

    static {
        UNDEAD_TYPES = Set.of(EntityType.ZOMBIE, EntityType.HUSK, EntityType.DROWNED, EntityType.ZOMBIE_VILLAGER, EntityType.ZOMBIFIED_PIGLIN, EntityType.SKELETON, EntityType.WITHER_SKELETON, EntityType.STRAY, EntityType.WITHER, EntityType.PHANTOM, EntityType.SKELETON_HORSE, EntityType.ZOMBIE_HORSE, EntityType.ZOGLIN);
        FRIENDLY_MOBS = Map.of(AbilityType.NECROMANCER, UNDEAD_TYPES, AbilityType.WITHER_KIN, Set.of(EntityType.WITHER, EntityType.WITHER_SKELETON), AbilityType.DEMON_SUMMONER, Set.of(EntityType.EVOKER, EntityType.VEX), AbilityType.WITCH_KIN, Set.of(EntityType.WITCH));
        ORE_EFFECTS = new HashMap();
        ORE_KEYS = new HashMap();
        FOOD_BUFF_EFFECTS = List.of(PotionEffectType.SPEED, PotionEffectType.HASTE, PotionEffectType.STRENGTH, PotionEffectType.JUMP_BOOST, PotionEffectType.REGENERATION, PotionEffectType.RESISTANCE, PotionEffectType.FIRE_RESISTANCE, PotionEffectType.WATER_BREATHING, PotionEffectType.INVISIBILITY, PotionEffectType.NIGHT_VISION, PotionEffectType.ABSORPTION, PotionEffectType.HEALTH_BOOST, PotionEffectType.SATURATION, PotionEffectType.CONDUIT_POWER, PotionEffectType.DOLPHINS_GRACE, PotionEffectType.LUCK);
        SMALL_ANIMALS = Set.of(EntityType.CHICKEN, EntityType.PIG, EntityType.COW, EntityType.RABBIT, EntityType.SHEEP, EntityType.MOOSHROOM, EntityType.GOAT, EntityType.TURTLE, EntityType.DONKEY, EntityType.MULE, EntityType.SNOW_GOLEM);
        ANIMAL_FOOD_MAP = Map.ofEntries(Map.entry(EntityType.CHICKEN, Material.COOKED_CHICKEN), Map.entry(EntityType.PIG, Material.COOKED_PORKCHOP), Map.entry(EntityType.COW, Material.COOKED_BEEF), Map.entry(EntityType.RABBIT, Material.COOKED_RABBIT), Map.entry(EntityType.SHEEP, Material.COOKED_MUTTON), Map.entry(EntityType.MOOSHROOM, Material.COOKED_BEEF), Map.entry(EntityType.GOAT, Material.COOKED_MUTTON), Map.entry(EntityType.TURTLE, Material.COOKED_COD), Map.entry(EntityType.DONKEY, Material.COOKED_BEEF), Map.entry(EntityType.MULE, Material.COOKED_BEEF), Map.entry(EntityType.SNOW_GOLEM, Material.SNOWBALL));
        swallowedByTaotie = new HashMap();
        FOOD_UPGRADES = Map.ofEntries(Map.entry(Material.APPLE, Material.ENCHANTED_GOLDEN_APPLE), Map.entry(Material.GOLDEN_APPLE, Material.ENCHANTED_GOLDEN_APPLE), Map.entry(Material.BEEF, Material.COOKED_BEEF), Map.entry(Material.PORKCHOP, Material.COOKED_PORKCHOP), Map.entry(Material.CHICKEN, Material.COOKED_CHICKEN), Map.entry(Material.COD, Material.COOKED_COD), Map.entry(Material.SALMON, Material.COOKED_SALMON), Map.entry(Material.MUTTON, Material.COOKED_MUTTON), Map.entry(Material.RABBIT, Material.COOKED_RABBIT), Map.entry(Material.POTATO, Material.BAKED_POTATO), Map.entry(Material.KELP, Material.DRIED_KELP));
        HOT_BIOME_GROUND = Set.of(Material.SAND, Material.RED_SAND, Material.SANDSTONE, Material.RED_SANDSTONE, Material.NETHERRACK, Material.SOUL_SAND, Material.SOUL_SOIL, Material.CRIMSON_NYLIUM, Material.WARPED_NYLIUM);
        List<TreeType> treeList = new ArrayList(Arrays.asList(TreeType.TREE, TreeType.BIG_TREE, TreeType.BIRCH, TreeType.REDWOOD, TreeType.JUNGLE, TreeType.SMALL_JUNGLE, TreeType.ACACIA, TreeType.DARK_OAK, TreeType.MEGA_REDWOOD, TreeType.TALL_BIRCH, TreeType.SWAMP, TreeType.CHERRY));

        try {
            TreeType paleOak = TreeType.valueOf("PALE_OAK");
            treeList.add(paleOak);
        } catch (IllegalArgumentException var2) {
        }

        RANDOM_TREES = (TreeType[])treeList.toArray(new TreeType[0]);
        ORE_EFFECTS.put(Material.COAL, PotionEffectType.DOLPHINS_GRACE);
        ORE_EFFECTS.put(Material.COPPER_INGOT, PotionEffectType.SPEED);
        ORE_EFFECTS.put(Material.IRON_INGOT, PotionEffectType.STRENGTH);
        ORE_EFFECTS.put(Material.GOLD_INGOT, PotionEffectType.REGENERATION);
        ORE_EFFECTS.put(Material.REDSTONE, PotionEffectType.HASTE);
        ORE_EFFECTS.put(Material.LAPIS_LAZULI, PotionEffectType.WATER_BREATHING);
        ORE_EFFECTS.put(Material.DIAMOND, PotionEffectType.RESISTANCE);
        ORE_EFFECTS.put(Material.QUARTZ, PotionEffectType.FIRE_RESISTANCE);
        ORE_EFFECTS.put(Material.EMERALD, PotionEffectType.HERO_OF_THE_VILLAGE);
        ORE_EFFECTS.put(Material.COAL_BLOCK, PotionEffectType.DOLPHINS_GRACE);
        ORE_EFFECTS.put(Material.COPPER_BLOCK, PotionEffectType.SPEED);
        ORE_EFFECTS.put(Material.IRON_BLOCK, PotionEffectType.STRENGTH);
        ORE_EFFECTS.put(Material.GOLD_BLOCK, PotionEffectType.REGENERATION);
        ORE_EFFECTS.put(Material.REDSTONE_BLOCK, PotionEffectType.HASTE);
        ORE_EFFECTS.put(Material.LAPIS_BLOCK, PotionEffectType.WATER_BREATHING);
        ORE_EFFECTS.put(Material.DIAMOND_BLOCK, PotionEffectType.RESISTANCE);
        ORE_EFFECTS.put(Material.QUARTZ_BLOCK, PotionEffectType.FIRE_RESISTANCE);
        ORE_EFFECTS.put(Material.EMERALD_BLOCK, PotionEffectType.HERO_OF_THE_VILLAGE);
        Iterator var3 = ORE_EFFECTS.keySet().iterator();

        while(var3.hasNext()) {
            Material mat = (Material)var3.next();
            ORE_KEYS.put(mat, getOreKey(mat));
        }

    }
    
    private void trackCitizenCrime(UUID criminal, String type, int jailSeconds) {
        long now = System.currentTimeMillis();
        citizenCrimes.computeIfAbsent(criminal, k -> new ArrayList<>()).add(new CitizenCrime(now, type, jailSeconds));
    }

    private String getCitizenCrimeMessage(String type) {
        switch (type) {
            case "hunt": return "§c法治社会你居然非法狩猎，报警了！";
            case "chop_tree": return "§c法治社会你居然滥伐林木，报警了！";
            case "mine": return "§c法治社会你居然非法采矿，报警了！";
            case "build": return "§c法治社会你居然违规建筑，报警了！";
            case "explode": return "§c法治社会你居然非法爆破，报警了！";
            case "arson": return "§c法治社会你居然放火，报警了！";
            case "hit": return "§c法治社会你居然打人，报警了！";
            case "kill": return "§c法治社会你敢杀人，进监狱反省吧你！";
            default: return "§c法治社会你犯罪了,警察已抓你!";
        }
    }

    private static class CitizenCrime {
        long time;
        String type;
        int jailSeconds;

        CitizenCrime(long time, String type, int jailSeconds) {
            this.time = time;
            this.type = type;
            this.jailSeconds = jailSeconds;
        }
    }

    private boolean isSameBattleTeam(Player p1, Player p2) {
        for (String tag : p1.getScoreboardTags()) {
            if (tag.startsWith("battle_team_") && p2.getScoreboardTags().contains(tag)) {
                return true;
            }
        }
        return false;
    }
}
