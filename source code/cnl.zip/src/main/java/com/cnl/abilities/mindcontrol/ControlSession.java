

package com.cnl.abilities.mindcontrol;

import java.util.UUID;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.scheduler.BukkitTask;

public class ControlSession {
    private final UUID controllerId;
    private final UUID targetId;
    private final String targetName;
    private PlayerStateSnapshot controllerSnapshot;
    private PlayerStateSnapshot targetSnapshot;
    private boolean inventoryOpen;
    private Inventory inventoryGui;
    private BukkitTask syncTask;
    private BukkitTask releaseTask;
    private boolean active;

    public ControlSession(Player controller, Player target) {
        this.controllerId = controller.getUniqueId();
        this.targetId = target.getUniqueId();
        this.targetName = target.getName();
        this.active = true;
        this.inventoryOpen = false;
    }

    public UUID getControllerId() {
        return this.controllerId;
    }

    public UUID getTargetId() {
        return this.targetId;
    }

    public String getTargetName() {
        return this.targetName;
    }

    public boolean isActive() {
        return this.active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public PlayerStateSnapshot getControllerSnapshot() {
        return this.controllerSnapshot;
    }

    public void setControllerSnapshot(PlayerStateSnapshot snapshot) {
        this.controllerSnapshot = snapshot;
    }

    public PlayerStateSnapshot getTargetSnapshot() {
        return this.targetSnapshot;
    }

    public void setTargetSnapshot(PlayerStateSnapshot snapshot) {
        this.targetSnapshot = snapshot;
    }

    public boolean isInventoryOpen() {
        return this.inventoryOpen;
    }

    public void setInventoryOpen(boolean open) {
        this.inventoryOpen = open;
    }

    public Inventory getInventoryGui() {
        return this.inventoryGui;
    }

    public void setInventoryGui(Inventory inv) {
        this.inventoryGui = inv;
    }

    public BukkitTask getSyncTask() {
        return this.syncTask;
    }

    public void setSyncTask(BukkitTask task) {
        this.syncTask = task;
    }

    public BukkitTask getReleaseTask() {
        return this.releaseTask;
    }

    public void setReleaseTask(BukkitTask task) {
        this.releaseTask = task;
    }

    public void cancelSyncTask() {
        if (this.syncTask != null) {
            this.syncTask.cancel();
            this.syncTask = null;
        }

    }

    public void cancelReleaseTask() {
        if (this.releaseTask != null) {
            this.releaseTask.cancel();
            this.releaseTask = null;
        }

    }

    public void cancelAllTasks() {
        this.cancelSyncTask();
        this.cancelReleaseTask();
    }
}
