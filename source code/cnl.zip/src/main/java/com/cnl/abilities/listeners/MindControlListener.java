

package com.cnl.abilities.listeners;

import com.cnl.abilities.mindcontrol.MindControlManager;
import java.util.Iterator;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class MindControlListener implements Listener {
    public MindControlListener() {
    }

    @EventHandler
    public void onMindControlPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlling(player.getUniqueId())) {
                mm.releaseControl(player);
            } else if (mm.isControlled(player.getUniqueId())) {
                mm.releaseControlByTarget(player);
            }

        }
    }

    @EventHandler
    public void onMindControlPlayerChangedWorld(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            if (mm.isControlled(player.getUniqueId())) {
                mm.releaseControlByTarget(player);
            }

        }
    }

    @EventHandler
    public void onMindControlBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlBucketFill(PlayerBucketFillEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlPlayerFish(PlayerFishEvent event) {
        Player player = event.getPlayer();
        if (this.isControlledPlayer(player)) {
            event.setCancelled(true);
        }

    }

    @EventHandler
    public void onMindControlInventoryClick(InventoryClickEvent event) {
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    int slot = event.getRawSlot();
                    if (slot >= 5 && slot <= 8) {
                        event.setCancelled(true);
                    } else {
                        if (slot < 0) {
                            event.setCancelled(true);
                        }

                    }
                }
            }
        }
    }

    @EventHandler
    public void onMindControlInventoryDrag(InventoryDragEvent event) {
        HumanEntity var3 = event.getWhoClicked();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    Iterator var4 = event.getRawSlots().iterator();

                    int slot;
                    do {
                        if (!var4.hasNext()) {
                            return;
                        }

                        slot = (Integer)var4.next();
                        if (slot >= 5 && slot <= 8) {
                            event.setCancelled(true);
                            return;
                        }
                    } while(slot >= 0);

                    event.setCancelled(true);
                }
            }
        }
    }

    @EventHandler
    public void onMindControlInventoryClose(InventoryCloseEvent event) {
        HumanEntity var3 = event.getPlayer();
        if (var3 instanceof Player player) {
            MindControlManager mm = MindControlManager.getInstance();
            if (mm != null) {
                if (mm.isInventoryOpen(player.getUniqueId())) {
                    mm.setInventoryClosed(player.getUniqueId());
                    Player target = mm.getTarget(player);
                    if (target != null && target.isOnline()) {
                        mm.syncInventoryToTarget(event.getInventory(), target);
                    }

                }
            }
        }
    }

    private boolean isControlledPlayer(Player player) {
        MindControlManager mm = MindControlManager.getInstance();
        return mm != null && mm.isControlled(player.getUniqueId());
    }
}
