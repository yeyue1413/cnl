
package com.cnl.abilities;

public enum AbilityType {
    NONE(0, "无", "没有超能力，为无超能力者状态"),
    FLASH(1, "闪电侠", "极快的移动速度，按技能键切换疾跑状态"),
    LUCKY(2, "气运之子", "挖掘方块和击杀生物会获得额外掉落物，每次受伤15%概率免除伤害"),
    POSEIDON(3, "海神", "进入水中获得力量IV、海豚恩惠IV和水下呼吸"),
    INVISIBLE(4, "隐形人", "持续隐身状态"),
    SUPERMAN(5, "小超人", "可以飞行，获得力量I和抗性II"),
    SUN_CHILD(6, "太阳之子", "白天获得力量III/抗性I/速度I/防火，夜晚虚弱缓慢"),
    BARBARIAN(7, "狂战士", "生命上限提升至32点，血量越低力量越强速度越快"),
    NECROMANCER(8, "亡灵法师", "攻击时呼唤周围亡灵围攻，亡灵生物无法伤害你"),
    HEX_MASTER(9, "蛊术师", "拥有一次替死保护，死亡时随机献祭其他玩家代替(每击杀3人恢复一次)"),
    HYDROPHOBIC(10, "深信水有剧毒的人", "永久生命恢复IV，但触水即死"),
    BLACKSMITH(11, "锻造师", "工作台制作顶级附魔装备，副手青金石右键随机附魔(每件限3次)"),
    RICH_MAN(12, "富豪", "初始获得12钻石块+2铁块+2金块+2绿宝石块，副手持钻石块右键消耗5个召唤一个铁傀儡保镖"),
    TAME_MASTER(13, "驯服大师", "驯服动物获得力量加成，每驯服2只提升1级力量"),
    AOE_ATTACK(14, "AOE者", "左键触发范围攻击，对周围5格内所有生物造成武器伤害"),
    TOTEM_BODY(15, "图腾之体", "主手持物品可当不死图腾使用(同物品仅一次)"),
    ORE_EATER(16, "食矿者", "副手持矿石右键可吃矿石获得效果(锭/块每1分钟冷却)"),
    DAMAGE_EXPLOSION(17, "爆炸人", "受到伤害时会爆炸"),
    SPIT_EXPLOSION(18, "射击者", "潜行左键发射，快速连射会惩罚"),
    SOUL_SUMMONER(19, "灵魂召唤师", "击杀怪物收集灵魂，技能键1查看灵魂，技能键2释放灵魂，技能键3释放全部，受伤3倍但由召唤生物承担"),
    DAMAGE_EFFECT(20, "自残者", "受伤时50%概率背包物品翻倍，50%概率获得buff"),
    FOOD_BUFF(21, "美食家", "每2分钟吃一次食物获得随机增益"),
    KILLER(22, "杀戮者", "击杀20只生物后解锁伤害加成(最高200)，前10只伤害降低为1/4"),
    ANT_MAN(23, "蚁人", "技能键变大(体型5倍+手长9格+抗性II)，技能键2缩小(生命1❤+攻击2❤真伤)"),
    RUBBER_MAN(24, "橡皮人", "手臂变长(触及+9)，免疫摔落伤害，火焰和锋利伤害翻倍"),
    QUANTUM_MAN(25, "量子人", "受到攻击40%概率进入旁观模式5秒"),
    FAIRY(26, "妖精", "可以飞行，体型变小，空手右键给予敌人debuff(30秒冷却)"),
    BIG_STOMACH(27, "饕餮", "永久饥饿和缓慢，空手右键吃方块，潜行右键吞噬生物或低血量玩家，饱食满获得力量II抗性II"),
    NATURE_CHILD(28, "自然之子", "技能键种树(1秒冷却)，站在特定方块上获得恢复效果"),
    FIRE_MAN(29, "火焰人", "走过的地方着火，近战带火焰附加，按技能键发射火焰弹(5秒冷却)，入水持续扣血"),
    ICE_MAN(30, "冰人", "水面结冰陆地留雪，按技能键发射冰冻雪球(5秒冷却)，炎热地方持续扣血"),
    ENDERLING(31, "末影族", "怕水，免疫远程/摔落伤害，受远程攻击50%概率瞬移，按技能键投掷末影珍珠(1秒冷却)"),
    SPIDER_MAN(32, "蜘蛛侠", "可爬墙，按技能键发射蛛网，技能键2发射蛛丝拉拽"),
    THIEF(33, "盗窃者", "潜行隐身，空手右键玩家偷物品/右键生物偷掉落，按技能键窃取生命或buff(30秒冷却)"),
    BOMBER(34, "炸弹人", "按技能键消耗背包3个物品发射炸弹雪球(3秒冷却)"),
    TIME_STOPPER(35, "时停者", "按技能键触发时停5秒，除你之外玩家和生物被冻结(冷却1分钟)"),
    RECALL(36, "回溯者", "技能键2记录位置，技能键回溯(冷却10秒)，自带一次替死传送回记录点"),
    MIND_CONTROL(37, "灵魂控制", "技能键控制10格内其他玩家(控制5秒,冷却60秒)，潜行技能键打开背包"),
    GOD_LEFT_HAND(38, "神之左手", "空手左键封印8格内目标玩家的超能力10秒(冷却10秒)"),
    FIELD_WEAVER(39, "立场编织者", "技能键创造15格直径立场区域，禁止飞行/跳跃/速度，持续10秒(冷却60秒)"),
    GUARDIAN(40, "守护者", "技能键给自己护盾(免疫3次伤害)，技能键2给队友护盾(4格距离)，持续消耗饱食度，冷却60秒"),
    SPARTAN(41, "斯巴达勇士", "技能键对前方4格目标造成3颗心伤害+巨额击退，击杀摔死的玩家获得30秒力量叠加，冷却60秒"),
    ROMAN_LEGION(42, "罗马军团", "潜行主手持盾右键展开防御阵型，左右后侧绝对防御并庇护3×3格队友，减速80%且不能跳跃，冷却60秒"),
    WITHER_KIN(43, "凋零族", "技能键发射凋零头颅(冷却5秒)，半血获得抗性I，可缓慢飞行"),
    DEMON_SUMMONER(44, "唤魔族", "技能键锁定前方生物释放单体地刺(冷却5秒，优先玩家>怪物>动物)，技能键2召唤恼鬼(冷却60秒，最多3只)"),
    LAWFUL_CITIZEN(45, "守法公民", "技能键送攻击者进监狱5秒(冷却50秒)，被击杀则击杀者进监狱20秒"),
    REFLECTOR(46, "镜反者", "技能键开启反射屏障(持续10秒)，反弹所有远程抛射物，近战攻击者受到50%反伤，冷却60秒"),
    ELF_RANGER(47, "精灵游侠", "技能键发射箭矢(冷却0.5秒)，箭矢击中生物获得10秒速度I，潜行技能键发射3支追踪箭(冷却15秒)"),
    WITCH_KIN(48, "女巫族", "技能键发射喷溅药水(随机负面效果5秒，冷却10秒)，潜行技能键自我生命恢复I(10秒，冷却30秒)"),
    GLASS_WALKER(49, "玻璃行者", "技能键在脚下持续生成3×3玻璃平台，持续10秒（冷却20秒）"),
    LIGHTNING_KING(50, "雷电法王", "技能键生成闪电（冷却5秒），技能键2生成5道闪电（冷却40秒）"),
    DIGGER(51, "淘矿者", "挖掘方块概率掉落矿物：铜15%，铁/金/青金石/红石各10%，钻石6%，下届合金锭+升级模板2%"),
    SENTINEL(52, "哨兵", "技能键2在目标位置召唤炮塔自动攻击敌人(冷却70秒)"),
    SUMMONER(53, "召集者", "技能键将同队队友传送至自己身边(冷却30秒)"),
    REDEEMER(54, "救赎者", "队友死亡获得其名字的纸，手持纸使用技能定身10秒后复活队友（冷却递增：3/5/7...分钟）"),
    DAMAGE_TELEPORT(100, "飞雷神", "受到伤害时免疫伤害并随机瞬移至附近最高点(冷却0.5秒)");

    private final int id;
    private final String displayName;
    private final String description;

    private AbilityType(int id, String displayName, String description) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
    }

    public int getId() {
        return this.id;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getDescription() {
        return this.description;
    }

    public String getDisplayId() {
        return this == DAMAGE_TELEPORT ? "s" : String.valueOf(this.id);
    }

    public static AbilityType fromString(String name) {
        try {
            return valueOf(name.toUpperCase());
        } catch (IllegalArgumentException var2) {
            return null;
        }
    }

    public static AbilityType fromId(int id) {
        AbilityType[] var1 = values();
        int var2 = var1.length;

        for(int var3 = 0; var3 < var2; ++var3) {
            AbilityType type = var1[var3];
            if (type.id == id) {
                return type;
            }
        }

        return null;
    }

    public static AbilityType fromDisplayId(String displayId) {
        if (displayId.equalsIgnoreCase("s")) {
            return DAMAGE_TELEPORT;
        } else {
            try {
                return fromId(Integer.parseInt(displayId));
            } catch (NumberFormatException var2) {
                return null;
            }
        }
    }
}
