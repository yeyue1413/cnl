package com.cnl.abilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class AbilityManager {
    private static final Map<UUID, AbilityType> playerAbilities = new HashMap();
    private static final Map<UUID, Boolean> activeSkills = new HashMap();
    private static final Map<UUID, Boolean> hexProtection = new HashMap();
    private static final Map<UUID, Integer> hexKillCount = new HashMap();
    private static final Map<UUID, Boolean> deathResetEnabled = new HashMap();
    private static final Map<UUID, List<UUID>> playerGolems = new HashMap();
    private static final Map<UUID, BukkitTask> golemFollowTasks = new HashMap();
    private static final Set<UUID> noCooldownPlayers = new HashSet();
    private static final Random random = new Random();
    private static boolean battleModeActive = false;
    private static final Map<UUID, Set<UUID>> richManTrackedTargets = new HashMap();
    private static final Map<UUID, Integer> richManDiamondCount = new HashMap();
    private static final Map<UUID, Integer> tameCounts = new HashMap();
    private static final Map<UUID, Integer> tameLevels = new HashMap();
    private static final Map<UUID, Set<Material>> usedTotemItems = new HashMap();
    private static final Map<UUID, Map<Material, Long>> oreCooldowns = new HashMap();
    private static final Map<UUID, Map<String, Integer>> oreBlockEatCounts = new HashMap();
    private static final Map<UUID, Map<String, Integer>> oreLevels = new HashMap();
    private static final Map<UUID, Map<EntityType, Integer>> playerSouls = new HashMap();
    private static NamespacedKey summonedKey;
    private static final Map<UUID, Long> lastFoodEatTime = new HashMap();
    private static final Map<UUID, Integer> killCounts = new HashMap();
    private static final Map<UUID, Double> killDamageBonuses = new HashMap();
    private static final double MAX_KILL_DAMAGE = 200.0;
    private static final int KILL_THRESHOLD = 20;
    private static final int REDUCTION_THRESHOLD = 10;
    private static final Map<UUID, Integer> antManState = new HashMap();
    private static final Map<UUID, Double> antManSavedHealth = new HashMap();
    private static final Map<UUID, Boolean> fireTrailEnabled = new HashMap();
    private static final Map<UUID, Boolean> iceWalkEnabled = new HashMap();
    private static final Map<UUID, Integer> guardianShields = new HashMap();
    private static final Map<UUID, Integer> guardianHungerTasks = new HashMap();
    private static final Map<UUID, Long> guardianCooldown = new HashMap();
    private static final Map<UUID, UUID> guardianGiver = new HashMap();
    private static final Map<UUID, UUID> guardianGivenTo = new HashMap();
    private static final Map<UUID, Long> spartanCooldown = new HashMap();
    private static final Map<UUID, Long> spartanCooldownDuration = new HashMap();
    private static final Map<UUID, Integer> spartanStrengthLevel = new HashMap();
    private static final Map<UUID, Long> spartanStrengthEndTime = new HashMap();
    private static final Map<UUID, Boolean> legionFormation = new HashMap();
    private static final Map<UUID, Integer> legionTaskId = new HashMap();
    private static final Map<UUID, Long> legionCooldown = new HashMap();
    private static final Map<UUID, Float> legionSavedSpeed = new HashMap();
    private static final Map<UUID, Long> witherSkillCooldown = new HashMap();
    private static final Map<UUID, Long> demonFangCooldown = new HashMap();
    private static final Map<UUID, Long> demonVexCooldown = new HashMap();
    private static final Map<UUID, Set<UUID>> demonVexUUIDs = new HashMap();
    private static final Map<UUID, BukkitTask> demonVexFollowTasks = new HashMap();
    private static final Map<UUID, Long> citizenCooldown = new HashMap();
    static final Map<UUID, List<PrisonBlock>> prisonBlocksMap = new HashMap();
    static final Map<UUID, Location> prisonOriginalLocation = new HashMap();
    static final Map<UUID, Integer> prisonTasks = new HashMap();
    private static final Map<UUID, Long> reflectorEndTime = new HashMap();
    private static final Map<UUID, Integer> reflectorParticleTask = new HashMap();
    private static final Map<UUID, Long> reflectorCooldown = new HashMap();
    private static final Map<UUID, Long> elfRangerCooldown = new HashMap();
    private static final Map<UUID, Long> witchKinCooldown = new HashMap();
    private static final Map<UUID, Long> witchRegenCooldown = new HashMap();
    private static final Map<UUID, Long> elfRangerTrackingCooldown = new HashMap();
    private static final Set<UUID> recallPassiveUsed = new HashSet();
    private static final Map<UUID, BukkitTask> glassWalkerTask = new HashMap();
    private static final Map<UUID, Long> lightningKingCooldown = new HashMap();
    private static final Map<UUID, Long> lightningKingMassCooldown = new HashMap();
    private static final Map<UUID, Long> sentinelCooldown = new HashMap();
    private static final Map<UUID, Set<UUID>> sentinelArmorStands = new HashMap();
    private static final Map<UUID, Set<BukkitTask>> sentinelTasks = new HashMap();
    private static final Map<UUID, Integer> sentinelHits = new HashMap();
    private static final Map<UUID, Long> summonerCooldown = new HashMap();
    private static final Map<UUID, Set<String>> redeemerPapers = new HashMap();
    private static final Map<UUID, Integer> redeemerUseCount = new HashMap();
    private static final Map<UUID, Long> redeemerCooldown = new HashMap();
    private static final Map<UUID, BukkitTask> redeemerTasks = new HashMap();
    private static final Map<UUID, Float> redeemerSavedSpeed = new HashMap();
    private static final Map<UUID, Long> quantumEndTime = new HashMap();
    private static final Map<UUID, Location> quantumReturnLocation = new HashMap();
    private static final Map<UUID, GameMode> quantumReturnGamemode = new HashMap();
    private static final Map<UUID, Double> quantumStoredDamage = new HashMap();
    private static final Set<UUID> quantumRestoringDamage = new HashSet();
    private static final Map<UUID, Long> fairyDebuffCooldown = new HashMap();
    private static final Map<UUID, Long> bigStomachEatCooldown = new HashMap();
    private static final Map<UUID, Long> bigStomachAnimalCooldown = new HashMap();
    private static final Map<UUID, Long> natureChildTreeCooldown = new HashMap();
    private static final Map<UUID, Long> bomberCooldown = new HashMap();
    private static final Map<UUID, Long> fireManSkillCooldown = new HashMap();
    private static final Map<UUID, Long> iceManSkillCooldown = new HashMap();
    private static final Map<UUID, Long> enderlingSkillCooldown = new HashMap();
    private static final Map<UUID, Long> spiderManWebCooldown = new HashMap();
    private static final Map<UUID, Long> spiderManPullCooldown = new HashMap();
    private static final Map<UUID, Long> thiefItemCooldown = new HashMap();
    private static final Map<UUID, Long> thiefLifeCooldown = new HashMap();
    private static final Map<UUID, PotionEffectType> thiefStolenBuff = new HashMap();
    private static final Map<UUID, Long> mindControlCooldown = new HashMap();
    private static final long MIND_CONTROL_COOLDOWN_MS = 60000L;
    private static final Map<UUID, Long> godsLeftHandCooldown = new HashMap();
    private static final Set<UUID> godsLeftHandDisabledPlayers = new HashSet();
    private static final Map<UUID, BukkitTask> godsLeftHandRestoreTasks = new HashMap();
    private static final long GODS_LEFT_HAND_DURATION_MS = 10000L;
    private static final long GODS_LEFT_HAND_COOLDOWN_MS = 10000L;
    private static final Map<UUID, FieldWeaverData> fieldWeaverActiveFields = new HashMap();
    private static final Map<UUID, Long> fieldWeaverCooldown = new HashMap();
    private static final long FIELD_WEAVER_DURATION_MS = 10000L;
    private static final long FIELD_WEAVER_COOLDOWN_MS = 60000L;
    private static final double FIELD_WEAVER_RADIUS = 7.5;
    private static final Set<UUID> fieldWeaverAffectedPlayers = new HashSet();
    private static final Map<UUID, Boolean> fieldWeaverPreFlight = new HashMap();
    private static final Map<UUID, Long> timeStopCooldowns = new HashMap();
    private static final Map<UUID, UUID> forcedKillers = new HashMap();
    private static boolean timeStopActive = false;
    private static UUID timeStopTriggerPlayer = null;
    private static BukkitTask timeStopRestoreTask = null;
    private static BukkitTask timeStopFreezeTask = null;
    private static final Map<UUID, EntityState> timeStopFrozenEntities = new HashMap();
    private static final Map<UUID, PlayerState> timeStopFrozenPlayers = new HashMap();
    private static final Map<UUID, AccumulatedDamage> timeStopAccumulatedDamage = new HashMap();
    private static final int TIME_STOP_DURATION = 5;
    private static final long TIME_STOP_COOLDOWN_MS = 60000L;
    private static final String PROTECT_TAG = "cnl_protected";
    private static Consumer<Player> onRedeemerReviveCallback = null;

    public static void setOnRedeemerReviveCallback(Consumer<Player> callback) {
        onRedeemerReviveCallback = callback;
    }

    public static void notifyRedeemerRevive(Player player) {
        if (onRedeemerReviveCallback != null) {
            onRedeemerReviveCallback.accept(player);
        }
    }

    public AbilityManager() {
    }

    public static boolean isBattleModeActive() {
        return battleModeActive;
    }

    public static void setBattleModeActive(boolean active) {
        battleModeActive = active;
    }

    public static boolean canMindControl(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long lastUse = (Long)mindControlCooldown.get(player.getUniqueId());
            if (lastUse != null) {
                long remaining = (lastUse + 60000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c灵魂控制冷却中! 剩余 §e" + remaining + " §c秒");
                    return false;
                }
            }

            return true;
        }
    }

    public static void setMindControlCooldown(Player player) {
        mindControlCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseTimeStop(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else if (timeStopActive) {
            if (player.getUniqueId().equals(timeStopTriggerPlayer)) {
                player.sendMessage("§c时停已经在进行中！");
            } else {
                player.sendMessage("§c当前世界已被暂停，无法触发时停！");
            }

            return false;
        } else {
            Long lastUse = (Long)timeStopCooldowns.get(player.getUniqueId());
            if (lastUse != null) {
                long remaining = (lastUse + 60000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c时停冷却中！剩余 §e" + remaining + " §c秒");
                    return false;
                }
            }

            return true;
        }
    }

    public static void setTimeStopCooldown(Player player) {
        timeStopCooldowns.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean isTimeStopActive() {
        return timeStopActive;
    }

    public static boolean isTimeStopTriggerPlayer(Player player) {
        return timeStopActive && player.getUniqueId().equals(timeStopTriggerPlayer);
    }

    public static boolean isFrozenPlayer(UUID playerUuid) {
        return timeStopActive && timeStopFrozenPlayers.containsKey(playerUuid);
    }

    public static void startTimeStop(Player trigger) {
        if (!timeStopActive) {
            timeStopActive = true;
            timeStopTriggerPlayer = trigger.getUniqueId();
            timeStopFrozenEntities.clear();
            timeStopFrozenPlayers.clear();
            timeStopAccumulatedDamage.clear();
            Iterator var1 = Bukkit.getWorlds().iterator();

            World world;
            while(var1.hasNext()) {
                world = (World)var1.next();
                world.setGameRule(GameRule.RANDOM_TICK_SPEED, 0);
            }

            trigger.sendMessage("§6⏳ §e你使用了时停！世界将暂停5秒！");
            var1 = Bukkit.getWorlds().iterator();

            while(var1.hasNext()) {
                world = (World)var1.next();
                Iterator var3 = world.getEntities().iterator();

                while(var3.hasNext()) {
                    Entity entity = (Entity)var3.next();
                    if (entity instanceof Player) {
                        Player player = (Player)entity;
                        if (!player.equals(trigger)) {
                            freezePlayer(player);
                        }
                    } else {
                        freezeEntity(entity);
                    }
                }
            }

            var1 = timeStopFrozenPlayers.entrySet().iterator();

            while(var1.hasNext()) {
                Map.Entry<UUID, PlayerState> entry = (Map.Entry)var1.next();
                Player p = Bukkit.getPlayer((UUID)entry.getKey());
                if (p != null && p.isOnline()) {
                    p.sendMessage("§c⏹ §4世界已被暂停！你将无法行动5秒...");
                }
            }

            startTimeStopFreezeTask();
            startTimeStopRestoreTask();
        }
    }

    public static void stopTimeStop() {
        if (timeStopActive) {
            timeStopActive = false;
            if (timeStopRestoreTask != null) {
                timeStopRestoreTask.cancel();
                timeStopRestoreTask = null;
            }

            if (timeStopFreezeTask != null) {
                timeStopFreezeTask.cancel();
                timeStopFreezeTask = null;
            }

            Iterator var0 = Bukkit.getWorlds().iterator();

            while(var0.hasNext()) {
                World world = (World)var0.next();
                world.setGameRule(GameRule.RANDOM_TICK_SPEED, 3);
            }

            restoreTimeStopPlayers();
            restoreTimeStopEntities();
            applyAccumulatedDamage();
            timeStopFrozenEntities.clear();
            timeStopFrozenPlayers.clear();
            timeStopAccumulatedDamage.clear();
            if (timeStopTriggerPlayer != null) {
                Player trigger = Bukkit.getPlayer(timeStopTriggerPlayer);
                if (trigger != null && trigger.isOnline()) {
                    trigger.sendMessage("§a✓ §b时停结束，世界恢复正常！");
                }
            }

            timeStopTriggerPlayer = null;
        }
    }

    private static void freezeEntity(Entity entity) {
        UUID uuid = entity.getUniqueId();
        EntityState state = new EntityState();
        state.location = entity.getLocation().clone();
        if (entity instanceof Mob mob) {
            state.hasAI = true;
            state.ai = mob.hasAI();
            mob.setAI(false);
        }

        if (entity instanceof LivingEntity living) {
            state.hasGravity = true;
            state.gravity = living.hasGravity();
            living.setGravity(false);
        }

        if (entity instanceof Projectile projectile) {
            state.isProjectile = true;
            state.originalVelocity = projectile.getVelocity().clone();
            projectile.setVelocity(new Vector(0, 0, 0));
            if (projectile instanceof AbstractArrow arrow) {
                arrow.setVelocity(new Vector(0, 0, 0));
            }

            timeStopFrozenEntities.put(uuid, state);
        } else if (entity instanceof Item item) {
            item.setPickupDelay(Integer.MAX_VALUE);
            state.location = entity.getLocation().clone();
            entity.setVelocity(new Vector(0, 0, 0));
            timeStopFrozenEntities.put(uuid, state);
        } else {
            entity.setVelocity(new Vector(0, 0, 0));
            timeStopFrozenEntities.put(uuid, state);
        }
    }

    private static void freezePlayer(Player player) {
        UUID uuid = player.getUniqueId();
        PlayerState state = new PlayerState();
        state.walkSpeed = player.getWalkSpeed();
        state.flySpeed = player.getFlySpeed();
        state.allowFlight = player.getAllowFlight();
        state.isFlying = player.isFlying();
        state.location = player.getLocation().clone();
        player.setWalkSpeed(0.0F);
        player.setFlySpeed(0.0F);
        player.setAllowFlight(true);
        player.setFlying(false);
        timeStopFrozenPlayers.put(uuid, state);
    }

    private static void restoreTimeStopEntities() {
        Iterator var0 = timeStopFrozenEntities.entrySet().iterator();

        while(var0.hasNext()) {
            Map.Entry<UUID, EntityState> entry = (Map.Entry)var0.next();
            Entity entity = Bukkit.getEntity((UUID)entry.getKey());
            if (entity != null) {
                EntityState state = (EntityState)entry.getValue();
                if (state.isProjectile && state.originalVelocity != null && entity instanceof Projectile) {
                    Projectile projectile = (Projectile)entity;
                    projectile.setVelocity(state.originalVelocity);
                }

                if (state.hasAI && entity instanceof Mob) {
                    Mob mob = (Mob)entity;
                    mob.setAI(state.ai);
                }

                if (state.hasGravity && entity instanceof LivingEntity) {
                    LivingEntity living = (LivingEntity)entity;
                    living.setGravity(state.gravity);
                }

                if (entity instanceof Item) {
                    Item item = (Item)entity;
                    item.setPickupDelay(0);
                }
            }
        }

    }

    private static void restoreTimeStopPlayers() {
        Iterator var0 = timeStopFrozenPlayers.entrySet().iterator();

        while(var0.hasNext()) {
            Map.Entry<UUID, PlayerState> entry = (Map.Entry)var0.next();
            Player player = Bukkit.getPlayer((UUID)entry.getKey());
            if (player != null && player.isOnline()) {
                PlayerState state = (PlayerState)entry.getValue();
                player.setWalkSpeed(state.walkSpeed);
                player.setFlySpeed(state.flySpeed);
                player.setAllowFlight(state.allowFlight);
                player.setFlying(state.isFlying);
            }
        }

    }

    private static void startTimeStopFreezeTask() {
        timeStopFreezeTask = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            if (timeStopActive) {
                Iterator var0 = timeStopFrozenEntities.entrySet().iterator();

                while(true) {
                    while(true) {
                        Map.Entry entry;
                        Entity entity;
                        do {
                            if (!var0.hasNext()) {
                                var0 = timeStopFrozenPlayers.entrySet().iterator();

                                while(var0.hasNext()) {
                                    entry = (Map.Entry)var0.next();
                                    Player player = Bukkit.getPlayer((UUID)entry.getKey());
                                    if (player != null && player.isOnline()) {
                                        player.setWalkSpeed(0.0F);
                                        player.setFlySpeed(0.0F);
                                        player.setVelocity(new Vector(0, 0, 0));
                                        player.teleport(((PlayerState)entry.getValue()).location);
                                    }
                                }

                                return;
                            }

                            entry = (Map.Entry)var0.next();
                            entity = Bukkit.getEntity((UUID)entry.getKey());
                        } while(entity == null);

                        EntityState state = (EntityState)entry.getValue();
                        if (state.isProjectile && entity instanceof Projectile) {
                            Projectile projectile = (Projectile)entity;
                            projectile.setVelocity(new Vector(0, 0, 0));
                            if (projectile instanceof AbstractArrow) {
                                AbstractArrow arrow = (AbstractArrow)projectile;
                                arrow.setVelocity(new Vector(0, 0, 0));
                            }

                            projectile.teleport(state.location);
                        } else if (entity instanceof Item) {
                            Item item = (Item)entity;
                            item.setPickupDelay(Integer.MAX_VALUE);
                            item.setVelocity(new Vector(0, 0, 0));
                            item.teleport(state.location);
                        } else {
                            entity.setVelocity(new Vector(0, 0, 0));
                            entity.teleport(state.location);
                            if (entity instanceof Mob) {
                                Mob mob = (Mob)entity;
                                mob.setAI(false);
                            }
                        }
                    }
                }
            }
        }, 0L, 1L);
    }

    private static void startTimeStopRestoreTask() {
        timeStopRestoreTask = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), new Runnable() {
            int secondsLeft = 5;

            public void run() {
                if (AbilityManager.timeStopTriggerPlayer != null) {
                    Player trigger = Bukkit.getPlayer(AbilityManager.timeStopTriggerPlayer);
                    if (trigger != null && trigger.isOnline()) {
                        trigger.sendActionBar("§e⏱ §7时停倒计时 §f" + this.secondsLeft + " §7秒");
                    }
                }

                --this.secondsLeft;
                if (this.secondsLeft <= 0) {
                    AbilityManager.stopTimeStop();
                }

            }
        }, 0L, 20L);
    }

    public static void accumulateDamage(UUID entityId, double damage, Entity damager) {
        AccumulatedDamage existing = (AccumulatedDamage)timeStopAccumulatedDamage.get(entityId);
        if (existing == null) {
            existing = new AccumulatedDamage();
            timeStopAccumulatedDamage.put(entityId, existing);
        }

        existing.damage += damage;
        if (damager != null) {
            existing.damager = damager;
        }

    }

    public static Map<UUID, AccumulatedDamage> getAccumulatedDamage() {
        return timeStopAccumulatedDamage;
    }

    private static void applyAccumulatedDamage() {
        Iterator var0 = timeStopAccumulatedDamage.entrySet().iterator();

        while(true) {
            while(true) {
                Entity entity;
                AccumulatedDamage acc;
                do {
                    Map.Entry entry;
                    do {
                        if (!var0.hasNext()) {
                            return;
                        }

                        entry = (Map.Entry)var0.next();
                        entity = Bukkit.getEntity((UUID)entry.getKey());
                    } while(entity == null);

                    acc = (AccumulatedDamage)entry.getValue();
                } while(acc.damage <= 0.0);

                Entity var7 = acc.damager;
                if (var7 instanceof Player damagerPlayer) {
                    if (entity instanceof LivingEntity living) {
                        living.damage(acc.damage, damagerPlayer);
                        continue;
                    }
                }

                if (entity instanceof LivingEntity living) {
                    living.damage(acc.damage);
                }
            }
        }
    }

    public static void setAbility(Player player, AbilityType ability) {
        if (ability == AbilityType.NONE) {
            removeAbility(player);
        } else {
            removeInvisibilityEffect(player);
            player.setInvisible(false);
            AbilityType oldAbility = (AbilityType)playerAbilities.get(player.getUniqueId());
            if (oldAbility != null) {
                removeAbilityEffects(player, oldAbility);
                if (oldAbility == AbilityType.SOUL_SUMMONER) {
                    removeSummonedMonsters(player);
                }
                for (PotionEffect effect : new ArrayList<>(player.getActivePotionEffects())) {
                    player.removePotionEffect(effect.getType());
                }
            }

            playerAbilities.put(player.getUniqueId(), ability);
            activeSkills.put(player.getUniqueId(), false);
            deathResetEnabled.putIfAbsent(player.getUniqueId(), true);
            if (ability == AbilityType.HEX_MASTER) {
                hexProtection.put(player.getUniqueId(), true);
            } else {
                hexProtection.remove(player.getUniqueId());
            }

            if (ability == AbilityType.SOUL_SUMMONER && summonedKey == null) {
                summonedKey = new NamespacedKey(Main.getInstance(), "summoned_monster");
            }

            applyAbilityEffects(player, ability);
        }
    }

    public static AbilityType getAbility(Player player) {
        return (AbilityType)playerAbilities.get(player.getUniqueId());
    }

    public static AbilityType getRandomAbility() {
        AbilityType[] abilities = AbilityType.values();

        AbilityType result;
        do {
            do {
                result = abilities[random.nextInt(abilities.length)];
            } while(result == AbilityType.NONE);
        } while(result == AbilityType.DAMAGE_TELEPORT);

        return result;
    }

    public static void removeAbility(Player player) {
        AbilityType ability = (AbilityType)playerAbilities.remove(player.getUniqueId());
        if (ability != null) {
            removeAbilityEffects(player, ability);
            if (ability == AbilityType.SOUL_SUMMONER) {
                removeSummonedMonsters(player);
            }
        }

        activeSkills.remove(player.getUniqueId());
        hexProtection.remove(player.getUniqueId());
        hexKillCount.remove(player.getUniqueId());
    }

    public static void removeSummonedMonsters(Player player) {
        if (summonedKey != null) {
            UUID playerId = player.getUniqueId();
            Iterator var2 = Bukkit.getWorlds().iterator();

            while(var2.hasNext()) {
                World world = (World)var2.next();
                Iterator var4 = world.getEntities().iterator();

                while(var4.hasNext()) {
                    Entity entity = (Entity)var4.next();
                    if (entity.getPersistentDataContainer().has(summonedKey, PersistentDataType.STRING)) {
                        String ownerId = (String)entity.getPersistentDataContainer().get(summonedKey, PersistentDataType.STRING);
                        if (ownerId != null && ownerId.equals(playerId.toString())) {
                            entity.remove();
                        }
                    }
                }
            }

        }
    }

    public static void removeAbilityEffectsOnly(Player player, AbilityType ability) {
        removeAbilityEffects(player, ability);
    }

    public static boolean isSkillActive(Player player) {
        return (Boolean)activeSkills.getOrDefault(player.getUniqueId(), false);
    }

    public static void toggleSkill(Player player) {
        boolean current = (Boolean)activeSkills.getOrDefault(player.getUniqueId(), false);
        activeSkills.put(player.getUniqueId(), !current);
        AbilityType ability = getAbility(player);
        if (ability != null) {
            if (!current) {
                applySkillEffect(player, ability);
            } else {
                removeSkillEffect(player, ability);
            }
        }

    }

    public static boolean hasHexProtection(Player player) {
        return (Boolean)hexProtection.getOrDefault(player.getUniqueId(), false);
    }

    public static void setHexProtection(Player player, boolean protected_) {
        hexProtection.put(player.getUniqueId(), protected_);
    }

    public static int getHexKillCount(Player player) {
        return (Integer)hexKillCount.getOrDefault(player.getUniqueId(), 0);
    }

    public static void incrementHexKillCount(Player player) {
        hexKillCount.put(player.getUniqueId(), getHexKillCount(player) + 1);
    }

    public static void applyAbilityEffects(Player player, AbilityType ability) {
        switch (ability) {
            case FLASH:
                player.setWalkSpeed(0.2F);
                player.setFlySpeed(0.2F);
                player.sendMessage("§6[超能力] §a你拥有极快的移动速度! 按技能键切换疾跑状态");
                break;
            case LUCKY:
                player.sendMessage("§6[超能力] §a你非常幸运! 挖掘方块和击杀生物会获得额外掉落物");
                player.sendMessage("§6[超能力] §a每次受伤有15%概率免除伤害");
                break;
            case POSEIDON:
                if (isInWater(player)) {
                    applyPoseidonEffects(player);
                }

                player.sendMessage("§6[超能力] §a进入水中获得力量IV、海豚恩惠IV和水下呼吸!");
                break;
            case INVISIBLE:
                applyInvisibilityEffect(player);
                player.sendMessage("§6[超能力] §a你处于持续隐身状态!");
                break;
            case SUPERMAN:
                player.setAllowFlight(true);
                addEffect(player, PotionEffectType.STRENGTH, 0);
                addEffect(player, PotionEffectType.RESISTANCE, 1);
                player.sendMessage("§6[超能力] §a你可以飞行,并获得力量I和抗性II!");
                break;
            case SUN_CHILD:
                applySunChildEffects(player);
                player.sendMessage("§6[超能力] §a白天获得力量III、抗性I、速度I、防火;夜晚虚弱和缓慢");
                break;
            case BARBARIAN:
                player.setMaxHealth(32.0);
                player.setHealth(32.0);
                player.sendMessage("§6[超能力] §a生命上限提升至32点! 血量越低力量越强、速度越快");
                break;
            case HYDROPHOBIC:
                addEffect(player, PotionEffectType.REGENERATION, 4);
                player.sendMessage("§6[超能力] §a获得永久生命恢复IV,但触水即死!");
                break;
            case NECROMANCER:
                player.sendMessage("§6[超能力] §a攻击目标时呼唤周围亡灵围攻! 亡灵生物无法伤害你");
                break;
            case HEX_MASTER:
                player.sendMessage("§6[超能力] §a拥有一次替死保护! 死亡时随机献祭其他玩家代替");
                break;
            case RICH_MAN:
                giveDiamondBlocks(player);
                player.sendMessage("§6[超能力] §a你获得了大量资源! 副手持钻石块右键消耗5个可召唤一个铁傀儡保镖");
                break;
            case AOE_ATTACK:
                player.sendMessage("§6[超能力] §a左键触发范围攻击,对周围5格内所有生物造成武器伤害!");
                break;
            case SPIT_EXPLOSION:
                player.sendMessage("§6[超能力] §a按技能键发射! 快速连射会惩罚");
                break;
            case BLACKSMITH:
                player.sendMessage("§6[超能力] §a你可以在工作台中制作顶级附魔装备!");
                player.sendMessage("§6[超能力] §a副手持青金石右键可随机附魔(每件装备限3次)");
                break;
            case TAME_MASTER:
                int level = (Integer)tameLevels.getOrDefault(player.getUniqueId(), 0);
                if (level > 0) {
                    applyTameStrengthEffect(player);
                }

                player.sendMessage("§6[超能力] §a驯服动物获得力量加成! 每驯服2只提升1级力量");
                break;
            case TOTEM_BODY:
                player.sendMessage("§6[超能力] §a主手持物品可当不死图腾使用(同物品仅一次)");
                break;
            case ORE_EATER:
                player.sendMessage("§6[超能力] §a副手持矿石右键可吃矿石获得效果(锭/块每1分钟冷却)!");
                break;
            case SOUL_SUMMONER:
                player.sendMessage("§6[超能力] §a击杀怪物收集灵魂,技能键1查看灵魂,技能键2释放灵魂!");
                player.sendMessage("§6[超能力] §c受到伤害3倍,但伤害先由召唤生物承担,生物死后溢出伤害才由你承受");
                break;
            case FOOD_BUFF:
                player.sendMessage("§6[超能力] §a每2分钟只能吃一次食物获得随机增益!");
                break;
            case KILLER:
                player.sendMessage("§6[超能力] §a击杀20只生物后解锁伤害加成!(最高200)");
                player.sendMessage("§6[超能力] §c前10只生物伤害降低为1/4,之后恢复");
                break;
            case ANT_MAN:
                player.sendMessage("§6[超能力] §a按技能键变大(5倍+手长9格+抗性II)!");
                player.sendMessage("§6[超能力] §a技能键2缩小(生命1❤+攻击2❤真伤)");
                break;
            case RUBBER_MAN:
                {
                    AttributeInstance attr = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
                    if (attr != null) {
                        attr.setBaseValue(attr.getDefaultValue() + 9.0);
                    }

                    AttributeInstance entityRange = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
                    if (entityRange != null) {
                        entityRange.setBaseValue(entityRange.getDefaultValue() + 9.0);
                    }
                }

                player.sendMessage("§6[超能力] §a你的手臂变长了! (触及距离+9)");
                player.sendMessage("§6[超能力] §a免疫摔落伤害,但火焰和锋利伤害翻倍");
                break;
            case QUANTUM_MAN:
                player.sendMessage("§6[超能力] §a受到攻击时有40%概率进入量子态(旁观模式5秒)!");
                break;
            case FAIRY:
                player.setAllowFlight(true);
                player.setFlySpeed(0.05F);
                {
                    AttributeInstance attr = player.getAttribute(Attribute.SCALE);
                    if (attr != null) {
                        attr.setBaseValue(0.5);
                    }
                }

                player.sendMessage("§6[超能力] §a你可以飞行! 按技能键给予敌人debuff(30秒冷却)");
                player.sendMessage("§6[超能力] §adebuff效果: 缓慢II+反胃+失明+黑暗 持续10秒");
                break;
            case BIG_STOMACH:
                addEffect(player, PotionEffectType.HUNGER, 1);
                addEffect(player, PotionEffectType.SLOWNESS, 1);
                player.sendMessage("§6[超能力] §a你永久饥饿和缓慢! 按技能键吃方块,技能键2吞噬生物或低血量玩家");
                player.sendMessage("§6[超能力] §a饱食度满时获得力量II和抗性II,低于3获得虚弱");
                break;
            case NATURE_CHILD:
                player.sendMessage("§6[超能力] §a按技能键对准泥土/草方块种树(1秒冷却)!");
                player.sendMessage("§6[超能力] §a站在草方块/泥土/沙子/红沙/灰化土/菌丝上获得生命恢复+食物+抗性");
                break;
            case DAMAGE_EXPLOSION:
                player.sendMessage("§6[超能力] §a受到伤害时会爆炸!");
                break;
            case DAMAGE_EFFECT:
                player.sendMessage("§6[超能力] §a受伤时50%概率背包物品翻倍,50%概率获得buff");
                break;
            case BOMBER:
                player.sendMessage("§6[超能力] §a按技能键(空手)消耗背包3个物品发射炸弹雪球!(3秒冷却)");
                break;
            case FIRE_MAN:
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0);
                player.sendMessage("§6[超能力] §a走过的地方会着火,入水持续扣血,近战带火焰附加!");
                player.sendMessage("§6[超能力] §a按技能键发射火焰弹(5秒冷却)! 技能键2切换走路带火");
                break;
            case ICE_MAN:
                player.sendMessage("§6[超能力] §a水面结冰,陆地留雪,在炎热地方持续扣血!");
                player.sendMessage("§6[超能力] §a按技能键(空手)发射冰冻雪球!(5秒冷却)");
                break;
            case ENDERLING:
                player.sendMessage("§6[超能力] §a怕水! 免疫远程伤害,受远程攻击自动瞬移");
                player.sendMessage("§6[超能力] §a按技能键(空手)投掷末影珍珠!(1秒冷却)");
                break;
            case SPIDER_MAN:
                player.sendMessage("§6[超能力] §a可爬墙!");
                player.sendMessage("§6[超能力] §a按技能键发射蛛网! 技能键2发射蛛丝拉拽");
                break;
            case THIEF:
                player.sendMessage("§6[超能力] §a潜行隐身! 空手右键玩家偷物品,右键生物偷掉落");
                player.sendMessage("§6[超能力] §a按技能键(空手)对玩家窃取生命或buff!(30秒冷却)");
                break;
            case TIME_STOPPER:
                player.sendMessage("§6[超能力] §a按技能键(空手)触发时停5秒! 时停期间世界将暂停");
                player.sendMessage("§6[超能力] §a除你之外的所有玩家和生物将被冻结!(冷却1分钟)");
                break;
            case RECALL:
                player.sendMessage("§6[超能力] §a技能键2记录当前位置!");
                player.sendMessage("§6[超能力] §a空手按技能键回到记录位置(回溯后冷却10秒)");
                player.sendMessage("§6[超能力] §d拥有仅一次替死被动: 受到致命伤害自动回溯到记录点(重新获得该能力也无法刷新)");
                break;
            case MIND_CONTROL:
                player.sendMessage("§6[超能力] §a按技能键控制其他玩家!(控制5秒,冷却60秒)");
                player.sendMessage("§6[超能力] §a控制期间技能键2打开目标玩家背包");
                break;
            case GUARDIAN:
                player.sendMessage("§6[超能力] §a按技能键给自己护盾(免疫3次伤害),技能键2给4格内队友护盾");
                player.sendMessage("§6[超能力] §a护盾持续消耗饱食度,用完或手动取消后冷却60秒");
                break;
            case SPARTAN:
                player.sendMessage("§6[超能力] §a按技能键对前方4格目标造成3❤伤害+巨额击退!");
                player.sendMessage("§6[超能力] §a击杀摔死的玩家获得30秒力量叠加,冷却60秒");
                break;
            case ROMAN_LEGION:
                player.sendMessage("§6[超能力] §a潜行主手持盾右键展开防御阵型!");
                player.sendMessage("§6[超能力] §a左右后侧绝对防御,庇护3×3格队友,减速80%不能跳跃");
                break;
            case WITHER_KIN:
                player.setAllowFlight(true);
                player.setFlySpeed(0.05F);
                player.sendMessage("§6[超能力] §a按技能键发射凋零头颅(冷却5秒)!");
                player.sendMessage("§6[超能力] §a半血获得抗性I,可缓慢飞行");
                break;
            case DEMON_SUMMONER:
                player.sendMessage("§6[超能力] §a按技能键生成唤魔者尖牙(冷却10秒)!");
                player.sendMessage("§6[超能力] §a技能键2召唤恼鬼(冷却60秒,最多1只)");
                break;
            case LAWFUL_CITIZEN:
                player.sendMessage("§6[超能力] §a按技能键送攻击者进监狱5秒(冷却50秒)!");
                player.sendMessage("§6[超能力] §a被击杀则击杀者进监狱20秒");
                break;
            case REFLECTOR:
                player.sendMessage("§6[超能力] §a按技能键开启反射屏障(持续10秒)!");
                player.sendMessage("§6[超能力] §a反弹远程抛射物,近战攻击者受50%反伤");
                break;
            case ELF_RANGER:
                player.sendMessage("§6[超能力] §a按技能键发射箭矢(冷却1秒)!");
                player.sendMessage("§6[超能力] §a箭矢击中生物获得10秒速度I");
                break;
            case WITCH_KIN:
                player.sendMessage("§6[超能力] §a按技能键发射喷溅药水(冷却10秒)!");
                player.sendMessage("§6[超能力] §a随机负面效果,持续5秒");
                break;
            case GLASS_WALKER:
                player.sendMessage("§6[超能力] §a按技能键开关玻璃平台! 开启后脚下持续生成3×3玻璃平台");
                player.sendMessage("§6[超能力] §a生成的玻璃10秒后自动消失");
                break;
            case LIGHTNING_KING:
                player.sendMessage("§6[超能力] §a按技能键对目标位置生成闪电(冷却5秒)!");
                player.sendMessage("§6[超能力] §a技能键2在目标位置生成5道闪电(冷却40秒)");
                break;
            case DIGGER:
                player.sendMessage("§6[超能力] §a挖掘方块概率掉落矿物(淘矿者)!");
                player.sendMessage("§6[超能力] §a铜锭15%，铁锭/金锭/青金石/红石各10%，钻石6%");
                player.sendMessage("§6[超能力] §6下届合金锭+升级模板2%");
                break;
            case SENTINEL:
                player.sendMessage("§6[超能力] §a技能键2在目标位置召唤炮塔(最远5格)!");
                player.sendMessage("§6[超能力] §a炮塔会自动攻击敌人，冷却70秒");
                break;
            case SUMMONER:
                player.sendMessage("§6[超能力] §a按技能键将同队队友传送至自己身边!");
                player.sendMessage("§6[超能力] §a只能传送同队伍的队友，冷却30秒");
        }

    }

    public static void removeAbilityEffects(Player player, AbilityType ability) {
        switch (ability) {
            case FLASH:
                player.setWalkSpeed(0.2F);
                activeSkills.put(player.getUniqueId(), false);
                {
                    AttributeInstance attr = player.getAttribute(Attribute.MOVEMENT_SPEED);
                    if (attr != null) {
                        attr.setBaseValue(0.1);
                    }
                }
            case LUCKY:
            case NECROMANCER:
            case HEX_MASTER:
            case AOE_ATTACK:
            case SPIT_EXPLOSION:
            case BLACKSMITH:
            case DAMAGE_EXPLOSION:
            case DAMAGE_EFFECT:
            case MIND_CONTROL:
            default:
                break;
            case RECALL:
                break;
            case POSEIDON:
                removeEffect(player, PotionEffectType.STRENGTH);
                removeEffect(player, PotionEffectType.DOLPHINS_GRACE);
                removeEffect(player, PotionEffectType.WATER_BREATHING);
                break;
            case INVISIBLE:
                removeInvisibilityEffect(player);
                break;
            case SUPERMAN:
                player.setAllowFlight(false);
                player.setFlying(false);
                removeEffect(player, PotionEffectType.STRENGTH);
                removeEffect(player, PotionEffectType.RESISTANCE);
                break;
            case SUN_CHILD:
                removeEffect(player, PotionEffectType.STRENGTH);
                removeEffect(player, PotionEffectType.RESISTANCE);
                removeEffect(player, PotionEffectType.SPEED);
                removeEffect(player, PotionEffectType.FIRE_RESISTANCE);
                removeEffect(player, PotionEffectType.WEAKNESS);
                removeEffect(player, PotionEffectType.SLOWNESS);
                break;
            case BARBARIAN:
                player.setMaxHealth(20.0);
                if (player.getHealth() > 20.0) {
                    player.setHealth(20.0);
                }

                removeEffect(player, PotionEffectType.STRENGTH);
                removeEffect(player, PotionEffectType.SPEED);
                break;
            case HYDROPHOBIC:
                removeEffect(player, PotionEffectType.REGENERATION);
                break;
            case RICH_MAN:
                removeIronGolems(player);
                break;
            case TAME_MASTER:
                player.removePotionEffect(PotionEffectType.STRENGTH);
                break;
            case TOTEM_BODY:
                usedTotemItems.remove(player.getUniqueId());
                break;
            case ORE_EATER:
                oreCooldowns.remove(player.getUniqueId());
                oreBlockEatCounts.remove(player.getUniqueId());
                oreLevels.remove(player.getUniqueId());
                break;
            case SOUL_SUMMONER:
                playerSouls.remove(player.getUniqueId());
                break;
            case FOOD_BUFF:
                lastFoodEatTime.remove(player.getUniqueId());
                break;
            case KILLER:
                killCounts.remove(player.getUniqueId());
                killDamageBonuses.remove(player.getUniqueId());
                break;
            case ANT_MAN:
                antManState.remove(player.getUniqueId());
                antManSavedHealth.remove(player.getUniqueId());
                {
                    AttributeInstance attr = player.getAttribute(Attribute.SCALE);
                    if (attr != null) {
                        attr.setBaseValue(1.0);
                    }
                }
                {
                    AttributeInstance attr = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
                    if (attr != null) {
                        attr.setBaseValue(attr.getDefaultValue());
                    }
                }
                {
                    AttributeInstance attr = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
                    if (attr != null) {
                        attr.setBaseValue(attr.getDefaultValue());
                    }
                }
                removeEffect(player, PotionEffectType.RESISTANCE);
                player.setMaxHealth(20.0);
                break;
            case RUBBER_MAN:
                {
                    AttributeInstance attr = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
                    if (attr != null) {
                        attr.setBaseValue(attr.getDefaultValue());
                    }
                }
                {
                    AttributeInstance attr = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
                    if (attr != null) {
                        attr.setBaseValue(attr.getDefaultValue());
                    }
                }
                break;
            case QUANTUM_MAN:
                boolean hadQuantumData = quantumEndTime.containsKey(player.getUniqueId());
                quantumEndTime.remove(player.getUniqueId());
                quantumReturnLocation.remove(player.getUniqueId());
                quantumReturnGamemode.remove(player.getUniqueId());
                if (hadQuantumData && player.getGameMode() == GameMode.SPECTATOR) {
                    player.setGameMode(GameMode.SURVIVAL);
                }
                break;
            case FAIRY:
                player.setAllowFlight(false);
                player.setFlying(false);
                player.setFlySpeed(0.2F);
                {
                    AttributeInstance attr = player.getAttribute(Attribute.SCALE);
                    if (attr != null) {
                        attr.setBaseValue(1.0);
                    }
                }
                fairyDebuffCooldown.remove(player.getUniqueId());
                break;
            case BIG_STOMACH:
                removeEffect(player, PotionEffectType.HUNGER);
                removeEffect(player, PotionEffectType.SLOWNESS);
                removeEffect(player, PotionEffectType.STRENGTH);
                removeEffect(player, PotionEffectType.RESISTANCE);
                removeEffect(player, PotionEffectType.WEAKNESS);
                bigStomachEatCooldown.remove(player.getUniqueId());
                bigStomachAnimalCooldown.remove(player.getUniqueId());
                break;
            case NATURE_CHILD:
                removeEffect(player, PotionEffectType.RESISTANCE);
                removeEffect(player, PotionEffectType.SPEED);
                natureChildTreeCooldown.remove(player.getUniqueId());
                break;
            case BOMBER:
                bomberCooldown.remove(player.getUniqueId());
                break;
            case FIRE_MAN:
                removeEffect(player, PotionEffectType.FIRE_RESISTANCE);
                fireManSkillCooldown.remove(player.getUniqueId());
                fireTrailEnabled.remove(player.getUniqueId());
                break;
            case ICE_MAN:
                iceManSkillCooldown.remove(player.getUniqueId());
                break;
            case ENDERLING:
                enderlingSkillCooldown.remove(player.getUniqueId());
                break;
            case SPIDER_MAN:
                player.setAllowFlight(false);
                player.setFlying(false);
                player.setFlySpeed(0.1F);
                spiderManWebCooldown.remove(player.getUniqueId());
                spiderManPullCooldown.remove(player.getUniqueId());
                break;
            case THIEF:
                player.setInvisible(false);
                thiefItemCooldown.remove(player.getUniqueId());
                thiefLifeCooldown.remove(player.getUniqueId());
                thiefStolenBuff.remove(player.getUniqueId());
                break;
            case TIME_STOPPER:
                timeStopCooldowns.remove(player.getUniqueId());
                if (timeStopActive && player.getUniqueId().equals(timeStopTriggerPlayer)) {
                    stopTimeStop();
                }
                break;
            case GUARDIAN:
                UUID gUid = player.getUniqueId();
                cancelGuardianHungerTask(gUid);
                guardianShields.remove(gUid);
                guardianCooldown.remove(gUid);
                guardianGiver.entrySet().removeIf((e) -> {
                    return ((UUID)e.getValue()).equals(gUid) || ((UUID)e.getKey()).equals(gUid);
                });
                guardianGivenTo.entrySet().removeIf((e) -> {
                    return ((UUID)e.getValue()).equals(gUid) || ((UUID)e.getKey()).equals(gUid);
                });
                break;
            case SPARTAN:
                spartanCooldown.remove(player.getUniqueId());
                spartanCooldownDuration.remove(player.getUniqueId());
                spartanStrengthLevel.remove(player.getUniqueId());
                spartanStrengthEndTime.remove(player.getUniqueId());
                removeEffect(player, PotionEffectType.STRENGTH);
                break;
            case ROMAN_LEGION:
                legionFormation.remove(player.getUniqueId());
                {
                    Integer tid = (Integer)legionTaskId.remove(player.getUniqueId());
                    if (tid != null) {
                        Bukkit.getScheduler().cancelTask(tid);
                    }
                }

                legionCooldown.remove(player.getUniqueId());
                Float savedSpeed = (Float)legionSavedSpeed.remove(player.getUniqueId());
                if (savedSpeed != null) {
                    player.setWalkSpeed(savedSpeed);
                }
                break;
            case WITHER_KIN:
                player.setAllowFlight(false);
                player.setFlying(false);
                player.setFlySpeed(0.1F);
                removeEffect(player, PotionEffectType.RESISTANCE);
                witherSkillCooldown.remove(player.getUniqueId());
                break;
            case DEMON_SUMMONER:
                demonFangCooldown.remove(player.getUniqueId());
                demonVexCooldown.remove(player.getUniqueId());
                {
                    Set<UUID> vexIds = (Set)demonVexUUIDs.remove(player.getUniqueId());
                    if (vexIds != null) {
                        Iterator vexIter = vexIds.iterator();
                        while(vexIter.hasNext()) {
                            UUID vexId = (UUID)vexIter.next();
                            Entity vex = Bukkit.getEntity(vexId);
                            if (vex != null) {
                                vex.remove();
                            }
                        }
                    }
                }
                {
                    BukkitTask task = (BukkitTask)demonVexFollowTasks.remove(player.getUniqueId());
                    if (task != null) {
                        task.cancel();
                    }
                }
                break;
            case LAWFUL_CITIZEN:
                citizenCooldown.remove(player.getUniqueId());
                break;
            case REFLECTOR:
                reflectorEndTime.remove(player.getUniqueId());
                {
                    Integer tid = (Integer)reflectorParticleTask.remove(player.getUniqueId());
                    if (tid != null) {
                        Bukkit.getScheduler().cancelTask(tid);
                    }
                }
                reflectorCooldown.remove(player.getUniqueId());
                break;
            case ELF_RANGER:
                elfRangerCooldown.remove(player.getUniqueId());
                break;
            case WITCH_KIN:
                witchKinCooldown.remove(player.getUniqueId());
                break;
            case GLASS_WALKER:
                {
                    BukkitTask t = (BukkitTask)glassWalkerTask.remove(player.getUniqueId());
                    if (t != null) {
                        t.cancel();
                    }
                }
            case LIGHTNING_KING:
                lightningKingCooldown.remove(player.getUniqueId());
                lightningKingMassCooldown.remove(player.getUniqueId());
            case DIGGER:
            case SENTINEL:
                {
                    sentinelCooldown.remove(player.getUniqueId());
                    Set<UUID> stands = (Set)sentinelArmorStands.remove(player.getUniqueId());
                    if (stands != null) {
                        Iterator standIter = stands.iterator();
                        while(standIter.hasNext()) {
                            UUID standId = (UUID)standIter.next();
                            sentinelHits.remove(standId);
                            Entity stand = Bukkit.getEntity(standId);
                            if (stand != null) {
                                stand.remove();
                            }
                        }
                    }
                    Set<BukkitTask> tasks = (Set)sentinelTasks.remove(player.getUniqueId());
                    if (tasks != null) {
                        Iterator taskIter = tasks.iterator();
                        while(taskIter.hasNext()) {
                            BukkitTask st = (BukkitTask)taskIter.next();
                            st.cancel();
                        }
                    }
                }
            case SUMMONER:
                summonerCooldown.remove(player.getUniqueId());
            case REDEEMER:
                redeemerPapers.remove(player.getUniqueId());
                redeemerUseCount.remove(player.getUniqueId());
                redeemerCooldown.remove(player.getUniqueId());
                cancelRedeemerTask(player.getUniqueId());
                restoreRedeemerSpeed(player);
                break;
        }

    }

    private static void applySkillEffect(Player player, AbilityType ability) {
        switch (ability) {
            case FLASH:
                AttributeInstance attr = player.getAttribute(Attribute.MOVEMENT_SPEED);
                if (attr != null) {
                    attr.setBaseValue(0.7);
                }
                break;
            case ANT_MAN:
            case GLASS_WALKER:
                {
                    UUID uuid = player.getUniqueId();
                    BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
                        if (!isSkillActive(player)) return;
                        Location loc = player.getLocation();
                        int bx = loc.getBlockX();
                        int by = loc.getBlockY() - 1;
                        int bz = loc.getBlockZ();
                        World world = loc.getWorld();
                        if (world != null) {
                            for (int dx = -1; dx <= 1; ++dx) {
                                for (int dz = -1; dz <= 1; ++dz) {
                                    Block block = world.getBlockAt(bx + dx, by, bz + dz);
                                    if (block.getType() == Material.AIR) {
                                        block.setType(Material.GLASS);
                                        Block finalBlock = block;
                                        Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                                            if (finalBlock.getType() == Material.GLASS) {
                                                finalBlock.setType(Material.AIR);
                                            }
                                        }, 200L);
                                    }
                                }
                            }
                        }
                    }, 0L, 1L);
                    glassWalkerTask.put(uuid, task);
                    player.sendMessage("§b✦ §3玻璃平台已开启!");
                }
            default:
        }
    }

    private static void removeSkillEffect(Player player, AbilityType ability) {
        switch (ability) {
            case FLASH:
                AttributeInstance attr = player.getAttribute(Attribute.MOVEMENT_SPEED);
                if (attr != null) {
                    attr.setBaseValue(0.1);
                }
                break;
            case ANT_MAN:
            case GLASS_WALKER:
                {
                    UUID uuid = player.getUniqueId();
                    BukkitTask task = (BukkitTask)glassWalkerTask.remove(uuid);
                    if (task != null) {
                        task.cancel();
                    }
                    player.sendMessage("§b✦ §3玻璃平台已关闭!");
                }
            default:
        }
    }

    public static void applyPoseidonEffects(Player player) {
        addEffect(player, PotionEffectType.STRENGTH, 3);
        addEffect(player, PotionEffectType.DOLPHINS_GRACE, 4);
        addEffect(player, PotionEffectType.WATER_BREATHING, 4);
    }

    public static void removePoseidonEffects(Player player) {
        removeEffect(player, PotionEffectType.STRENGTH);
        removeEffect(player, PotionEffectType.DOLPHINS_GRACE);
        removeEffect(player, PotionEffectType.WATER_BREATHING);
    }

    public static void applySunChildEffects(Player player) {
        long time = player.getWorld().getTime();
        boolean isDay = time >= 0L && time < 12000L;
        removeEffect(player, PotionEffectType.STRENGTH);
        removeEffect(player, PotionEffectType.RESISTANCE);
        removeEffect(player, PotionEffectType.SPEED);
        removeEffect(player, PotionEffectType.FIRE_RESISTANCE);
        removeEffect(player, PotionEffectType.WEAKNESS);
        removeEffect(player, PotionEffectType.SLOWNESS);
        if (isDay) {
            addEffect(player, PotionEffectType.STRENGTH, 3);
            addEffect(player, PotionEffectType.RESISTANCE, 1);
            addEffect(player, PotionEffectType.SPEED, 1);
            addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0);
        } else {
            addEffect(player, PotionEffectType.WEAKNESS, 2);
            addEffect(player, PotionEffectType.SLOWNESS, 1);
        }

    }

    public static void applyBarbarianEffects(Player player) {
        int currentHealth = (int)player.getHealth();
        int maxHealth = 32;
        int heartsLost = (maxHealth - currentHealth) / 2;
        removeEffect(player, PotionEffectType.STRENGTH);
        removeEffect(player, PotionEffectType.SPEED);
        if (heartsLost > 0) {
            addEffect(player, PotionEffectType.STRENGTH, heartsLost - 1);
        }

        int speedLevel = Math.min(heartsLost, 5);
        if (speedLevel > 0) {
            addEffect(player, PotionEffectType.SPEED, speedLevel - 1);
        }

    }

    public static void processBlockBreak(Player player, Block block, Collection<ItemStack> drops) {
        if (!drops.isEmpty()) {
            Iterator var3 = drops.iterator();

            while(var3.hasNext()) {
                ItemStack drop = (ItemStack)var3.next();
                int randomCount = random.nextInt(256) + 1;
                int maxStack = drop.getMaxStackSize();
                ItemStack extra = drop.clone();
                extra.setAmount(Math.min(randomCount, maxStack));
                block.getWorld().dropItemNaturally(block.getLocation(), extra);

                for(randomCount -= maxStack; randomCount > 0; randomCount -= maxStack) {
                    ItemStack more = drop.clone();
                    more.setAmount(Math.min(randomCount, maxStack));
                    block.getWorld().dropItemNaturally(block.getLocation(), more);
                }
            }
        }

    }

    public static void processEntityDrops(Player player, Location deathLocation, List<ItemStack> drops) {
        if (!drops.isEmpty()) {
            Iterator var3 = drops.iterator();

            while(true) {
                ItemStack item;
                int multiplier;
                do {
                    if (!var3.hasNext()) {
                        return;
                    }

                    item = (ItemStack)var3.next();
                    multiplier = random.nextInt(5) + 1;
                } while(multiplier <= 1);

                int extraAmount = item.getAmount() * (multiplier - 1);

                int stackSize;
                for(int maxStack = item.getMaxStackSize(); extraAmount > 0; extraAmount -= stackSize) {
                    stackSize = Math.min(extraAmount, maxStack);
                    ItemStack extra = item.clone();
                    extra.setAmount(stackSize);
                    deathLocation.getWorld().dropItemNaturally(deathLocation, extra);
                }
            }
        }
    }

    private static void giveDiamondBlocks(Player player) {
        ItemStack[] items = new ItemStack[]{new ItemStack(Material.DIAMOND_BLOCK, 12), new ItemStack(Material.IRON_BLOCK, 2), new ItemStack(Material.GOLD_BLOCK, 2), new ItemStack(Material.EMERALD_BLOCK, 2)};
        ItemStack[] var2 = items;
        int var3 = items.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            ItemStack item = var2[var4];
            Map<Integer, ItemStack> remaining = player.getInventory().addItem(new ItemStack[]{item});
            if (!remaining.isEmpty()) {
                Location loc = player.getLocation();
                Iterator var8 = remaining.values().iterator();

                while(var8.hasNext()) {
                    ItemStack i = (ItemStack)var8.next();
                    loc.getWorld().dropItemNaturally(loc, i);
                }
            }
        }

        player.sendMessage("§6[超能力] §a你获得了12个钻石块、2个铁块、2个金块和2个绿宝石块! (已存入背包)");
    }

    public static void processDiggerDrop(Player player) {
        double r = Math.random() * 100.0;
        ItemStack drop = null;
        if (r < 2.0) {
            ItemStack template = new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, 1);
            ItemStack ingot = new ItemStack(Material.NETHERITE_INGOT, 1);
            Map<Integer, ItemStack> remain = player.getInventory().addItem(template, ingot);
            if (!remain.isEmpty()) {
                for (ItemStack i : remain.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), i);
                }
            }
            player.sendMessage("§6[淘矿者] §6你淘到了下届合金锭+升级模板!");
            return;
        } else if (r < 8.0) {
            drop = new ItemStack(Material.DIAMOND, 1);
            player.sendMessage("§6[淘矿者] §b你淘到了钻石!");
        } else if (r < 18.0) {
            int type = (int)(Math.random() * 4.0);
            switch (type) {
                case 0: drop = new ItemStack(Material.IRON_INGOT, 1); break;
                case 1: drop = new ItemStack(Material.GOLD_INGOT, 1); break;
                case 2: drop = new ItemStack(Material.LAPIS_LAZULI, 3); break;
                case 3: drop = new ItemStack(Material.REDSTONE, 4); break;
            }
        } else if (r < 33.0) {
            drop = new ItemStack(Material.COPPER_INGOT, 1);
        }
        if (drop != null) {
            Map<Integer, ItemStack> remain = player.getInventory().addItem(drop);
            if (!remain.isEmpty()) {
                player.getWorld().dropItemNaturally(player.getLocation(), remain.get(0));
            }
        }
    }

    private static void spawnIronGolems(Player player) {
        List<UUID> golemIds = new ArrayList();
        Location loc = player.getLocation();

        for(int i = 0; i < 2; ++i) {
            Location spawnLoc = loc.clone().add((double)(1 + i), 1.0, 0.0);
            IronGolem golem = (IronGolem)player.getWorld().spawnEntity(spawnLoc, EntityType.IRON_GOLEM);
            golem.setPlayerCreated(true);
            golem.setCustomName("§b" + player.getName() + "的铁傀儡");
            golem.setCustomNameVisible(true);
            golem.setMaxHealth(100.0);
            golem.setHealth(100.0);
            golemIds.add(golem.getUniqueId());
        }

        playerGolems.put(player.getUniqueId(), golemIds);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            List<UUID> ids = (List)playerGolems.get(player.getUniqueId());
            if (ids != null && !ids.isEmpty()) {
                Iterator var2 = ids.iterator();

                while(true) {
                    while(true) {
                        Entity entity;
                        do {
                            do {
                                do {
                                    do {
                                        if (!var2.hasNext()) {
                                            return;
                                        }

                                        UUID golemId = (UUID)var2.next();
                                        entity = Bukkit.getEntity(golemId);
                                    } while(entity == null);
                                } while(!entity.isValid());
                            } while(entity.isDead());
                        } while(!(entity instanceof Mob));

                        Mob mob = (Mob)entity;
                        if (!entity.getWorld().equals(player.getWorld())) {
                            entity.teleport(player.getLocation().add(1.0, 1.0, 0.0));
                        } else {
                            double distance = entity.getLocation().distance(player.getLocation());
                            if (distance > 30.0) {
                                entity.teleport(player.getLocation().add(1.0, 1.0, 0.0));
                            } else if (distance > 10.0) {
                                mob.getPathfinder().moveTo(player.getLocation(), 1.0);
                            }

                            if (mob.getTarget() != null) {
                                Set<UUID> tracked = (Set)richManTrackedTargets.get(player.getUniqueId());
                                if (tracked == null || !tracked.contains(mob.getTarget().getUniqueId())) {
                                    mob.setTarget((LivingEntity)null);
                                }
                            }
                        }
                    }
                }
            }
        }, 20L, 40L);
        golemFollowTasks.put(player.getUniqueId(), task);
        player.sendMessage("§6[超能力] §a两个铁傀儡已降临到你身边!");
    }

    private static void removeIronGolems(Player player) {
        List<UUID> golemIds = (List)playerGolems.remove(player.getUniqueId());
        if (golemIds != null) {
            Iterator var2 = golemIds.iterator();

            while(var2.hasNext()) {
                UUID golemId = (UUID)var2.next();
                Entity entity = Bukkit.getEntity(golemId);
                if (entity != null) {
                    entity.remove();
                }
            }
        }

        BukkitTask task = (BukkitTask)golemFollowTasks.remove(player.getUniqueId());
        if (task != null) {
            task.cancel();
        }

        richManDiamondCount.remove(player.getUniqueId());
        richManTrackedTargets.remove(player.getUniqueId());
    }

    public static List<UUID> getPlayerGolems(UUID playerUUID) {
        return (List)playerGolems.get(playerUUID);
    }

    public static Map<UUID, List<UUID>> getPlayerGolemsMap() {
        return playerGolems;
    }

    public static void addRichManTarget(UUID playerId, UUID targetId) {
        ((Set)richManTrackedTargets.computeIfAbsent(playerId, (k) -> {
            return new HashSet();
        })).add(targetId);
    }

    public static boolean isRichManTarget(UUID playerId, UUID targetId) {
        Set<UUID> targets = (Set)richManTrackedTargets.get(playerId);
        return targets != null && targets.contains(targetId);
    }

    public static int getRichManDiamondCount(UUID uuid) {
        return (Integer)richManDiamondCount.getOrDefault(uuid, 0);
    }

    public static void incrementRichManDiamondCount(UUID uuid) {
        richManDiamondCount.put(uuid, getRichManDiamondCount(uuid) + 1);
    }

    public static void resetRichManDiamondCount(UUID uuid) {
        richManDiamondCount.remove(uuid);
    }

    public static void spawnSingleGolemForRichMan(Player player) {
        Location loc = player.getLocation();
        IronGolem golem = (IronGolem)player.getWorld().spawnEntity(loc.add(1.0, 1.0, 0.0), EntityType.IRON_GOLEM);
        golem.setPlayerCreated(true);
        golem.setCustomName("§b" + player.getName() + "的铁傀儡保镖");
        golem.setCustomNameVisible(true);
        golem.setMaxHealth(100.0);
        golem.setHealth(100.0);
        List<UUID> golemIds = (List)playerGolems.computeIfAbsent(player.getUniqueId(), (k) -> {
            return new ArrayList();
        });
        golemIds.add(golem.getUniqueId());
        if (!golemFollowTasks.containsKey(player.getUniqueId())) {
            BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
                List<UUID> ids = (List)playerGolems.get(player.getUniqueId());
                if (ids != null && !ids.isEmpty()) {
                    Iterator var2 = ids.iterator();

                    while(true) {
                        while(true) {
                            Entity entity;
                            do {
                                do {
                                    do {
                                        do {
                                            if (!var2.hasNext()) {
                                                return;
                                            }

                                            UUID golemId = (UUID)var2.next();
                                            entity = Bukkit.getEntity(golemId);
                                        } while(entity == null);
                                    } while(!entity.isValid());
                                } while(entity.isDead());
                            } while(!(entity instanceof Mob));

                            Mob mob = (Mob)entity;
                            if (!entity.getWorld().equals(player.getWorld())) {
                                entity.teleport(player.getLocation().add(1.0, 1.0, 0.0));
                            } else {
                                double distance = entity.getLocation().distance(player.getLocation());
                                if (distance > 30.0) {
                                    entity.teleport(player.getLocation().add(1.0, 1.0, 0.0));
                                } else if (distance > 10.0) {
                                    mob.getPathfinder().moveTo(player.getLocation(), 1.0);
                                }

                                if (mob.getTarget() != null) {
                                    Set<UUID> tracked = (Set)richManTrackedTargets.get(player.getUniqueId());
                                    if (tracked == null || !tracked.contains(mob.getTarget().getUniqueId())) {
                                        mob.setTarget((LivingEntity)null);
                                    }
                                }
                            }
                        }
                    }
                }
            }, 20L, 40L);
            golemFollowTasks.put(player.getUniqueId(), task);
        }

        int total = golemIds.size();
        player.sendMessage("§6[超能力] §a铁傀儡保镖已降临! §7(当前共 §e" + total + " §7个保镖)");
    }

    public static void ensureRichManGolems(Player player) {
        if (getAbility(player) == AbilityType.RICH_MAN) {
            List<UUID> golemIds = (List)playerGolems.get(player.getUniqueId());
            if (golemIds == null || golemIds.isEmpty()) {
                return;
            }

            boolean anyAlive = golemIds.stream().anyMatch((id) -> {
                Entity entity = Bukkit.getEntity(id);
                return entity != null && entity.isValid() && !entity.isDead();
            });
            if (!anyAlive) {
                removeIronGolems(player);
            }
        }

    }

    public static void addTameCount(Player player) {
        UUID uuid = player.getUniqueId();
        int count = (Integer)tameCounts.getOrDefault(uuid, 0) + 1;
        tameCounts.put(uuid, count);
        int newLevel = count / 2;
        int oldLevel = (Integer)tameLevels.getOrDefault(uuid, 0);
        tameLevels.put(uuid, newLevel);
        if (newLevel > oldLevel) {
            player.sendMessage("§6[超能力] §a驯服大师等级提升! 当前等级: §e" + newLevel + " §a(驯服 " + count + " 只)");
        }

        if (newLevel > 0) {
            applyTameStrengthEffect(player);
        }

    }

    public static void applyTameStrengthEffect(Player player) {
        int level = (Integer)tameLevels.getOrDefault(player.getUniqueId(), 0);
        if (level > 0) {
            player.removePotionEffect(PotionEffectType.STRENGTH);
            player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, -1, level - 1, false, false, false));
        }
    }

    public static int getTameLevel(UUID uuid) {
        return (Integer)tameLevels.getOrDefault(uuid, 0);
    }

    public static int getTameCount(UUID uuid) {
        return (Integer)tameCounts.getOrDefault(uuid, 0);
    }

    public static NamespacedKey getSummonedKey() {
        return summonedKey;
    }

    public static Map<EntityType, Integer> getSouls(UUID playerId) {
        return (Map)playerSouls.computeIfAbsent(playerId, (k) -> {
            return new HashMap();
        });
    }

    public static void addSoul(UUID playerId, EntityType type) {
        Map<EntityType, Integer> souls = getSouls(playerId);
        souls.put(type, (Integer)souls.getOrDefault(type, 0) + 1);
    }

    public static boolean removeSoul(UUID playerId, EntityType type) {
        Map<EntityType, Integer> souls = getSouls(playerId);
        int count = (Integer)souls.getOrDefault(type, 0);
        if (count > 0) {
            if (count == 1) {
                souls.remove(type);
            } else {
                souls.put(type, count - 1);
            }

            return true;
        } else {
            return false;
        }
    }

    public static int getSoulCount(UUID playerId, EntityType type) {
        return (Integer)getSouls(playerId).getOrDefault(type, 0);
    }

    public static void clearSouls(UUID playerId) {
        playerSouls.remove(playerId);
    }

    public static boolean canEatOre(Player player, Material material) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Map<Material, Long> cooldowns = (Map)oreCooldowns.get(player.getUniqueId());
            if (cooldowns == null) {
                return true;
            } else {
                Long lastEat = (Long)cooldowns.get(material);
                if (lastEat == null) {
                    return true;
                } else {
                    return System.currentTimeMillis() - lastEat >= 60000L;
                }
            }
        }
    }

    public static void setOreCooldown(Player player, Material material) {
        ((Map)oreCooldowns.computeIfAbsent(player.getUniqueId(), (k) -> {
            return new HashMap();
        })).put(material, System.currentTimeMillis());
    }

    public static int getOreBlockEatCount(UUID uuid, String oreKey) {
        Map<String, Integer> counts = (Map)oreBlockEatCounts.get(uuid);
        return counts == null ? 0 : (Integer)counts.getOrDefault(oreKey, 0);
    }

    public static void incrementOreBlockEatCount(UUID uuid, String oreKey) {
        oreBlockEatCounts.computeIfAbsent(uuid, (k) -> {
            return new HashMap();
        });
        int count = getOreBlockEatCount(uuid, oreKey) + 1;
        ((Map)oreBlockEatCounts.get(uuid)).put(oreKey, count);
        if (count % 5 == 0) {
            int level = getOreLevel(uuid, oreKey) + 1;
            setOreLevel(uuid, oreKey, level);
        }

    }

    public static int getOreLevel(UUID uuid, String oreKey) {
        Map<String, Integer> levels = (Map)oreLevels.get(uuid);
        return levels == null ? 0 : (Integer)levels.getOrDefault(oreKey, 0);
    }

    public static void setOreLevel(UUID uuid, String oreKey, int level) {
        ((Map)oreLevels.computeIfAbsent(uuid, (k) -> {
            return new HashMap();
        })).put(oreKey, level);
    }

    public static Map<String, Integer> getAllOreLevels(UUID uuid) {
        Map<String, Integer> levels = (Map)oreLevels.get(uuid);
        return levels == null ? new HashMap() : new HashMap(levels);
    }

    public static boolean canEatFood(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long lastEat = (Long)lastFoodEatTime.get(player.getUniqueId());
            if (lastEat == null) {
                return true;
            } else {
                return System.currentTimeMillis() - lastEat >= 120000L;
            }
        }
    }

    public static void setFoodCooldown(Player player) {
        lastFoodEatTime.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static void addKillCount(Player player) {
        UUID uuid = player.getUniqueId();
        int kills = (Integer)killCounts.getOrDefault(uuid, 0) + 1;
        killCounts.put(uuid, kills);
        if (kills <= 20) {
            player.sendMessage("§6[超能力] §a杀戮者击杀进度: §e" + kills + "/20 §a(" + (kills <= 10 ? "减伤中" : "已突破减伤") + ")");
        }

        if (kills >= 20) {
            double bonus = Math.min((double)(kills - 20 + 1), 200.0);
            killDamageBonuses.put(uuid, bonus);
            String var10001 = String.format("%.1f", bonus);
            player.sendMessage("§6[超能力] §a杀戮者伤害解锁! 当前加成: §e+" + var10001 + " §a(击杀 " + kills + " 只)");
        }

    }

    public static int getKillCount(UUID uuid) {
        return (Integer)killCounts.getOrDefault(uuid, 0);
    }

    public static double getKillDamageBonus(UUID uuid) {
        return (Double)killDamageBonuses.getOrDefault(uuid, 0.0);
    }

    public static int getKillThreshold() {
        return 20;
    }

    public static int getReductionThreshold() {
        return 10;
    }

    public static double getMaxKillDamage() {
        return 200.0;
    }

    public static boolean hasUsedTotemItem(Player player, Material material) {
        Set<Material> used = (Set)usedTotemItems.get(player.getUniqueId());
        return used != null && used.contains(material);
    }

    public static void markTotemItemUsed(Player player, Material material) {
        ((Set)usedTotemItems.computeIfAbsent(player.getUniqueId(), (k) -> {
            return new HashSet();
        })).add(material);
    }

    private static boolean isInWater(Player player) {
        return player.getLocation().getBlock().isLiquid() || player.getLocation().add(0.0, 1.0, 0.0).getBlock().isLiquid();
    }

    private static void addEffect(Player player, PotionEffectType type, int amplifier) {
        player.addPotionEffect(new PotionEffect(type, -1, amplifier, true, false));
    }

    private static void removeEffect(Player player, PotionEffectType type) {
        player.removePotionEffect(type);
    }

    public static void applyInvisibilityEffect(Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, -1, 0, false, false, false));
        player.setInvisible(true);
        InvisibleEquipmentManager.stripPotionParticles(player);
        InvisibleEquipmentManager.hideEquipment(player);
    }

    public static void removeInvisibilityEffect(Player player) {
        player.removePotionEffect(PotionEffectType.INVISIBILITY);
        player.setInvisible(false);
        InvisibleEquipmentManager.showEquipment(player);
    }

    public static boolean isDeathResetEnabled(Player player) {
        return (Boolean)deathResetEnabled.getOrDefault(player.getUniqueId(), true);
    }

    public static void setDeathResetEnabled(Player player, boolean enabled) {
        deathResetEnabled.put(player.getUniqueId(), enabled);
    }

    public static boolean shouldResetOnDeath(Player player) {
        return isDeathResetEnabled(player) && playerAbilities.containsKey(player.getUniqueId());
    }

    public static boolean hasNoCooldown(UUID uuid) {
        return noCooldownPlayers.contains(uuid);
    }

    public static void setNoCooldown(UUID uuid, boolean enabled) {
        if (enabled) {
            noCooldownPlayers.add(uuid);
        } else {
            noCooldownPlayers.remove(uuid);
        }

    }

    public static boolean toggleNoCooldown(UUID uuid) {
        boolean current = hasNoCooldown(uuid);
        setNoCooldown(uuid, !current);
        return !current;
    }

    public static boolean isCodeKillProtected(Player player) {
        return player.getScoreboardTags().contains("cnl_protected");
    }

    public static boolean toggleCodeKillProtection(Player player) {
        if (isCodeKillProtected(player)) {
            player.removeScoreboardTag("cnl_protected");
            return false;
        } else {
            player.addScoreboardTag("cnl_protected");
            return true;
        }
    }

    public static boolean isAntManShrunk(Player player) {
        return (Integer)antManState.getOrDefault(player.getUniqueId(), 0) == 1;
    }

    public static boolean isAntManBig(Player player) {
        return (Integer)antManState.getOrDefault(player.getUniqueId(), 0) == 2;
    }

    public static int getAntManState(Player player) {
        return (Integer)antManState.getOrDefault(player.getUniqueId(), 0);
    }

    public static void applyAntManSmallEffect(Player player) {
        antManState.put(player.getUniqueId(), 1);
        antManSavedHealth.put(player.getUniqueId(), player.getHealth());
        AttributeInstance scaleAttr = player.getAttribute(Attribute.SCALE);
        if (scaleAttr != null) {
            scaleAttr.setBaseValue(0.1);
        }

        player.setMaxHealth(2.0);
        player.setHealth(Math.min(2.0, player.getHealth()));
        player.sendMessage("§6[超能力] §a你缩小了! 生命值变为1颗心,攻击造成2颗心真伤!");
    }

    public static void applyAntManBigEffect(Player player) {
        antManState.put(player.getUniqueId(), 2);
        antManSavedHealth.put(player.getUniqueId(), player.getHealth());
        AttributeInstance scaleAttr = player.getAttribute(Attribute.SCALE);
        if (scaleAttr != null) {
            scaleAttr.setBaseValue(5.0);
        }

        AttributeInstance blockRange = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
        if (blockRange != null) {
            blockRange.setBaseValue(9.0);
        }

        AttributeInstance entityRange = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
        if (entityRange != null) {
            entityRange.setBaseValue(9.0);
        }

        addEffect(player, PotionEffectType.RESISTANCE, 1);
        player.sendMessage("§6[超能力] §a你变大了! 体型5倍,手长9格,获得抗性II!");
    }

    public static void removeAntManEffect(Player player) {
        int state = (Integer)antManState.getOrDefault(player.getUniqueId(), 0);
        antManState.put(player.getUniqueId(), 0);
        AttributeInstance scaleAttr = player.getAttribute(Attribute.SCALE);
        if (scaleAttr != null) {
            scaleAttr.setBaseValue(1.0);
        }

        AttributeInstance blockRange = player.getAttribute(Attribute.BLOCK_INTERACTION_RANGE);
        if (blockRange != null) {
            blockRange.setBaseValue(blockRange.getDefaultValue());
        }

        AttributeInstance entityRange = player.getAttribute(Attribute.ENTITY_INTERACTION_RANGE);
        if (entityRange != null) {
            entityRange.setBaseValue(entityRange.getDefaultValue());
        }

        if (state == 1) {
            double savedHealth = (Double)antManSavedHealth.getOrDefault(player.getUniqueId(), 20.0);
            antManSavedHealth.remove(player.getUniqueId());
            player.setMaxHealth(20.0);
            player.setHealth(Math.min(savedHealth, 20.0));
        } else {
            antManSavedHealth.remove(player.getUniqueId());
            player.setMaxHealth(20.0);
        }

        removeEffect(player, PotionEffectType.RESISTANCE);
        player.sendMessage("§6[超能力] §a你恢复了正常大小!");
    }

    public static boolean isQuantumState(UUID uuid) {
        Long end = (Long)quantumEndTime.get(uuid);
        if (end == null) {
            return false;
        } else if (System.currentTimeMillis() >= end) {
            quantumEndTime.remove(uuid);
            return false;
        } else {
            return true;
        }
    }

    public static boolean isRestoringQuantumDamage(UUID uuid) {
        return quantumRestoringDamage.contains(uuid);
    }

    public static void setQuantumState(Player player, long durationMs) {
        setQuantumState(player, durationMs, 0.0);
    }

    public static void setQuantumState(Player player, long durationMs, double storedDamage) {
        UUID uuid = player.getUniqueId();
        quantumReturnGamemode.put(uuid, player.getGameMode());
        quantumEndTime.put(uuid, System.currentTimeMillis() + durationMs);
        if (storedDamage > 0.0) {
            quantumStoredDamage.put(uuid, storedDamage);
        }
        player.setGameMode(GameMode.SPECTATOR);
    }

    public static void clearQuantumState(UUID uuid) {
        quantumEndTime.remove(uuid);
        quantumReturnGamemode.remove(uuid);
        quantumReturnLocation.remove(uuid);
        quantumStoredDamage.remove(uuid);
    }

    public static void restoreFromQuantum(Player player) {
        UUID uuid = player.getUniqueId();
        GameMode gm = (GameMode)quantumReturnGamemode.remove(uuid);
        quantumEndTime.remove(uuid);
        quantumReturnLocation.remove(uuid);
        Double storedDamage = (Double)quantumStoredDamage.remove(uuid);
        if (!player.isDead() && player.getHealth() > 0.0) {
            if (gm != null) {
                player.setGameMode(gm);
            } else {
                player.setGameMode(GameMode.SURVIVAL);
            }
            if (storedDamage != null && storedDamage > 0.0) {
                quantumRestoringDamage.add(uuid);
                player.damage(storedDamage);
                Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
                    quantumRestoringDamage.remove(uuid);
                }, 2L);
            }
        }
    }

    public static boolean canUseFairyDebuff(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)fairyDebuffCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 30000L;
        }
    }

    public static void setFairyDebuffCooldown(Player player) {
        fairyDebuffCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canEatBlock(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)bigStomachEatCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 500L;
        }
    }

    public static void setBlockEatCooldown(Player player) {
        bigStomachEatCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canEatAnimal(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)bigStomachAnimalCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 2000L;
        }
    }

    public static void setAnimalEatCooldown(Player player) {
        bigStomachAnimalCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canGrowTree(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)natureChildTreeCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 1000L;
        }
    }

    public static void setTreeCooldown(Player player) {
        natureChildTreeCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canPlaceTNT(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)bomberCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 3000L;
        }
    }

    public static void setTntCooldown(Player player) {
        bomberCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canFireSkill(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)fireManSkillCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 5000L;
        }
    }

    public static void setFireSkillCooldown(Player player) {
        fireManSkillCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean isFireTrailEnabled(Player player) {
        return (Boolean)fireTrailEnabled.getOrDefault(player.getUniqueId(), false);
    }

    public static void toggleFireTrail(Player player) {
        boolean current = (Boolean)fireTrailEnabled.getOrDefault(player.getUniqueId(), false);
        fireTrailEnabled.put(player.getUniqueId(), !current);
        player.sendMessage("§6[超能力] §a走路带火已" + (!current ? "§a开启" : "§c关闭") + "§a!");
    }

    public static boolean isIceWalkEnabled(Player player) {
        return (Boolean)iceWalkEnabled.getOrDefault(player.getUniqueId(), true);
    }

    public static void toggleIceWalk(Player player) {
        boolean current = (Boolean)iceWalkEnabled.getOrDefault(player.getUniqueId(), true);
        iceWalkEnabled.put(player.getUniqueId(), !current);
        player.sendMessage("§6[超能力] §a水面结冰已" + (!current ? "§a开启" : "§c关闭") + "§a!");
    }

    public static boolean canUseGuardian(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)guardianCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 60000L;
        }
    }

    public static void setGuardianCooldown(UUID uuid) {
        guardianCooldown.put(uuid, System.currentTimeMillis());
    }

    public static boolean isGuardianShieldActive(UUID uuid) {
        return (Integer)guardianShields.getOrDefault(uuid, 0) > 0;
    }

    public static int getGuardianShields(UUID uuid) {
        return (Integer)guardianShields.getOrDefault(uuid, 0);
    }

    public static void activateGuardianShield(Player player) {
        UUID uuid = player.getUniqueId();
        guardianShields.put(uuid, 3);
        player.sendMessage("§6[超能力] §b守护之盾已激活! 剩余 §e3 §b次,持续消耗饱食度");
        startGuardianHungerTask(player);
    }

    public static void deactivateGuardianShield(Player player) {
        UUID uuid = player.getUniqueId();
        guardianShields.remove(uuid);
        cancelGuardianHungerTask(uuid);
        guardianGiver.remove(uuid);
        player.sendMessage("§6[超能力] §c守护之盾已取消");
        setGuardianCooldown(uuid);
    }

    public static void consumeGuardianShield(UUID uuid) {
        int shields = (Integer)guardianShields.getOrDefault(uuid, 0);
        if (shields > 0) {
            --shields;
            Player player;
            if (shields <= 0) {
                guardianShields.remove(uuid);
                cancelGuardianHungerTask(uuid);
                player = Bukkit.getPlayer(uuid);
                if (player != null) {
                    player.sendMessage("§6[超能力] §c守护之盾已耗尽!");
                }

                setGuardianCooldown(uuid);
                UUID giverUuid = (UUID)guardianGiver.get(uuid);
                if (giverUuid != null) {
                    Player giver = Bukkit.getPlayer(giverUuid);
                    if (giver != null) {
                        giver.sendMessage("§6[超能力] §c你的守护目标护盾已耗尽!");
                    }

                    guardianGivenTo.remove(giverUuid);
                    setGuardianCooldown(giverUuid);
                }
            } else {
                guardianShields.put(uuid, shields);
                player = Bukkit.getPlayer(uuid);
                if (player != null) {
                    player.sendMessage("§6[超能力] §c护盾受到攻击! 剩余 §e" + shields + " §c次");
                }
            }

        }
    }

    public static void startGuardianHungerTask(Player player) {
        UUID uuid = player.getUniqueId();
        cancelGuardianHungerTask(uuid);
        int taskId = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                if (!isGuardianShieldActive(uuid)) {
                    cancelGuardianHungerTask(uuid);
                } else {
                    int foodLevel = p.getFoodLevel();
                    if (foodLevel <= 0) {
                        p.sendMessage("§6[超能力] §c饱食度不足,守护之盾消失!");
                        UUID giverUuid = (UUID)guardianGiver.get(uuid);
                        if (giverUuid != null) {
                            Player giver = Bukkit.getPlayer(giverUuid);
                            if (giver != null) {
                                giver.sendMessage("§6[超能力] §c你的守护目标饱食度不足,护盾消失!");
                            }

                            setGuardianCooldown(giverUuid);
                            guardianGivenTo.remove(giverUuid);
                        }

                        deactivateGuardianShield(p);
                    } else {
                        p.setFoodLevel(Math.max(0, foodLevel - 2));
                    }
                }
            } else {
                cancelGuardianHungerTask(uuid);
            }
        }, 50L, 50L).getTaskId();
        guardianHungerTasks.put(uuid, taskId);
    }

    public static void cancelGuardianHungerTask(UUID uuid) {
        Integer taskId = (Integer)guardianHungerTasks.remove(uuid);
        if (taskId != null) {
            Bukkit.getScheduler().cancelTask(taskId);
        }

    }

    public static void giveGuardianShieldToTarget(Player giver, Player target) {
        UUID targetUuid = target.getUniqueId();
        UUID giverUuid = giver.getUniqueId();
        UUID existingTarget = (UUID)guardianGivenTo.get(giverUuid);
        if (existingTarget != null && !existingTarget.equals(targetUuid)) {
            Player existing = Bukkit.getPlayer(existingTarget);
            if (existing != null && existing.isOnline() && isGuardianShieldActive(existingTarget)) {
                giver.sendMessage("§c你已有守护目标,请先收回再对其他玩家释放!");
                return;
            }

            guardianGivenTo.remove(giverUuid);
            guardianGiver.remove(existingTarget);
            setGuardianCooldown(giverUuid);
        }

        guardianGivenTo.put(giverUuid, targetUuid);
        guardianGiver.put(targetUuid, giverUuid);
        guardianShields.put(targetUuid, 3);
        target.sendMessage("§6[超能力] §b你获得了 §e" + giver.getName() + " §b的守护之盾! 剩余 §e3 §b次,持续消耗饱食度");
        giver.sendMessage("§6[超能力] §a你向 §e" + target.getName() + " §a释放了守护之盾!");
        startGuardianHungerTask(target);
    }

    public static void removeGuardianTargetShield(Player giver, Player target) {
        UUID targetUuid = target.getUniqueId();
        UUID giverUuid = giver.getUniqueId();
        guardianShields.remove(targetUuid);
        cancelGuardianHungerTask(targetUuid);
        guardianGiver.remove(targetUuid);
        guardianGivenTo.remove(giverUuid);
        target.sendMessage("§6[超能力] §c" + giver.getName() + " 收回了你的守护之盾");
        giver.sendMessage("§6[超能力] §c已收回 §e" + target.getName() + " §c的守护之盾");
        setGuardianCooldown(giverUuid);
    }

    public static UUID getGuardianGiver(UUID playerUuid) {
        return (UUID)guardianGiver.get(playerUuid);
    }

    public static UUID getGuardianGivenTarget(UUID giverUuid) {
        return (UUID)guardianGivenTo.get(giverUuid);
    }

    public static void clearGuardianShieldData(UUID uuid) {
        cancelGuardianHungerTask(uuid);
        guardianShields.remove(uuid);
        guardianGiver.remove(uuid);
        guardianGivenTo.values().remove(uuid);
    }

    public static boolean canUseSpartan(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)spartanCooldown.get(player.getUniqueId());
            if (last == null) {
                return true;
            } else {
                long duration = (Long)spartanCooldownDuration.getOrDefault(player.getUniqueId(), 60000L);
                return System.currentTimeMillis() - last >= duration;
            }
        }
    }

    public static void setSpartanCooldown(Player player) {
        spartanCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        spartanCooldownDuration.put(player.getUniqueId(), 60000L);
    }

    public static void resetSpartanCooldown(Player player) {
        spartanCooldown.remove(player.getUniqueId());
        spartanCooldownDuration.remove(player.getUniqueId());
    }

    public static void setSpartanCooldownMillis(Player player, long millis) {
        spartanCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        spartanCooldownDuration.put(player.getUniqueId(), millis);
    }

    public static int getSpartanStrengthLevel(Player player) {
        Long endTime = (Long)spartanStrengthEndTime.get(player.getUniqueId());
        if (endTime != null && System.currentTimeMillis() <= endTime) {
            return (Integer)spartanStrengthLevel.getOrDefault(player.getUniqueId(), 0);
        } else {
            spartanStrengthLevel.remove(player.getUniqueId());
            spartanStrengthEndTime.remove(player.getUniqueId());
            return 0;
        }
    }

    public static void applySpartanStrength(Player player) {
        UUID uuid = player.getUniqueId();
        Long endTime = (Long)spartanStrengthEndTime.get(uuid);
        if (endTime == null || System.currentTimeMillis() > endTime) {
            spartanStrengthLevel.remove(uuid);
            spartanStrengthEndTime.remove(uuid);
        }

        int level = (Integer)spartanStrengthLevel.getOrDefault(uuid, 0) + 1;
        spartanStrengthLevel.put(uuid, level);
        spartanStrengthEndTime.put(uuid, System.currentTimeMillis() + 30000L);
        removeEffect(player, PotionEffectType.STRENGTH);
        addEffect(player, PotionEffectType.STRENGTH, level);
        player.sendMessage("§6[超能力] §a斯巴达之怒! 力量提升至 §e" + level + " §a级(30秒)");
    }

    public static boolean canUseWitherSkill(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)witherSkillCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 5000L;
        }
    }

    public static void setWitherSkillCooldown(Player player) {
        witherSkillCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseDemonFang(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)demonFangCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 5000L;
        }
    }

    public static void setDemonFangCooldown(Player player) {
        demonFangCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseDemonVex(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)demonVexCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 60000L;
        }
    }

    public static void setDemonVexCooldown(Player player) {
        demonVexCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static Set<UUID> getDemonVexUUIDs(UUID playerUUID) {
        return (Set)demonVexUUIDs.getOrDefault(playerUUID, Collections.emptySet());
    }

    public static void addDemonVexUUID(UUID playerUUID, UUID vexUUID) {
        ((Set)demonVexUUIDs.computeIfAbsent(playerUUID, (k) -> {
            return new HashSet();
        })).add(vexUUID);
    }

    public static void removeDemonVexUUID(UUID playerUUID, UUID vexUUID) {
        Set<UUID> vexes = (Set)demonVexUUIDs.get(playerUUID);
        if (vexes != null) {
            vexes.remove(vexUUID);
            if (vexes.isEmpty()) {
                demonVexUUIDs.remove(playerUUID);
            }
        }
    }

    public static int getDemonVexCount(UUID playerUUID) {
        return getDemonVexUUIDs(playerUUID).size();
    }

    public static void removeAllDemonVexes(UUID playerUUID) {
        demonVexUUIDs.remove(playerUUID);
    }

    public static BukkitTask getDemonVexFollowTask(UUID playerUUID) {
        return (BukkitTask)demonVexFollowTasks.get(playerUUID);
    }

    public static void setDemonVexFollowTask(UUID playerUUID, BukkitTask task) {
        demonVexFollowTasks.put(playerUUID, task);
    }

    public static void removeDemonVexFollowTask(UUID playerUUID) {
        demonVexFollowTasks.remove(playerUUID);
    }

    public static boolean isLegionFormationActive(UUID uuid) {
        return (Boolean)legionFormation.getOrDefault(uuid, false);
    }

    public static void setLegionFormation(Player player, boolean active) {
        UUID uuid = player.getUniqueId();
        if (active) {
            legionFormation.put(uuid, true);
            legionSavedSpeed.put(uuid, player.getWalkSpeed());
            player.setWalkSpeed(0.04F);
            startLegionTask(player);
        } else {
            legionFormation.put(uuid, false);
            Integer tid = (Integer)legionTaskId.remove(uuid);
            if (tid != null) {
                Bukkit.getScheduler().cancelTask(tid);
            }

            Float savedSpeed = (Float)legionSavedSpeed.remove(uuid);
            if (savedSpeed != null) {
                player.setWalkSpeed(savedSpeed);
            }

            legionCooldown.put(uuid, System.currentTimeMillis());
            player.sendMessage("§6[超能力] §c罗马防御阵型已解除");
        }

    }

    public static boolean canUseLegion(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)legionCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 60000L;
        }
    }

    private static void startLegionTask(Player player) {
        UUID uuid = player.getUniqueId();
        Integer existing = (Integer)legionTaskId.remove(uuid);
        if (existing != null) {
            Bukkit.getScheduler().cancelTask(existing);
        }

        int taskId = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                if (!(Boolean)legionFormation.getOrDefault(uuid, false)) {
                    legionTaskId.remove(uuid);
                } else if (!p.isSneaking() || p.getInventory().getItemInMainHand().getType() != Material.SHIELD) {
                    setLegionFormation(p, false);
                }
            } else {
                legionFormation.remove(uuid);
                legionTaskId.remove(uuid);
                legionSavedSpeed.remove(uuid);
            }
        }, 1L, 5L).getTaskId();
        legionTaskId.put(uuid, taskId);
    }

    public static boolean canUseCitizen(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)citizenCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 50000L;
        }
    }

    public static void setCitizenCooldown(Player player) {
        citizenCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean isReflectorActive(UUID uuid) {
        Long end = (Long)reflectorEndTime.get(uuid);
        return end != null && System.currentTimeMillis() < end;
    }

    public static void activateReflector(Player player) {
        UUID uuid = player.getUniqueId();
        reflectorEndTime.put(uuid, System.currentTimeMillis() + 10000L);
        startReflectorParticleTask(player);
        player.sendMessage("§6[超能力] §b反射屏障已开启! 持续10秒");
    }

    public static void deactivateReflector(Player player) {
        UUID uuid = player.getUniqueId();
        reflectorEndTime.remove(uuid);
        Integer taskId = (Integer)reflectorParticleTask.remove(uuid);
        if (taskId != null) {
            Bukkit.getScheduler().cancelTask(taskId);
        }

        reflectorCooldown.put(uuid, System.currentTimeMillis());
        player.sendMessage("§6[超能力] §c反射屏障已关闭");
    }

    public static boolean canUseReflector(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)reflectorCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 60000L;
        }
    }

    private static void startReflectorParticleTask(Player player) {
        UUID uuid = player.getUniqueId();
        Integer existing = (Integer)reflectorParticleTask.remove(uuid);
        if (existing != null) {
            Bukkit.getScheduler().cancelTask(existing);
        }

        int taskId = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline() && isReflectorActive(uuid)) {
                p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0.0, 1.0, 0.0), 15, 1.5, 1.5, 1.5, 0.01);
            } else {
                Integer tid = (Integer)reflectorParticleTask.remove(uuid);
                if (tid != null) {
                    Bukkit.getScheduler().cancelTask(tid);
                }

            }
        }, 0L, 5L).getTaskId();
        reflectorParticleTask.put(uuid, taskId);
    }

    public static boolean canUseElfRanger(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)elfRangerCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 500L;
        }
    }

    public static void setElfRangerCooldown(Player player) {
        elfRangerCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean isRecallPassiveUsed(UUID uuid) {
        return recallPassiveUsed.contains(uuid);
    }

    public static void setRecallPassiveUsed(UUID uuid) {
        recallPassiveUsed.add(uuid);
    }

    public static boolean canUseLightningKing(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)lightningKingCooldown.get(player.getUniqueId());
            if (last != null) {
                long remaining = (last + 5000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c雷电法王冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }
            return true;
        }
    }

    public static void setLightningKingCooldown(Player player) {
        lightningKingCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseLightningKingMass(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)lightningKingMassCooldown.get(player.getUniqueId());
            if (last != null) {
                long remaining = (last + 40000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c雷电法王五雷轰顶冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }
            return true;
        }
    }

    public static void setLightningKingMassCooldown(Player player) {
        lightningKingMassCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseWitchKin(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)witchKinCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 10000L;
        }
    }

    public static void setWitchKinCooldown(Player player) {
        witchKinCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseWitchRegen(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)witchRegenCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 30000L;
        }
    }

    public static void setWitchRegenCooldown(Player player) {
        witchRegenCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseElfRangerTracking(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)elfRangerTrackingCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 15000L;
        }
    }

    public static void setElfRangerTrackingCooldown(Player player) {
        elfRangerTrackingCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseSentinel(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)sentinelCooldown.get(player.getUniqueId());
            if (last != null) {
                long remaining = (last + 70000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c炮塔冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }
            return true;
        }
    }

    public static void setSentinelCooldown(Player player) {
        sentinelCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canUseSummoner(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)summonerCooldown.get(player.getUniqueId());
            if (last != null) {
                long remaining = (last + 30000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c召集冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }
            return true;
        }
    }

    public static void setSummonerCooldown(Player player) {
        summonerCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static void addRedeemerPaper(Player player, String deadName) {
        redeemerPapers.computeIfAbsent(player.getUniqueId(), k -> new HashSet()).add(deadName);
    }

    public static boolean hasRedeemerPaper(Player player, String deadName) {
        Set<String> papers = redeemerPapers.get(player.getUniqueId());
        return papers != null && papers.contains(deadName);
    }

    public static Set<String> getRedeemerPapers(Player player) {
        return redeemerPapers.getOrDefault(player.getUniqueId(), new HashSet());
    }

    public static void removeRedeemerPaper(Player player, String deadName) {
        Set<String> papers = redeemerPapers.get(player.getUniqueId());
        if (papers != null) {
            papers.remove(deadName);
            if (papers.isEmpty()) {
                redeemerPapers.remove(player.getUniqueId());
            }
        }
    }

    public static int getRedeemerCooldownSeconds(Player player) {
        int count = redeemerUseCount.getOrDefault(player.getUniqueId(), 0);
        return 180 + count * 120;
    }

    public static boolean canUseRedeemer(Player player) {
        if (hasNoCooldown(player.getUniqueId())) return true;
        Long last = redeemerCooldown.get(player.getUniqueId());
        if (last != null) {
            int cd = getRedeemerCooldownSeconds(player);
            long remaining = (last + cd * 1000L - System.currentTimeMillis()) / 1000L;
            if (remaining > 0L) {
                player.sendMessage("§c救赎冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                return false;
            }
        }
        return true;
    }

    public static void setRedeemerCooldown(Player player) {
        redeemerCooldown.put(player.getUniqueId(), System.currentTimeMillis());
        redeemerUseCount.merge(player.getUniqueId(), 1, Integer::sum);
    }

    public static void addRedeemerTask(UUID uuid, BukkitTask task) {
        BukkitTask existing = redeemerTasks.remove(uuid);
        if (existing != null) existing.cancel();
        redeemerTasks.put(uuid, task);
    }

    public static void cancelRedeemerTask(UUID uuid) {
        BukkitTask task = redeemerTasks.remove(uuid);
        if (task != null) task.cancel();
    }

    public static void saveRedeemerSpeed(Player player) {
        redeemerSavedSpeed.put(player.getUniqueId(), player.getWalkSpeed());
    }

    public static void restoreRedeemerSpeed(Player player) {
        Float speed = redeemerSavedSpeed.remove(player.getUniqueId());
        if (speed != null) {
            player.setWalkSpeed(speed);
        }
    }

    public static void addSentinelArmorStand(UUID playerUuid, UUID standUuid) {
        ((Set)sentinelArmorStands.computeIfAbsent(playerUuid, (k) -> {
            return new HashSet();
        })).add(standUuid);
    }

    public static void removeSentinelArmorStand(UUID playerUuid, UUID standUuid) {
        Set<UUID> stands = (Set)sentinelArmorStands.get(playerUuid);
        if (stands != null) {
            stands.remove(standUuid);
            if (stands.isEmpty()) {
                sentinelArmorStands.remove(playerUuid);
            }
        }
        sentinelHits.remove(standUuid);
    }

    public static void addSentinelTask(UUID playerUuid, BukkitTask task) {
        ((Set)sentinelTasks.computeIfAbsent(playerUuid, (k) -> {
            return new HashSet();
        })).add(task);
    }

    public static void removeSentinelTask(UUID playerUuid, BukkitTask task) {
        Set<BukkitTask> tasks = (Set)sentinelTasks.get(playerUuid);
        if (tasks != null) {
            tasks.remove(task);
            if (tasks.isEmpty()) {
                sentinelTasks.remove(playerUuid);
            }
        }
    }

    public static int getSentinelHits(UUID standUuid) {
        return (Integer)sentinelHits.getOrDefault(standUuid, 0);
    }

    public static void incrementSentinelHits(UUID standUuid) {
        sentinelHits.put(standUuid, getSentinelHits(standUuid) + 1);
    }

    public static void resetSentinelHits(UUID standUuid) {
        sentinelHits.remove(standUuid);
    }

    public static boolean canIceSkill(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)iceManSkillCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 5000L;
        }
    }

    public static void setIceSkillCooldown(Player player) {
        iceManSkillCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canThrowPearl(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)enderlingSkillCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 1000L;
        }
    }

    public static void setPearlCooldown(Player player) {
        enderlingSkillCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canShootWeb(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)spiderManWebCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 2000L;
        }
    }

    public static void setWebCooldown(Player player) {
        spiderManWebCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canPullWeb(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)spiderManPullCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 2000L;
        }
    }

    public static void setPullCooldown(Player player) {
        spiderManPullCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canStealItem(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)thiefItemCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 10000L;
        }
    }

    public static void setItemStealCooldown(Player player) {
        thiefItemCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean canStealLife(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long last = (Long)thiefLifeCooldown.get(player.getUniqueId());
            return last == null || System.currentTimeMillis() - last >= 30000L;
        }
    }

    public static void setLifeStealCooldown(Player player) {
        thiefLifeCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static PotionEffectType getStolenBuff(UUID uuid) {
        return (PotionEffectType)thiefStolenBuff.get(uuid);
    }

    public static void setStolenBuff(UUID uuid, PotionEffectType effect) {
        thiefStolenBuff.put(uuid, effect);
    }

    public static void removeStolenBuff(UUID uuid) {
        thiefStolenBuff.remove(uuid);
    }

    public static boolean canUseGodsLeftHand(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long lastUse = (Long)godsLeftHandCooldown.get(player.getUniqueId());
            if (lastUse != null) {
                long remaining = (lastUse + 10000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c神之左手冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }

            return true;
        }
    }

    public static void setGodsLeftHandCooldown(Player player) {
        godsLeftHandCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static boolean isAbilityDisabledByGodsLeftHand(UUID playerId) {
        return godsLeftHandDisabledPlayers.contains(playerId);
    }

    public static void disablePlayerAbilities(Player player) {
        UUID uuid = player.getUniqueId();
        if (!godsLeftHandDisabledPlayers.contains(uuid)) {
            godsLeftHandDisabledPlayers.add(uuid);
            BukkitTask existingTask = (BukkitTask)godsLeftHandRestoreTasks.remove(uuid);
            if (existingTask != null) {
                existingTask.cancel();
            }

            Map<UUID, Long>[] cooldownMaps = new Map[]{mindControlCooldown, timeStopCooldowns, fairyDebuffCooldown, bigStomachEatCooldown, bigStomachAnimalCooldown, natureChildTreeCooldown, bomberCooldown, fireManSkillCooldown, iceManSkillCooldown, enderlingSkillCooldown, spiderManWebCooldown, spiderManPullCooldown, thiefItemCooldown, thiefLifeCooldown};
            Map[] var4 = cooldownMaps;
            int var5 = cooldownMaps.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                Map<UUID, Long> map = var4[var6];
                Long stored = (Long)map.get(uuid);
                if (stored != null) {
                    map.put(uuid, stored + 10000L);
                }
            }

            AbilityType ability = getAbility(player);
            if (ability != null) {
                removeAbilityEffectsOnly(player, ability);
            }

            player.sendMessage("§c☠ §4你的超能力已被神之左手封印10秒!");
        }
    }

    public static void enablePlayerAbilities(Player player) {
        UUID uuid = player.getUniqueId();
        if (godsLeftHandDisabledPlayers.contains(uuid)) {
            godsLeftHandDisabledPlayers.remove(uuid);
            BukkitTask existingTask = (BukkitTask)godsLeftHandRestoreTasks.remove(uuid);
            if (existingTask != null) {
                existingTask.cancel();
            }

            Map<UUID, Long>[] cooldownMaps = new Map[]{mindControlCooldown, timeStopCooldowns, fairyDebuffCooldown, bigStomachEatCooldown, bigStomachAnimalCooldown, natureChildTreeCooldown, bomberCooldown, fireManSkillCooldown, iceManSkillCooldown, enderlingSkillCooldown, spiderManWebCooldown, spiderManPullCooldown, thiefItemCooldown, thiefLifeCooldown};
            Map[] var4 = cooldownMaps;
            int var5 = cooldownMaps.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                Map<UUID, Long> map = var4[var6];
                Long stored = (Long)map.get(uuid);
                if (stored != null) {
                    map.put(uuid, Math.max(stored - 10000L, 0L));
                }
            }

            AbilityType ability = getAbility(player);
            if (ability != null) {
                applyAbilityEffects(player, ability);
            }

            player.sendMessage("§a✓ §b你的超能力已恢复!");
        }
    }

    public static void scheduleGodsLeftHandRestore(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask task = Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null && p.isOnline()) {
                enablePlayerAbilities(p);
            } else {
                godsLeftHandDisabledPlayers.remove(uuid);
                godsLeftHandRestoreTasks.remove(uuid);
            }

        }, 200L);
        godsLeftHandRestoreTasks.put(uuid, task);
    }

    public static Map<UUID, Long> getGodsLeftHandCooldown() {
        return godsLeftHandCooldown;
    }

    public static boolean canUseFieldWeaver(Player player) {
        if (hasNoCooldown(player.getUniqueId())) {
            return true;
        } else {
            Long lastUse = (Long)fieldWeaverCooldown.get(player.getUniqueId());
            if (lastUse != null) {
                long remaining = (lastUse + 60000L - System.currentTimeMillis()) / 1000L;
                if (remaining > 0L) {
                    player.sendMessage("§c立场编织者冷却中! 剩余 §e" + (remaining + 1L) + " §c秒");
                    return false;
                }
            }

            return true;
        }
    }

    public static void setFieldWeaverCooldown(Player player) {
        fieldWeaverCooldown.put(player.getUniqueId(), System.currentTimeMillis());
    }

    public static void startFieldWeaver(Player player) {
        UUID uuid = player.getUniqueId();
        stopFieldWeaver(uuid);
        Location center = player.getLocation().clone();
        long expireTime = System.currentTimeMillis() + 10000L;
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(Main.getInstance(), () -> {
            if (System.currentTimeMillis() >= expireTime) {
                stopFieldWeaver(uuid);
            } else if (!player.isOnline()) {
                stopFieldWeaver(uuid);
            } else {
                applyFieldWeaverEffects(player, center);
            }
        }, 0L, 5L);
        FieldWeaverData data = new FieldWeaverData(center, center.getWorld(), expireTime, uuid, task);
        fieldWeaverActiveFields.put(uuid, data);
        player.sendMessage("§d✦ §5你展开了立场编织区域! 持续10秒");
    }

    public static void stopFieldWeaver(UUID uuid) {
        FieldWeaverData data = (FieldWeaverData)fieldWeaverActiveFields.remove(uuid);
        if (data != null) {
            if (data.task != null) {
                data.task.cancel();
            }

            Set<UUID> toRestore = new HashSet(fieldWeaverAffectedPlayers);
            Iterator var3 = toRestore.iterator();

            while(true) {
                while(var3.hasNext()) {
                    UUID affectedUuid = (UUID)var3.next();
                    Player affected = Bukkit.getPlayer(affectedUuid);
                    if (affected != null && affected.isOnline()) {
                        if (!isInAnyActiveField(affected.getLocation())) {
                            restoreFieldWeaverPlayer(affected);
                            fieldWeaverAffectedPlayers.remove(affectedUuid);
                        }
                    } else {
                        fieldWeaverAffectedPlayers.remove(affectedUuid);
                        fieldWeaverPreFlight.remove(affectedUuid);
                    }
                }

                return;
            }
        }
    }

    private static boolean isInAnyActiveField(Location location) {
        if (location != null && location.getWorld() != null) {
            Iterator var1 = fieldWeaverActiveFields.values().iterator();

            while(var1.hasNext()) {
                FieldWeaverData field = (FieldWeaverData)var1.next();
                if (location.getWorld().equals(field.world)) {
                    double dx = location.getX() - field.center.getX();
                    double dz = location.getZ() - field.center.getZ();
                    if (dx * dx + dz * dz <= 56.25) {
                        return true;
                    }
                }
            }

            return false;
        } else {
            return false;
        }
    }

    private static void applyFieldWeaverEffects(Player caster, Location center) {
        World world = center.getWorld();
        Iterator var3 = Bukkit.getOnlinePlayers().iterator();

        while(true) {
            Player player;
            AbilityType ability;
            do {
                while(true) {
                    do {
                        do {
                            if (!var3.hasNext()) {
                                return;
                            }

                            player = (Player)var3.next();
                        } while(player.equals(caster) || isSameBattleTeam(caster, player));
                    } while(!player.getWorld().equals(world));

                    Location pLoc = player.getLocation();
                    double dx = pLoc.getX() - center.getX();
                    double dz = pLoc.getZ() - center.getZ();
                    double distSq = dx * dx + dz * dz;
                    double radiusSq = 56.25;
                    if (distSq <= radiusSq) {
                        fieldWeaverAffectedPlayers.add(player.getUniqueId());
                        if (player.getAllowFlight() || player.isFlying()) {
                            fieldWeaverPreFlight.putIfAbsent(player.getUniqueId(), player.getAllowFlight());
                            player.setAllowFlight(false);
                            player.setFlying(false);
                        }

                        removeEffect(player, PotionEffectType.SPEED);
                        ability = getAbility(player);
                        if (ability == AbilityType.FLASH) {
                            AttributeInstance attr = player.getAttribute(Attribute.MOVEMENT_SPEED);
                            if (attr != null) {
                                attr.setBaseValue(0.1);
                            }

                            player.setWalkSpeed(0.2F);
                        }
                        break;
                    }

                    if (fieldWeaverAffectedPlayers.contains(player.getUniqueId()) && !isInAnyActiveField(player.getLocation())) {
                        restoreFieldWeaverPlayer(player);
                        fieldWeaverAffectedPlayers.remove(player.getUniqueId());
                        fieldWeaverPreFlight.remove(player.getUniqueId());
                    }
                }
            } while(ability != AbilityType.SUPERMAN && ability != AbilityType.FAIRY);

            addEffect(player, PotionEffectType.SLOWNESS, 2);
        }
    }

    public static void restoreFieldWeaverPlayer(Player player) {
        removeEffect(player, PotionEffectType.SLOWNESS);
        AbilityType ability = getAbility(player);
        if (ability == AbilityType.FLASH) {
            AttributeInstance attr = player.getAttribute(Attribute.MOVEMENT_SPEED);
            if (attr != null) {
                attr.setBaseValue(0.7);
            }

            player.setWalkSpeed(0.2F);
        }

        Boolean hadFlight = (Boolean)fieldWeaverPreFlight.remove(player.getUniqueId());
        if (hadFlight != null) {
            player.setAllowFlight(true);
        }

        if (ability == AbilityType.SUPERMAN) {
            addEffect(player, PotionEffectType.STRENGTH, 0);
            addEffect(player, PotionEffectType.RESISTANCE, 1);
        }

    }

    public static boolean isPlayerInFieldWeaverZone(UUID playerId) {
        return fieldWeaverAffectedPlayers.contains(playerId);
    }

    public static Map<UUID, FieldWeaverData> getFieldWeaverActiveFields() {
        return fieldWeaverActiveFields;
    }

    public static Set<UUID> getFieldWeaverAffectedPlayers() {
        return fieldWeaverAffectedPlayers;
    }

    public static Map<UUID, Long> getFieldWeaverCooldown() {
        return fieldWeaverCooldown;
    }

    public static boolean isSameBattleTeam(Player p1, Player p2) {
        for (String tag : p1.getScoreboardTags()) {
            if (tag.startsWith("battle_team_") && p2.getScoreboardTags().contains(tag)) {
                return true;
            }
        }
        return false;
    }

    private static class EntityState {
        Location location;
        boolean isProjectile = false;
        Vector originalVelocity;
        boolean hasAI = false;
        boolean ai = false;
        boolean hasGravity = false;
        boolean gravity = false;

        private EntityState() {
        }
    }

    private static class PlayerState {
        float walkSpeed;
        float flySpeed;
        boolean allowFlight;
        boolean isFlying;
        Location location;

        private PlayerState() {
        }
    }

    public static class AccumulatedDamage {
        double damage = 0.0;
        Entity damager = null;

        public AccumulatedDamage() {
        }
    }

    public static class FieldWeaverData {
        public Location center;
        public World world;
        public long expireTime;
        public UUID casterId;
        public BukkitTask task;

        public FieldWeaverData(Location center, World world, long expireTime, UUID casterId, BukkitTask task) {
            this.center = center;
            this.world = world;
            this.expireTime = expireTime;
            this.casterId = casterId;
            this.task = task;
        }
    }

    static class PrisonBlock {
        final World world;
        final int x;
        final int y;
        final int z;

        PrisonBlock(World world, int x, int y, int z) {
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    public static UUID getEntityOwner(Entity entity) {
        if (entity == null) return null;
        PersistentDataContainer pdc = entity.getPersistentDataContainer();

        if (summonedKey != null) {
            String id = pdc.get(summonedKey, PersistentDataType.STRING);
            if (id != null) return UUID.fromString(id);
        }

        NamespacedKey vexKey = new NamespacedKey(Main.getInstance(), "vex_owner");
        String vexOwner = pdc.get(vexKey, PersistentDataType.STRING);
        if (vexOwner != null) return UUID.fromString(vexOwner);

        NamespacedKey fangKey = new NamespacedKey(Main.getInstance(), "fang_caster");
        String fangOwner = pdc.get(fangKey, PersistentDataType.STRING);
        if (fangOwner != null) return UUID.fromString(fangOwner);

        return null;
    }

    public static void setForcedKiller(UUID victim, UUID killer) {
        forcedKillers.put(victim, killer);
    }

    public static UUID getForcedKiller(UUID victim) {
        return forcedKillers.remove(victim);
    }
}
