

package com.cnl.abilities.mindcontrol;

import java.lang.reflect.Constructor;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class MindControlManager {
    private static MindControlManager instance;
    private final Plugin plugin;
    private final Map<UUID, ControlSession> activeSessions = new ConcurrentHashMap();
    private Constructor<?> cameraPacketConstructor;
    private static final int CONTROL_DURATION_TICKS = 100;

    private MindControlManager(Plugin plugin) {
        this.plugin = plugin;
        this.initCameraPacket();
    }

    public static MindControlManager getInstance() {
        return instance;
    }

    public static void init(Plugin plugin) {
        if (instance == null) {
            instance = new MindControlManager(plugin);
        }

    }

    private void initCameraPacket() {
        try {
            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.PacketPlayOutCamera");
            this.cameraPacketConstructor = packetClass.getConstructor(Integer.TYPE);
        } catch (Exception var2) {
        }

    }

    public void sendCameraPacket(Player viewer, int entityId) {
        if (this.cameraPacketConstructor != null) {
            try {
                Object packet = this.cameraPacketConstructor.newInstance(entityId);
                Object handle = viewer.getClass().getMethod("getHandle").invoke(viewer);
                Object connection = handle.getClass().getField("connection").get(handle);
                connection.getClass().getMethod("a", packet.getClass()).invoke(connection, packet);
            } catch (Exception var6) {
            }

        }
    }

    public void resetCamera(Player viewer) {
        this.sendCameraPacket(viewer, viewer.getEntityId());
    }

    public ControlState startControl(Player controller, Player target) {
        if (target != null && target.isOnline()) {
            if (controller.equals(target)) {
                return MindControlManager.ControlState.INVALID_TARGET;
            } else if (this.isControlling(controller.getUniqueId())) {
                return MindControlManager.ControlState.ALREADY_CONTROLLING;
            } else if (this.isControlled(target.getUniqueId())) {
                return MindControlManager.ControlState.ALREADY_CONTROLLED;
            } else {
                ControlSession session = new ControlSession(controller, target);
                session.setControllerSnapshot(new PlayerStateSnapshot(controller));
                session.setTargetSnapshot(new PlayerStateSnapshot(target));
                this.hideControllerFromAll(controller);
                controller.teleport(target.getLocation().add(0.0, 0.5, 0.0));
                target.setWalkSpeed(0.0F);
                target.setFlySpeed(0.0F);
                target.setCollidable(false);
                this.activeSessions.put(controller.getUniqueId(), session);
                this.startSyncTask(session);
                this.startReleaseTimer(session);
                controller.sendMessage("§5[灵魂控制] §a你已控制 §e" + target.getName() + " §a(持续5秒)");
                target.sendMessage("§5[灵魂控制] §c你已被 §e" + controller.getName() + " §c控制!");
                return MindControlManager.ControlState.SUCCESS;
            }
        } else {
            return MindControlManager.ControlState.OFFLINE;
        }
    }

    private void startSyncTask(ControlSession session) {
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (session.isActive()) {
                Player controller = Bukkit.getPlayer(session.getControllerId());
                Player target = Bukkit.getPlayer(session.getTargetId());
                if (controller != null && controller.isOnline() && target != null && target.isOnline()) {
                    Location cLoc = controller.getLocation();
                    if (cLoc.distanceSquared(target.getLocation()) > 0.25) {
                        target.teleport(new Location(cLoc.getWorld(), cLoc.getX(), cLoc.getY(), cLoc.getZ(), cLoc.getYaw(), cLoc.getPitch()));
                    }

                    if (!target.isOnGround() && target.getLocation().getY() > (double)(target.getWorld().getMinHeight() + 2)) {
                        if (!target.getAllowFlight()) {
                            target.setAllowFlight(true);
                        }

                        if (!target.isFlying()) {
                            target.setFlying(true);
                        }
                    } else if (target.isOnGround() && target.isFlying()) {
                        target.setFlying(false);
                    }

                } else {
                    this.releaseControlInner(controller, session, true);
                }
            }
        }, 1L, 1L);
        session.setSyncTask(task);
    }

    private void startReleaseTimer(ControlSession session) {
        BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            Player controller = Bukkit.getPlayer(session.getControllerId());
            if (controller != null && controller.isOnline()) {
                this.releaseControl(controller);
                controller.sendMessage("§5[灵魂控制] §e控制时间已到!");
            } else {
                this.releaseControlInner((Player)null, session, true);
            }

        }, 100L);
        session.setReleaseTask(task);
    }

    public boolean releaseControl(Player controller) {
        ControlSession session = (ControlSession)this.activeSessions.get(controller.getUniqueId());
        if (session == null) {
            return false;
        } else {
            Player target = Bukkit.getPlayer(session.getTargetId());
            controller.sendMessage("§5[灵魂控制] §a已解除对 §e" + session.getTargetName() + " §a的控制");
            if (target != null && target.isOnline()) {
                target.sendMessage("§5[灵魂控制] §a你已摆脱控制!");
            }

            return this.releaseControlInner(controller, session, false);
        }
    }

    public boolean releaseControlByTarget(Player target) {
        Iterator var2 = this.activeSessions.values().iterator();

        ControlSession session;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            session = (ControlSession)var2.next();
        } while(!session.getTargetId().equals(target.getUniqueId()));

        Player controller = Bukkit.getPlayer(session.getControllerId());
        return this.releaseControlInner(controller, session, false);
    }

    public void releaseControlByControllerUUID(UUID controllerId) {
        ControlSession session = (ControlSession)this.activeSessions.get(controllerId);
        if (session != null) {
            Player controller = Bukkit.getPlayer(controllerId);
            this.releaseControlInner(controller, session, true);
        }

    }

    private boolean releaseControlInner(Player controller, ControlSession session, boolean silent) {
        if (session != null && session.isActive()) {
            session.setActive(false);
            session.cancelAllTasks();
            session.setInventoryOpen(false);
            if (controller != null && controller.isOnline()) {
                PlayerStateSnapshot snapshot = session.getControllerSnapshot();
                if (snapshot != null) {
                    snapshot.restore(controller);
                }

                this.showControllerToAll(controller);
                controller.updateInventory();
            }

            Player target = Bukkit.getPlayer(session.getTargetId());
            if (target != null && target.isOnline()) {
                PlayerStateSnapshot snapshot = session.getTargetSnapshot();
                if (snapshot == null) {
                    target.setWalkSpeed(0.2F);
                    target.setFlySpeed(0.1F);
                    target.setCollidable(true);
                } else {
                    target.setWalkSpeed(snapshot.getWalkSpeed());
                    target.setFlySpeed(snapshot.getFlySpeed());
                    target.setCollidable(snapshot.isCollidable());
                    target.setAllowFlight(snapshot.isAllowFlight());
                    target.setFlying(snapshot.isAllowFlight() && snapshot.isFlying() && snapshot.getGameMode() != GameMode.SPECTATOR);
                }

                target.updateInventory();
            }

            this.activeSessions.remove(session.getControllerId());
            return true;
        } else {
            return false;
        }
    }

    public void releaseAll() {
        Iterator var1 = this.activeSessions.values().iterator();

        while(var1.hasNext()) {
            ControlSession session = (ControlSession)var1.next();
            Player controller = Bukkit.getPlayer(session.getControllerId());
            this.releaseControlInner(controller, session, true);
        }

        this.activeSessions.clear();
    }

    public void openTargetInventory(Player controller) {
        ControlSession session = (ControlSession)this.activeSessions.get(controller.getUniqueId());
        if (session != null) {
            Player target = Bukkit.getPlayer(session.getTargetId());
            if (target != null && target.isOnline()) {
                PlayerInventory targetInv = target.getInventory();
                Inventory gui = Bukkit.createInventory((InventoryHolder)null, 45, "§8[§5灵魂控制§8] §7" + session.getTargetName());
                ItemStack borderItem = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
                ItemMeta meta = borderItem.getItemMeta();
                if (meta != null) {
                    meta.setDisplayName("§r");
                    borderItem.setItemMeta(meta);
                }

                ItemStack helm = targetInv.getHelmet();
                ItemStack chest = targetInv.getChestplate();
                ItemStack legs = targetInv.getLeggings();
                ItemStack boots = targetInv.getBoots();
                ItemStack offhand = targetInv.getItemInOffHand();
                if (helm != null) {
                    gui.setItem(0, helm.clone());
                }

                if (chest != null) {
                    gui.setItem(1, chest.clone());
                }

                if (legs != null) {
                    gui.setItem(2, legs.clone());
                }

                if (boots != null) {
                    gui.setItem(3, boots.clone());
                }

                if (offhand != null) {
                    gui.setItem(4, offhand.clone());
                }

                int i;
                for(i = 5; i <= 8; ++i) {
                    gui.setItem(i, borderItem.clone());
                }

                ItemStack item;
                for(i = 9; i < 36; ++i) {
                    item = targetInv.getItem(i);
                    if (item != null) {
                        gui.setItem(i, item.clone());
                    }
                }

                for(i = 0; i < 9; ++i) {
                    item = targetInv.getItem(i);
                    if (item != null) {
                        gui.setItem(36 + i, item.clone());
                    }
                }

                session.setInventoryGui(gui);
                session.setInventoryOpen(true);
                controller.openInventory(gui);
            } else {
                controller.sendMessage("§c目标已离线!");
            }
        }
    }

    public void syncInventoryToTarget(Inventory gui, Player target) {
        if (target != null && target.isOnline()) {
            PlayerInventory targetInv = target.getInventory();
            ItemStack helmItem = gui.getItem(0);
            ItemStack chestItem = gui.getItem(1);
            ItemStack legsItem = gui.getItem(2);
            ItemStack bootsItem = gui.getItem(3);
            ItemStack offhandItem = gui.getItem(4);
            targetInv.setHelmet(helmItem != null && helmItem.getType() != Material.AIR ? helmItem : null);
            targetInv.setChestplate(chestItem != null && chestItem.getType() != Material.AIR ? chestItem : null);
            targetInv.setLeggings(legsItem != null && legsItem.getType() != Material.AIR ? legsItem : null);
            targetInv.setBoots(bootsItem != null && bootsItem.getType() != Material.AIR ? bootsItem : null);
            targetInv.setItemInOffHand(offhandItem != null && offhandItem.getType() != Material.AIR ? offhandItem : null);

            int i;
            ItemStack item;
            for(i = 9; i < 36; ++i) {
                item = gui.getItem(i);
                targetInv.setItem(i, item != null && item.getType() != Material.AIR ? item : null);
            }

            for(i = 0; i < 9; ++i) {
                item = gui.getItem(36 + i);
                targetInv.setItem(i, item != null && item.getType() != Material.AIR ? item : null);
            }

        }
    }

    public boolean isControlling(UUID playerId) {
        return this.activeSessions.containsKey(playerId);
    }

    public boolean isControlled(UUID playerId) {
        Iterator var2 = this.activeSessions.values().iterator();

        ControlSession session;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            session = (ControlSession)var2.next();
        } while(!session.getTargetId().equals(playerId));

        return true;
    }

    public Player getTarget(Player controller) {
        ControlSession session = (ControlSession)this.activeSessions.get(controller.getUniqueId());
        return session == null ? null : Bukkit.getPlayer(session.getTargetId());
    }

    public Player getController(Player target) {
        Iterator var2 = this.activeSessions.values().iterator();

        ControlSession session;
        do {
            if (!var2.hasNext()) {
                return null;
            }

            session = (ControlSession)var2.next();
        } while(!session.getTargetId().equals(target.getUniqueId()));

        return Bukkit.getPlayer(session.getControllerId());
    }

    public ControlSession getSessionByController(UUID playerId) {
        return (ControlSession)this.activeSessions.get(playerId);
    }

    public boolean isInventoryOpen(UUID controllerId) {
        ControlSession session = (ControlSession)this.activeSessions.get(controllerId);
        return session != null && session.isInventoryOpen();
    }

    public void setInventoryClosed(UUID controllerId) {
        ControlSession session = (ControlSession)this.activeSessions.get(controllerId);
        if (session != null) {
            session.setInventoryOpen(false);
            session.setInventoryGui((Inventory)null);
        }

    }

    private void hideControllerFromAll(Player controller) {
        Iterator var2 = Bukkit.getOnlinePlayers().iterator();

        while(var2.hasNext()) {
            Player p = (Player)var2.next();
            p.hidePlayer(this.plugin, controller);
        }

    }

    private void showControllerToAll(Player controller) {
        Iterator var2 = Bukkit.getOnlinePlayers().iterator();

        while(var2.hasNext()) {
            Player p = (Player)var2.next();
            p.showPlayer(this.plugin, controller);
        }

    }

    public void hideAllControllersFrom(Player player) {
        Iterator var2 = this.activeSessions.values().iterator();

        while(var2.hasNext()) {
            ControlSession session = (ControlSession)var2.next();
            Player c = Bukkit.getPlayer(session.getControllerId());
            if (c != null && c.isOnline()) {
                player.hidePlayer(this.plugin, c);
            }
        }

    }

    public Plugin getPlugin() {
        return this.plugin;
    }

    public static enum ControlState {
        SUCCESS,
        OFFLINE,
        ALREADY_CONTROLLING,
        ALREADY_CONTROLLED,
        COOLDOWN,
        INVALID_TARGET;

        private ControlState() {
        }
    }
}
