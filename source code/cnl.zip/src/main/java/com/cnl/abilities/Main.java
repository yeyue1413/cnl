

package com.cnl.abilities;

import com.cnl.abilities.commands.AbilityCommand;
import com.cnl.abilities.listeners.MindControlListener;
import com.cnl.abilities.listeners.TimeStopListener;
import com.cnl.abilities.mindcontrol.MindControlManager;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {
    private static Main instance;

    public Main() {
    }

    public void onEnable() {
        instance = this;
        InvisibleEquipmentManager.init();
        this.getServer().getPluginManager().registerEvents(new AbilityListener(), this);
        this.getServer().getPluginManager().registerEvents(new TimeStopListener(), this);
        this.getServer().getPluginManager().registerEvents(new MindControlListener(), this);
        this.getCommand("cnl").setExecutor(new AbilityCommand());
        this.getCommand("cnl").setTabCompleter(new AbilityCommand());
        this.getServer().getScheduler().runTaskTimer(this, AbilityListener::followTask, 0L, 20L);
        MindControlManager.init(this);
        this.getLogger().info("Abilities plugin has been enabled!");
    }

    public void onDisable() {
        MindControlManager mm = MindControlManager.getInstance();
        if (mm != null) {
            mm.releaseAll();
        }

        this.getLogger().info("Abilities plugin has been disabled!");
    }

    public static Main getInstance() {
        return instance;
    }
}
