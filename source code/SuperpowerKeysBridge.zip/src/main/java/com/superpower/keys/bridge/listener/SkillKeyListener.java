package com.superpower.keys.bridge.listener;

import com.cnl.abilities.AbilityListener;
import com.cnl.abilities.AbilityManager;
import com.cnl.abilities.AbilityType;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class SkillKeyListener implements PluginMessageListener {

    private enum FBehavior {
        NORMAL_F,
        SNEAK_F,
        ITEM_F,
        VIEW_SOULS,
        SUMMON_SOUL,
        SUMMON_ALL_SOUL,
        MIND_CONTROL,
        MIND_INVENTORY,
        MIND_RELEASE,
        TOGGLE_ICE
    }

    private static final Map<AbilityType, FBehavior[]> BEHAVIOR_MAP = createBehaviorMap();

    private static Map<AbilityType, FBehavior[]> createBehaviorMap() {
        Map<AbilityType, FBehavior[]> map = new HashMap<>();

        map.put(AbilityType.ANT_MAN,        new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.FIRE_MAN,       new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.RECALL,         new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.GUARDIAN,       new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.BIG_STOMACH,    new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.DEMON_SUMMONER, new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.ELF_RANGER,     new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.WITCH_KIN,      new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});
        map.put(AbilityType.LIGHTNING_KING, new FBehavior[]{FBehavior.NORMAL_F, FBehavior.SNEAK_F});

        map.put(AbilityType.MIND_CONTROL,   new FBehavior[]{FBehavior.MIND_CONTROL, FBehavior.MIND_INVENTORY, FBehavior.MIND_RELEASE});
        map.put(AbilityType.SOUL_SUMMONER,  new FBehavior[]{FBehavior.VIEW_SOULS, FBehavior.SUMMON_SOUL, FBehavior.SUMMON_ALL_SOUL});

        map.put(AbilityType.ICE_MAN,        new FBehavior[]{FBehavior.NORMAL_F, FBehavior.TOGGLE_ICE});

        map.put(AbilityType.SPIDER_MAN,     new FBehavior[]{FBehavior.NORMAL_F, FBehavior.ITEM_F});

        map.put(AbilityType.BLACKSMITH,     new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.RICH_MAN,       new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.ORE_EATER,      new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.GOD_LEFT_HAND,  new FBehavior[]{FBehavior.NORMAL_F});

        map.put(AbilityType.SENTINEL,       new FBehavior[]{FBehavior.SNEAK_F});

        map.put(AbilityType.FLASH,          new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.FAIRY,          new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.NATURE_CHILD,   new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.ENDERLING,      new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.THIEF,          new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.BOMBER,         new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.TIME_STOPPER,   new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.FIELD_WEAVER,   new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.SPIT_EXPLOSION, new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.SPARTAN,        new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.WITHER_KIN,     new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.LAWFUL_CITIZEN, new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.REFLECTOR,      new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.GLASS_WALKER,   new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.SUMMONER,       new FBehavior[]{FBehavior.NORMAL_F});
        map.put(AbilityType.REDEEMER,       new FBehavior[]{FBehavior.NORMAL_F});

        return Collections.unmodifiableMap(map);
    }

    @Override
    public void onPluginMessageReceived(@NotNull String channel, @NotNull Player player, byte @NotNull [] message) {
        if (!channel.equals("superpower-keys:skill_key")) return;

        ByteArrayDataInput in = ByteStreams.newDataInput(message);
        int skillSlot = in.readInt();
        boolean pressed = in.readBoolean();

        if (!pressed) return;

        Bukkit.getScheduler().runTask(
                Bukkit.getPluginManager().getPlugin("SuperpowerKeysBridge"),
                () -> handleSkillPress(player, skillSlot)
        );
    }

    private void handleSkillPress(Player player, int skillSlot) {
        AbilityType ability = AbilityManager.getAbility(player);
        if (ability == null) return;

        int index = skillSlot - 1;
        FBehavior[] behaviors = BEHAVIOR_MAP.get(ability);

        if (behaviors != null && index < behaviors.length) {
            executeBehavior(player, ability, behaviors[index]);
        }
    }

    private void executeBehavior(Player player, AbilityType ability, FBehavior behavior) {
        switch (behavior) {
            case NORMAL_F -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, null);
                if (sneak) player.setSneaking(true);
            }
            case SNEAK_F -> {
                boolean sneak = player.isSneaking();
                if (!sneak) player.setSneaking(true);
                AbilityListener.executeFKey(player, null);
                if (!sneak) player.setSneaking(false);
            }
            case ITEM_F -> {
                Material item = (ability == AbilityType.SPIDER_MAN) ? Material.STRING : Material.STICK;
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, item);
                if (sneak) player.setSneaking(true);
            }
            case MIND_CONTROL -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.STICK);
                if (sneak) player.setSneaking(true);
            }
            case MIND_INVENTORY -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.CHEST);
                if (sneak) player.setSneaking(true);
            }
            case MIND_RELEASE -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.BARRIER);
                if (sneak) player.setSneaking(true);
            }
            case TOGGLE_ICE -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.ICE);
                if (sneak) player.setSneaking(true);
            }
            case VIEW_SOULS -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.STICK);
                if (sneak) player.setSneaking(true);
            }
            case SUMMON_SOUL -> {
                boolean sneak = player.isSneaking();
                if (sneak) player.setSneaking(false);
                AbilityListener.executeFKey(player, Material.BONE);
                if (sneak) player.setSneaking(true);
            }
            case SUMMON_ALL_SOUL -> {
                boolean sneak = player.isSneaking();
                if (!sneak) player.setSneaking(true);
                AbilityListener.executeFKey(player, Material.BONE);
                if (!sneak) player.setSneaking(false);
            }
        }
    }
}
