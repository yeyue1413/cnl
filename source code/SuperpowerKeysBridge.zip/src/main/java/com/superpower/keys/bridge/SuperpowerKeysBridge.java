package com.superpower.keys.bridge;

import com.superpower.keys.bridge.listener.SkillKeyListener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class SuperpowerKeysBridge extends JavaPlugin {
    private static SuperpowerKeysBridge instance;

    private static final String CHANNEL = "superpower-keys:skill_key";
    private SkillKeyListener skillKeyListener;

    public static SuperpowerKeysBridge getInstance() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;

        this.skillKeyListener = new SkillKeyListener();

        Bukkit.getMessenger().registerIncomingPluginChannel(this, CHANNEL, skillKeyListener);

        getLogger().info("SuperpowerKeysBridge 已启用 - 等待超能力按键Mod连接");
    }

    @Override
    public void onDisable() {
        Bukkit.getMessenger().unregisterIncomingPluginChannel(this);
        getLogger().info("SuperpowerKeysBridge 已禁用");
    }
}
