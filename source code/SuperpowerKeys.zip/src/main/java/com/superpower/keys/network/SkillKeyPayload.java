package com.superpower.keys.network;

import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record SkillKeyPayload(int skillSlot, boolean pressed) implements CustomPayload {
    public static final CustomPayload.Id<SkillKeyPayload> ID = new CustomPayload.Id<>(
            Identifier.of("superpower-keys", "skill_key")
    );

    public static final PacketCodec<PacketByteBuf, SkillKeyPayload> CODEC = PacketCodec.of(
            SkillKeyPayload::write,
            SkillKeyPayload::new
    );

    private SkillKeyPayload(PacketByteBuf buf) {
        this(buf.readInt(), buf.readBoolean());
    }

    private void write(PacketByteBuf buf) {
        buf.writeInt(skillSlot);
        buf.writeBoolean(pressed);
    }

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
