package com.superpower.keys;

import com.superpower.keys.network.SkillKeyPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SuperpowerKeysMod implements ModInitializer {
    public static final String MOD_ID = "superpower-keys";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().register(SkillKeyPayload.ID, SkillKeyPayload.CODEC);
        LOGGER.info("超能力按键 Mod 已初始化");
    }
}
