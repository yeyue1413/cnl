package com.superpower.keys;

import com.superpower.keys.network.SkillKeyPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class SuperpowerKeysClient implements ClientModInitializer {
    private static KeyBinding skill1Key;
    private static KeyBinding skill2Key;
    private static KeyBinding skill3Key;

    private static boolean lastSkill1Pressed = false;
    private static boolean lastSkill2Pressed = false;
    private static boolean lastSkill3Pressed = false;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(
                Identifier.of(SuperpowerKeysMod.MOD_ID, "category")
        );

        skill1Key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.superpower-keys.skill1",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                category
        ));

        skill2Key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.superpower-keys.skill2",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                category
        ));

        skill3Key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.superpower-keys.skill3",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            handleKey(skill1Key, 1);
            handleKey(skill2Key, 2);
            handleKey(skill3Key, 3);
        });

        SuperpowerKeysMod.LOGGER.info("超能力按键客户端已初始化");
    }

    private void handleKey(KeyBinding key, int skillSlot) {
        boolean isPressed = key.isPressed();

        boolean wasPressed = switch (skillSlot) {
            case 1 -> lastSkill1Pressed;
            case 2 -> lastSkill2Pressed;
            case 3 -> lastSkill3Pressed;
            default -> false;
        };

        if (isPressed != wasPressed) {
            updateLastPressed(skillSlot, isPressed);
            if (ClientPlayNetworking.canSend(SkillKeyPayload.ID)) {
                ClientPlayNetworking.send(new SkillKeyPayload(skillSlot, isPressed));
            }
        }
    }

    private void updateLastPressed(int skillSlot, boolean pressed) {
        switch (skillSlot) {
            case 1 -> lastSkill1Pressed = pressed;
            case 2 -> lastSkill2Pressed = pressed;
            case 3 -> lastSkill3Pressed = pressed;
        }
    }
}
